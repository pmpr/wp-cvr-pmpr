<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6800f8694bf67             |
    |_______________________________________|
*/
 do_action('render_footer');
