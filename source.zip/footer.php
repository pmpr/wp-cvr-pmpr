<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6681a8acaf4d8             |
    |_______________________________________|
*/
 do_action("\x72\x65\x6e\x64\x65\162\x5f\x66\x6f\x6f\x74\145\x72");
