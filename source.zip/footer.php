<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68cc71d48e2e3             |
    |_______________________________________|
*/
 do_action('render_footer');
