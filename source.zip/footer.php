<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68e580c20eadf             |
    |_______________________________________|
*/
 do_action('render_footer');
