<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68dda3bcddc00             |
    |_______________________________________|
*/
 pmpr_do_action('render_comments');
