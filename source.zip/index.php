<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ebe653ec9             |
    |_______________________________________|
*/
 pmpr_do_action("\x69\x6e\151\x74\x5f\x63\x6f\x76\x65\162");
