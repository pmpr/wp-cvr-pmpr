<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661d98bae5930             |
    |_______________________________________|
*/
 pmpr_do_action("\151\x6e\x69\x74\x5f\x63\x6f\x76\x65\162");
