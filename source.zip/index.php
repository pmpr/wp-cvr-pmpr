<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6800f8694bf67             |
    |_______________________________________|
*/
 pmpr_do_action('init_cover');
