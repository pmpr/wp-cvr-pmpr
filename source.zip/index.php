<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8625742f             |
    |_______________________________________|
*/
 pmpr_do_action("\x69\x6e\x69\x74\x5f\x63\157\x76\x65\x72");
