<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68cc71d48e2e3             |
    |_______________________________________|
*/
 pmpr_do_action('init_cover');
