<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e6f5ab992a             |
    |_______________________________________|
*/
 pmpr_do_action("\x69\x6e\151\164\x5f\x63\x6f\x76\x65\162");
