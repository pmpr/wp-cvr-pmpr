<?php
if (!defined('ABSPATH')) {
	exit;
}
do_action('woocommerce_render_variation', ['items' => $item_data]);
?>

