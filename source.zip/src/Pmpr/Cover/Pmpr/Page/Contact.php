<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6606b5f370d0d             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Common\Foundation\FormMaker\Front\Field\Field; use Pmpr\Cover\Pmpr\Container; class Contact extends Container { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x67\145\x74\137\143\x6f\156\x74\141\x63\x74\137\x66\x6f\162\x6d\137\146\x69\145\x6c\x64\163", [$this, "\x67\151\x6f\x6d\x67\141\x79\151\161\145\143\143\x67\141\145\147"]); } public function giomgayiqeccgaeg($ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $aiowsaccomcoikus) { if (!$aiowsaccomcoikus instanceof Field) { goto eequksumcoogyoem; } if (!(self::iueeekcmggceyscu === $aiowsaccomcoikus->mwikyscisascoeea())) { goto sqiciiuwmykocycc; } $aiowsaccomcoikus->qigsyyqgewgskemg("\x62\x74\156\x2d\160\162\x69\x6d\141\162\x79\x20\x68\157\166\x65\162\x2d\x6f\165\164\154\151\x6e\145\x20\144\x2d\146\x6c\x65\170"); sqiciiuwmykocycc: eequksumcoogyoem: iomcaiwewsawiamu: } kiqogmwcgcamwiig: return $ikgwqyuyckaewsow; } }
