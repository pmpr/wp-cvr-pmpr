<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e4de2d54d6             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; class Reportage extends Common { public function qiccuiwooiquycsg() { $this->wegcaymyqqoyewmw("\162\145\160\x6f\162\x74\x61\147\x65")->wmsaakuicamguoam(Setting::symcgieuakksimmu()->giiuwsmyumqwwiyq(Setting::akmweacgkkukkakq)); parent::qiccuiwooiquycsg(); } public function gogaagekwoisaqgu() { $this->gswweykyogmsyawy(__("\x52\145\160\157\162\x74\x61\147\x65", PR__CVR__PMPR)); } }
