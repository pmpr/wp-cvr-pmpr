<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6678837767a70             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; class Reportage extends Common { public function qiccuiwooiquycsg() { $this->wegcaymyqqoyewmw("\x72\x65\160\157\x72\164\141\147\145")->wmsaakuicamguoam(Setting::symcgieuakksimmu()->giiuwsmyumqwwiyq(Setting::akmweacgkkukkakq)); } public function gogaagekwoisaqgu() { $this->gswweykyogmsyawy(__("\x52\145\160\x6f\x72\164\x61\x67\x65", PR__CVR__PMPR)); } }
