<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6714e17f99bf3             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; use Pmpr\Common\Foundation\Frontend\Page; class Reportage extends Page { public function qiccuiwooiquycsg() { $this->wegcaymyqqoyewmw("\x72\x65\x70\x6f\162\164\x61\147\x65")->gswweykyogmsyawy(__("\122\x65\160\157\x72\164\141\x67\145", PR__CVR__PMPR))->wmsaakuicamguoam($this->weysguygiseoukqw(Setting::akmweacgkkukkakq)); } }
