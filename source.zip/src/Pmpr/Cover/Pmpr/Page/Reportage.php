<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66c31d3912e5b             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; class Reportage extends Common { public function qiccuiwooiquycsg() { $this->wegcaymyqqoyewmw("\x72\145\160\157\x72\164\x61\147\145")->wmsaakuicamguoam(Setting::symcgieuakksimmu()->giiuwsmyumqwwiyq(Setting::akmweacgkkukkakq)); } public function gogaagekwoisaqgu() { $this->gswweykyogmsyawy(__("\x52\145\x70\x6f\x72\x74\141\147\x65", PR__CVR__PMPR)); } }
