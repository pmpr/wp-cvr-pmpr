<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66bd2143b21cb             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; class Reportage extends Common { public function qiccuiwooiquycsg() { $this->wegcaymyqqoyewmw("\162\145\x70\157\162\164\x61\147\x65")->wmsaakuicamguoam(Setting::symcgieuakksimmu()->giiuwsmyumqwwiyq(Setting::akmweacgkkukkakq)); } public function gogaagekwoisaqgu() { $this->gswweykyogmsyawy(__("\x52\145\x70\157\162\164\x61\x67\145", PR__CVR__PMPR)); } }
