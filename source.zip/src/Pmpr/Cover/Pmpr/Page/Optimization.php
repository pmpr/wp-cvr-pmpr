<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668dab879d304             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; class Optimization extends Common { public function qiccuiwooiquycsg() { $this->ekgmmugauoasqwyc()->wegcaymyqqoyewmw("\157\160\164")->wmsaakuicamguoam(Setting::symcgieuakksimmu()->giiuwsmyumqwwiyq(Setting::wmesoeyeosmwmeyk)); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x68\x61\x73\x5f\x68\x65\x61\144\145\162", [$this, "\143\x77\x79\x63\x61\x77\x63\171\x67\153\x69\x61\145\145\x67\x69"])->aqaqisyssqeomwom("\150\141\163\137\x66\157\x6f\x74\x65\x72", [$this, "\143\x77\171\143\x61\x77\x63\171\x67\153\151\141\x65\x65\x67\151"]); parent::kgquecmsgcouyaya(); } public function gogaagekwoisaqgu() { $this->gswweykyogmsyawy(__("\117\x70\164\x69\155\x69\172\x61\x74\x69\x6f\x6e", PR__CVR__PMPR)); } public function cwycawcygkiaeegi($umuecysoywoumgwo) { if (!$this->sgeaogakoscmysgc()) { goto aiccyaswigkaycqk; } $umuecysoywoumgwo = false; aiccyaswigkaycqk: return $umuecysoywoumgwo; } }
