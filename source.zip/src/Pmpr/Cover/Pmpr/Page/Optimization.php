<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668c5b6675758             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; class Optimization extends Common { public function qiccuiwooiquycsg() { $this->ekgmmugauoasqwyc()->wegcaymyqqoyewmw("\157\160\x74")->wmsaakuicamguoam(Setting::symcgieuakksimmu()->giiuwsmyumqwwiyq(Setting::wmesoeyeosmwmeyk)); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\150\141\163\137\x68\x65\141\144\145\x72", [$this, "\x63\x77\171\x63\x61\167\x63\x79\147\x6b\x69\141\145\145\147\x69"])->aqaqisyssqeomwom("\x68\x61\x73\137\146\x6f\x6f\164\145\162", [$this, "\x63\167\171\x63\x61\x77\x63\171\147\153\151\x61\x65\145\x67\x69"]); parent::kgquecmsgcouyaya(); } public function gogaagekwoisaqgu() { $this->gswweykyogmsyawy(__("\x4f\160\x74\x69\155\151\x7a\141\x74\x69\157\156", PR__CVR__PMPR)); } public function cwycawcygkiaeegi($umuecysoywoumgwo) { if (!$this->sgeaogakoscmysgc()) { goto gkyawqqcmigqgaiq; } $umuecysoywoumgwo = false; gkyawqqcmigqgaiq: return $umuecysoywoumgwo; } }
