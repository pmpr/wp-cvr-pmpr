<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cf889e20710             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; class Optimization extends Common { public function qiccuiwooiquycsg() { $this->ekgmmugauoasqwyc()->wegcaymyqqoyewmw("\x6f\160\x74")->wmsaakuicamguoam(Setting::symcgieuakksimmu()->giiuwsmyumqwwiyq(Setting::wmesoeyeosmwmeyk)); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\150\141\163\137\150\145\141\144\145\162", [$this, "\x63\x77\x79\143\141\167\x63\x79\x67\153\151\x61\x65\145\147\x69"])->aqaqisyssqeomwom("\150\141\x73\x5f\146\x6f\157\164\145\162", [$this, "\143\x77\x79\x63\x61\x77\143\171\x67\153\151\141\145\145\x67\x69"]); parent::kgquecmsgcouyaya(); } public function gogaagekwoisaqgu() { $this->gswweykyogmsyawy(__("\x4f\x70\x74\151\x6d\151\172\x61\x74\x69\157\156", PR__CVR__PMPR)); } public function cwycawcygkiaeegi($umuecysoywoumgwo) { if (!$this->sgeaogakoscmysgc()) { goto yuqgwwmqwqiuwmaw; } $umuecysoywoumgwo = false; yuqgwwmqwqiuwmaw: return $umuecysoywoumgwo; } }
