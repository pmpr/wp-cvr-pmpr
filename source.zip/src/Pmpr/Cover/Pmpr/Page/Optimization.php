<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6621af0415f73             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; class Optimization extends Common { public function qiccuiwooiquycsg() { $this->ekgmmugauoasqwyc()->wegcaymyqqoyewmw("\157\160\x74")->wmsaakuicamguoam(Setting::symcgieuakksimmu()->giiuwsmyumqwwiyq(Setting::wmesoeyeosmwmeyk)); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\150\x61\x73\137\x68\x65\x61\x64\x65\x72", [$this, "\143\x77\171\x63\x61\x77\x63\x79\x67\x6b\151\141\x65\x65\x67\151"])->aqaqisyssqeomwom("\x68\x61\x73\x5f\x66\x6f\x6f\x74\x65\162", [$this, "\143\x77\171\143\141\x77\x63\x79\x67\x6b\x69\141\145\x65\147\151"]); parent::kgquecmsgcouyaya(); } public function gogaagekwoisaqgu() { $this->gswweykyogmsyawy(__("\x4f\x70\164\151\x6d\x69\x7a\x61\x74\x69\157\x6e", PR__CVR__PMPR)); } public function cwycawcygkiaeegi($umuecysoywoumgwo) { if (!$this->sgeaogakoscmysgc()) { goto saauykgakaeiyoua; } $umuecysoywoumgwo = false; saauykgakaeiyoua: return $umuecysoywoumgwo; } }
