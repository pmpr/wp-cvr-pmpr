<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669d561d8bd6d             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; class Optimization extends Common { public function qiccuiwooiquycsg() { $this->ekgmmugauoasqwyc()->wegcaymyqqoyewmw("\157\160\x74")->wmsaakuicamguoam(Setting::symcgieuakksimmu()->giiuwsmyumqwwiyq(Setting::wmesoeyeosmwmeyk)); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\150\x61\x73\x5f\150\x65\141\144\x65\x72", [$this, "\143\167\171\143\x61\x77\x63\171\147\153\151\141\x65\x65\147\x69"])->aqaqisyssqeomwom("\x68\x61\163\137\146\x6f\157\x74\145\162", [$this, "\143\167\x79\x63\141\167\x63\171\147\153\151\141\x65\x65\x67\x69"]); parent::kgquecmsgcouyaya(); } public function gogaagekwoisaqgu() { $this->gswweykyogmsyawy(__("\117\160\164\x69\155\x69\172\141\x74\151\x6f\156", PR__CVR__PMPR)); } public function cwycawcygkiaeegi($umuecysoywoumgwo) { if (!$this->sgeaogakoscmysgc()) { goto aiccyaswigkaycqk; } $umuecysoywoumgwo = false; aiccyaswigkaycqk: return $umuecysoywoumgwo; } }
