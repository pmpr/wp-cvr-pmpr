<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ebe653ec9             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; class Optimization extends Common { public function qiccuiwooiquycsg() { $this->ekgmmugauoasqwyc()->wegcaymyqqoyewmw("\x6f\160\164")->wmsaakuicamguoam(Setting::symcgieuakksimmu()->giiuwsmyumqwwiyq(Setting::wmesoeyeosmwmeyk)); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x68\141\163\x5f\x68\145\x61\144\145\x72", [$this, "\x63\167\x79\143\141\167\143\171\147\x6b\151\x61\x65\145\147\151"])->aqaqisyssqeomwom("\150\141\163\137\x66\157\157\x74\145\162", [$this, "\143\167\171\143\x61\167\143\171\147\x6b\x69\141\145\145\x67\x69"]); parent::kgquecmsgcouyaya(); } public function gogaagekwoisaqgu() { $this->gswweykyogmsyawy(__("\x4f\160\164\x69\155\151\x7a\141\x74\x69\x6f\156", PR__CVR__PMPR)); } public function cwycawcygkiaeegi($umuecysoywoumgwo) { if (!$this->sgeaogakoscmysgc()) { goto eqkauqciwewmgeoi; } $umuecysoywoumgwo = false; eqkauqciwewmgeoi: return $umuecysoywoumgwo; } }
