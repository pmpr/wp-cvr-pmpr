<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce114e0e8f4             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; class Optimization extends Common { public function qiccuiwooiquycsg() { $this->ekgmmugauoasqwyc()->wegcaymyqqoyewmw("\157\x70\164")->wmsaakuicamguoam(Setting::symcgieuakksimmu()->giiuwsmyumqwwiyq(Setting::wmesoeyeosmwmeyk)); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\150\x61\163\137\150\x65\141\x64\145\x72", [$this, "\x63\x77\x79\x63\141\x77\143\171\147\153\151\141\x65\145\x67\x69"])->aqaqisyssqeomwom("\x68\x61\163\x5f\146\157\x6f\x74\x65\162", [$this, "\143\x77\171\x63\x61\x77\x63\x79\147\153\151\x61\145\145\147\151"]); parent::kgquecmsgcouyaya(); } public function gogaagekwoisaqgu() { $this->gswweykyogmsyawy(__("\117\x70\x74\x69\155\x69\x7a\x61\164\x69\157\x6e", PR__CVR__PMPR)); } public function cwycawcygkiaeegi($umuecysoywoumgwo) { if (!$this->sgeaogakoscmysgc()) { goto yuqgwwmqwqiuwmaw; } $umuecysoywoumgwo = false; yuqgwwmqwqiuwmaw: return $umuecysoywoumgwo; } }
