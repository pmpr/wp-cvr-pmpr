<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6616500702db5             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; class Optimization extends Common { public function qiccuiwooiquycsg() { $this->ekgmmugauoasqwyc()->wegcaymyqqoyewmw("\x6f\x70\164")->wmsaakuicamguoam(Setting::symcgieuakksimmu()->giiuwsmyumqwwiyq(Setting::wmesoeyeosmwmeyk)); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x68\x61\x73\x5f\x68\x65\x61\144\x65\x72", [$this, "\x63\x77\x79\143\x61\x77\x63\171\147\x6b\x69\141\145\145\147\x69"])->aqaqisyssqeomwom("\x68\x61\163\x5f\x66\157\157\x74\x65\x72", [$this, "\x63\167\171\x63\141\167\143\171\x67\153\151\141\145\145\147\x69"]); parent::kgquecmsgcouyaya(); } public function gogaagekwoisaqgu() { $this->gswweykyogmsyawy(__("\x4f\x70\x74\x69\x6d\x69\172\x61\164\x69\157\156", PR__CVR__PMPR)); } public function cwycawcygkiaeegi($umuecysoywoumgwo) { if (!$this->sgeaogakoscmysgc()) { goto uougwgeyiokewkkm; } $umuecysoywoumgwo = false; uougwgeyiokewkkm: return $umuecysoywoumgwo; } }
