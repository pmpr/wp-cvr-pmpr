<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669ada6f97df7             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; class Optimization extends Common { public function qiccuiwooiquycsg() { $this->ekgmmugauoasqwyc()->wegcaymyqqoyewmw("\x6f\x70\x74")->wmsaakuicamguoam(Setting::symcgieuakksimmu()->giiuwsmyumqwwiyq(Setting::wmesoeyeosmwmeyk)); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x68\x61\x73\137\150\x65\141\144\145\x72", [$this, "\x63\167\x79\143\141\x77\x63\x79\147\x6b\x69\x61\145\145\x67\151"])->aqaqisyssqeomwom("\x68\x61\x73\137\146\x6f\x6f\164\x65\x72", [$this, "\143\x77\171\143\141\x77\143\171\147\153\x69\x61\145\145\147\x69"]); parent::kgquecmsgcouyaya(); } public function gogaagekwoisaqgu() { $this->gswweykyogmsyawy(__("\x4f\x70\x74\x69\155\151\x7a\x61\164\x69\157\156", PR__CVR__PMPR)); } public function cwycawcygkiaeegi($umuecysoywoumgwo) { if (!$this->sgeaogakoscmysgc()) { goto aiccyaswigkaycqk; } $umuecysoywoumgwo = false; aiccyaswigkaycqk: return $umuecysoywoumgwo; } }
