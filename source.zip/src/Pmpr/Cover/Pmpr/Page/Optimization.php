<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e6f5ab992a             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; class Optimization extends Common { public function qiccuiwooiquycsg() { $this->ekgmmugauoasqwyc()->wegcaymyqqoyewmw("\x6f\160\164")->wmsaakuicamguoam(Setting::symcgieuakksimmu()->giiuwsmyumqwwiyq(Setting::wmesoeyeosmwmeyk)); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x68\x61\x73\137\x68\x65\x61\x64\x65\x72", [$this, "\x63\167\x79\143\141\x77\x63\171\147\153\x69\141\145\x65\147\151"])->aqaqisyssqeomwom("\150\x61\163\x5f\146\157\157\164\145\x72", [$this, "\x63\167\x79\x63\x61\x77\143\171\x67\x6b\x69\x61\x65\145\147\x69"]); parent::kgquecmsgcouyaya(); } public function gogaagekwoisaqgu() { $this->gswweykyogmsyawy(__("\117\160\x74\151\x6d\151\172\141\x74\x69\157\156", PR__CVR__PMPR)); } public function cwycawcygkiaeegi($umuecysoywoumgwo) { if (!$this->sgeaogakoscmysgc()) { goto uougwgeyiokewkkm; } $umuecysoywoumgwo = false; uougwgeyiokewkkm: return $umuecysoywoumgwo; } }
