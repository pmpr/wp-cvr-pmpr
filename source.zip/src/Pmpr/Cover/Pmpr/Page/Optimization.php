<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6681a8acaf4d8             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; class Optimization extends Common { public function qiccuiwooiquycsg() { $this->ekgmmugauoasqwyc()->wegcaymyqqoyewmw("\157\160\164")->wmsaakuicamguoam(Setting::symcgieuakksimmu()->giiuwsmyumqwwiyq(Setting::wmesoeyeosmwmeyk)); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\150\x61\163\137\x68\145\141\144\145\x72", [$this, "\x63\167\x79\143\141\167\x63\x79\147\153\151\x61\x65\145\x67\151"])->aqaqisyssqeomwom("\x68\x61\163\x5f\146\157\x6f\164\145\x72", [$this, "\143\x77\x79\143\x61\x77\x63\171\x67\153\151\141\145\x65\147\x69"]); parent::kgquecmsgcouyaya(); } public function gogaagekwoisaqgu() { $this->gswweykyogmsyawy(__("\x4f\x70\164\x69\x6d\151\172\141\164\x69\x6f\x6e", PR__CVR__PMPR)); } public function cwycawcygkiaeegi($umuecysoywoumgwo) { if (!$this->sgeaogakoscmysgc()) { goto gkyawqqcmigqgaiq; } $umuecysoywoumgwo = false; gkyawqqcmigqgaiq: return $umuecysoywoumgwo; } }
