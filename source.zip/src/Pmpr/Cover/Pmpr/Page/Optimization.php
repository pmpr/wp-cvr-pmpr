<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4a92a54a5             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; use Pmpr\Common\Foundation\Frontend\Page; class Optimization extends Page { public function qiccuiwooiquycsg() { $this->ekgmmugauoasqwyc()->wegcaymyqqoyewmw("\x6f\x70\x74")->gswweykyogmsyawy(__("\x4f\160\164\x69\x6d\151\172\141\164\151\x6f\156", PR__CVR__PMPR))->wmsaakuicamguoam($this->weysguygiseoukqw(Setting::wmesoeyeosmwmeyk, 0)); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\150\141\163\x5f\150\x65\141\x64\145\x72", [$this, "\143\167\x79\x63\141\x77\143\x79\147\x6b\151\x61\145\x65\147\151"])->aqaqisyssqeomwom("\x68\141\x73\x5f\x66\x6f\157\x74\145\162", [$this, "\143\167\x79\x63\x61\167\143\171\x67\153\x69\141\x65\145\x67\x69"]); parent::kgquecmsgcouyaya(); } public function cwycawcygkiaeegi($umuecysoywoumgwo) { if ($this->sgeaogakoscmysgc()) { $umuecysoywoumgwo = false; } return $umuecysoywoumgwo; } }
