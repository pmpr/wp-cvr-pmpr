<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc4b4e670e             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; use Pmpr\Common\Foundation\Frontend\Page; class Optimization extends Page { public function qiccuiwooiquycsg() { $this->ekgmmugauoasqwyc()->wegcaymyqqoyewmw("\x6f\160\164")->gswweykyogmsyawy(__("\x4f\160\x74\x69\155\x69\x7a\141\x74\x69\x6f\156", PR__CVR__PMPR))->wmsaakuicamguoam($this->weysguygiseoukqw(Setting::wmesoeyeosmwmeyk, 0)); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\150\141\x73\x5f\x68\145\141\x64\145\x72", [$this, "\x63\167\171\143\141\167\x63\171\x67\x6b\151\141\145\x65\x67\x69"])->aqaqisyssqeomwom("\x68\x61\x73\137\x66\x6f\157\x74\145\162", [$this, "\x63\167\x79\143\141\x77\143\171\x67\x6b\x69\x61\145\x65\147\x69"]); parent::kgquecmsgcouyaya(); } public function cwycawcygkiaeegi($umuecysoywoumgwo) { if ($this->sgeaogakoscmysgc()) { $umuecysoywoumgwo = false; } return $umuecysoywoumgwo; } }
