<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             675816101f185             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; use Pmpr\Common\Foundation\Frontend\Page; class Optimization extends Page { public function qiccuiwooiquycsg() { $this->ekgmmugauoasqwyc()->wegcaymyqqoyewmw("\x6f\x70\x74")->gswweykyogmsyawy(__("\117\x70\x74\151\155\x69\172\x61\x74\x69\157\156", PR__CVR__PMPR))->wmsaakuicamguoam($this->weysguygiseoukqw(Setting::wmesoeyeosmwmeyk, 0)); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\150\141\163\x5f\x68\145\x61\144\x65\x72", [$this, "\x63\x77\x79\143\x61\167\x63\171\147\153\151\x61\145\145\147\151"])->aqaqisyssqeomwom("\x68\x61\163\x5f\146\x6f\157\164\x65\162", [$this, "\143\167\171\143\x61\167\143\x79\x67\x6b\x69\x61\145\145\x67\151"]); parent::kgquecmsgcouyaya(); } public function cwycawcygkiaeegi($umuecysoywoumgwo) { if ($this->sgeaogakoscmysgc()) { $umuecysoywoumgwo = false; } return $umuecysoywoumgwo; } }
