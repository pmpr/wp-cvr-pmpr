<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66c508e944d8a             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; class Optimization extends Common { public function qiccuiwooiquycsg() { $this->ekgmmugauoasqwyc()->wegcaymyqqoyewmw("\x6f\160\x74")->wmsaakuicamguoam(Setting::symcgieuakksimmu()->giiuwsmyumqwwiyq(Setting::wmesoeyeosmwmeyk)); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\150\141\x73\137\150\145\141\x64\x65\x72", [$this, "\143\x77\171\x63\x61\167\x63\x79\x67\153\151\x61\145\x65\147\151"])->aqaqisyssqeomwom("\150\x61\163\137\146\x6f\x6f\164\145\x72", [$this, "\143\x77\x79\x63\x61\167\143\171\x67\153\x69\x61\x65\x65\x67\x69"]); parent::kgquecmsgcouyaya(); } public function gogaagekwoisaqgu() { $this->gswweykyogmsyawy(__("\117\x70\164\x69\x6d\x69\x7a\141\164\x69\x6f\x6e", PR__CVR__PMPR)); } public function cwycawcygkiaeegi($umuecysoywoumgwo) { if (!$this->sgeaogakoscmysgc()) { goto qkuiwoqksgayqqmg; } $umuecysoywoumgwo = false; qkuiwoqksgayqqmg: return $umuecysoywoumgwo; } }
