<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d1dbc97f5c2             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; class Optimization extends Common { public function qiccuiwooiquycsg() { $this->ekgmmugauoasqwyc()->wegcaymyqqoyewmw("\x6f\160\164")->wmsaakuicamguoam(Setting::symcgieuakksimmu()->giiuwsmyumqwwiyq(Setting::wmesoeyeosmwmeyk)); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\150\x61\x73\x5f\150\x65\x61\144\145\x72", [$this, "\x63\x77\171\x63\x61\x77\x63\171\147\x6b\x69\x61\145\x65\x67\151"])->aqaqisyssqeomwom("\150\x61\163\137\x66\157\157\164\x65\x72", [$this, "\143\167\171\143\x61\167\143\171\147\153\x69\141\145\145\147\151"]); parent::kgquecmsgcouyaya(); } public function gogaagekwoisaqgu() { $this->gswweykyogmsyawy(__("\x4f\160\x74\x69\x6d\151\172\141\164\151\x6f\156", PR__CVR__PMPR)); } public function cwycawcygkiaeegi($umuecysoywoumgwo) { if (!$this->sgeaogakoscmysgc()) { goto yuqgwwmqwqiuwmaw; } $umuecysoywoumgwo = false; yuqgwwmqwqiuwmaw: return $umuecysoywoumgwo; } }
