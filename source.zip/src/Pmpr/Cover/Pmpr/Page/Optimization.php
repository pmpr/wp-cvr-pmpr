<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8625742f             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; class Optimization extends Common { public function qiccuiwooiquycsg() { $this->ekgmmugauoasqwyc()->wegcaymyqqoyewmw("\x6f\160\x74")->wmsaakuicamguoam(Setting::symcgieuakksimmu()->giiuwsmyumqwwiyq(Setting::wmesoeyeosmwmeyk)); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\150\x61\163\137\150\145\x61\144\145\162", [$this, "\x63\x77\x79\x63\x61\167\x63\x79\x67\153\x69\141\x65\145\147\x69"])->aqaqisyssqeomwom("\x68\141\x73\x5f\146\157\x6f\x74\x65\x72", [$this, "\x63\167\171\x63\141\x77\143\171\147\x6b\x69\x61\x65\145\x67\151"]); parent::kgquecmsgcouyaya(); } public function gogaagekwoisaqgu() { $this->gswweykyogmsyawy(__("\x4f\160\164\151\x6d\x69\x7a\x61\x74\151\157\x6e", PR__CVR__PMPR)); } public function cwycawcygkiaeegi($umuecysoywoumgwo) { if (!$this->sgeaogakoscmysgc()) { goto wcesymwqykqoyuqk; } $umuecysoywoumgwo = false; wcesymwqykqoyuqk: return $umuecysoywoumgwo; } }
