<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669eeba41d44c             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; class Optimization extends Common { public function qiccuiwooiquycsg() { $this->ekgmmugauoasqwyc()->wegcaymyqqoyewmw("\157\x70\x74")->wmsaakuicamguoam(Setting::symcgieuakksimmu()->giiuwsmyumqwwiyq(Setting::wmesoeyeosmwmeyk)); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x68\x61\163\x5f\x68\145\x61\144\145\x72", [$this, "\143\167\171\x63\x61\x77\143\x79\x67\153\x69\x61\145\145\x67\x69"])->aqaqisyssqeomwom("\150\x61\x73\137\x66\157\x6f\164\145\x72", [$this, "\143\167\x79\x63\x61\x77\143\x79\147\153\151\x61\x65\x65\147\151"]); parent::kgquecmsgcouyaya(); } public function gogaagekwoisaqgu() { $this->gswweykyogmsyawy(__("\117\160\164\x69\155\151\x7a\141\x74\151\x6f\x6e", PR__CVR__PMPR)); } public function cwycawcygkiaeegi($umuecysoywoumgwo) { if (!$this->sgeaogakoscmysgc()) { goto aiccyaswigkaycqk; } $umuecysoywoumgwo = false; aiccyaswigkaycqk: return $umuecysoywoumgwo; } }
