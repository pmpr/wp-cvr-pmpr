<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678a9fdb37aae             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; use Pmpr\Common\Foundation\Frontend\Page; class Optimization extends Page { public function qiccuiwooiquycsg() { $this->ekgmmugauoasqwyc()->wegcaymyqqoyewmw("\x6f\160\x74")->gswweykyogmsyawy(__("\x4f\160\164\151\x6d\x69\172\x61\x74\x69\157\x6e", PR__CVR__PMPR))->wmsaakuicamguoam($this->weysguygiseoukqw(Setting::wmesoeyeosmwmeyk, 0)); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x68\x61\x73\x5f\150\x65\x61\144\x65\x72", [$this, "\x63\x77\171\x63\141\167\143\x79\147\x6b\151\141\145\x65\x67\151"])->aqaqisyssqeomwom("\150\x61\163\137\146\157\157\x74\145\x72", [$this, "\143\167\x79\143\141\x77\x63\x79\147\x6b\151\141\145\x65\x67\151"]); parent::kgquecmsgcouyaya(); } public function cwycawcygkiaeegi($umuecysoywoumgwo) { if ($this->sgeaogakoscmysgc()) { $umuecysoywoumgwo = false; } return $umuecysoywoumgwo; } }
