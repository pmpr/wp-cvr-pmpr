<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661d98bae5930             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; class Optimization extends Common { public function qiccuiwooiquycsg() { $this->ekgmmugauoasqwyc()->wegcaymyqqoyewmw("\157\x70\164")->wmsaakuicamguoam(Setting::symcgieuakksimmu()->giiuwsmyumqwwiyq(Setting::wmesoeyeosmwmeyk)); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\150\x61\163\x5f\x68\145\x61\x64\145\162", [$this, "\x63\x77\x79\x63\x61\167\143\171\x67\x6b\151\x61\x65\x65\147\x69"])->aqaqisyssqeomwom("\150\x61\163\x5f\x66\x6f\x6f\x74\145\162", [$this, "\x63\167\x79\x63\141\167\143\171\x67\x6b\151\x61\145\145\147\x69"]); parent::kgquecmsgcouyaya(); } public function gogaagekwoisaqgu() { $this->gswweykyogmsyawy(__("\117\x70\164\151\x6d\151\x7a\141\164\x69\x6f\x6e", PR__CVR__PMPR)); } public function cwycawcygkiaeegi($umuecysoywoumgwo) { if (!$this->sgeaogakoscmysgc()) { goto uougwgeyiokewkkm; } $umuecysoywoumgwo = false; uougwgeyiokewkkm: return $umuecysoywoumgwo; } }
