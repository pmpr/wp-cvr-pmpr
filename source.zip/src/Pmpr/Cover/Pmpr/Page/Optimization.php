<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb56afe7646             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; class Optimization extends Common { public function qiccuiwooiquycsg() { $this->ekgmmugauoasqwyc()->wegcaymyqqoyewmw("\157\x70\x74")->wmsaakuicamguoam(Setting::symcgieuakksimmu()->giiuwsmyumqwwiyq(Setting::wmesoeyeosmwmeyk)); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\150\141\x73\x5f\x68\145\141\x64\x65\x72", [$this, "\x63\167\x79\143\x61\x77\143\x79\x67\153\151\141\x65\x65\x67\151"])->aqaqisyssqeomwom("\x68\x61\x73\137\x66\157\157\164\145\162", [$this, "\143\x77\x79\143\x61\x77\x63\x79\147\x6b\151\141\x65\145\x67\x69"]); parent::kgquecmsgcouyaya(); } public function gogaagekwoisaqgu() { $this->gswweykyogmsyawy(__("\x4f\160\x74\151\155\151\172\141\164\x69\x6f\x6e", PR__CVR__PMPR)); } public function cwycawcygkiaeegi($umuecysoywoumgwo) { if (!$this->sgeaogakoscmysgc()) { goto qkuiwoqksgayqqmg; } $umuecysoywoumgwo = false; qkuiwoqksgayqqmg: return $umuecysoywoumgwo; } }
