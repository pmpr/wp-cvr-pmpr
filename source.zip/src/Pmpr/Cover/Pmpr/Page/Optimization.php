<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66c31d3912e5b             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; class Optimization extends Common { public function qiccuiwooiquycsg() { $this->ekgmmugauoasqwyc()->wegcaymyqqoyewmw("\x6f\x70\x74")->wmsaakuicamguoam(Setting::symcgieuakksimmu()->giiuwsmyumqwwiyq(Setting::wmesoeyeosmwmeyk)); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\150\x61\163\137\150\145\x61\144\145\162", [$this, "\x63\167\171\x63\141\x77\143\171\x67\x6b\151\x61\x65\145\x67\151"])->aqaqisyssqeomwom("\x68\x61\x73\x5f\146\157\x6f\x74\145\162", [$this, "\143\x77\x79\143\141\x77\143\x79\x67\x6b\x69\141\x65\145\x67\x69"]); parent::kgquecmsgcouyaya(); } public function gogaagekwoisaqgu() { $this->gswweykyogmsyawy(__("\x4f\x70\x74\151\x6d\x69\172\x61\164\x69\x6f\x6e", PR__CVR__PMPR)); } public function cwycawcygkiaeegi($umuecysoywoumgwo) { if (!$this->sgeaogakoscmysgc()) { goto qkuiwoqksgayqqmg; } $umuecysoywoumgwo = false; qkuiwoqksgayqqmg: return $umuecysoywoumgwo; } }
