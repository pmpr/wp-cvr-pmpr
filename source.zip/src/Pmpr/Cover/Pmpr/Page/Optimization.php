<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce733cb0b0d             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; class Optimization extends Common { public function qiccuiwooiquycsg() { $this->ekgmmugauoasqwyc()->wegcaymyqqoyewmw("\x6f\x70\x74")->wmsaakuicamguoam(Setting::symcgieuakksimmu()->giiuwsmyumqwwiyq(Setting::wmesoeyeosmwmeyk)); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x68\x61\163\137\x68\145\141\144\x65\x72", [$this, "\143\167\171\x63\x61\x77\143\x79\x67\153\151\x61\x65\145\147\151"])->aqaqisyssqeomwom("\x68\x61\x73\x5f\x66\x6f\x6f\x74\145\x72", [$this, "\x63\x77\171\x63\141\x77\143\x79\x67\153\151\x61\x65\145\147\151"]); parent::kgquecmsgcouyaya(); } public function gogaagekwoisaqgu() { $this->gswweykyogmsyawy(__("\117\x70\164\151\x6d\151\x7a\141\x74\x69\x6f\x6e", PR__CVR__PMPR)); } public function cwycawcygkiaeegi($umuecysoywoumgwo) { if (!$this->sgeaogakoscmysgc()) { goto yuqgwwmqwqiuwmaw; } $umuecysoywoumgwo = false; yuqgwwmqwqiuwmaw: return $umuecysoywoumgwo; } }
