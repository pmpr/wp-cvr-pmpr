<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66c7b6d27cadb             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; class Optimization extends Common { public function qiccuiwooiquycsg() { $this->ekgmmugauoasqwyc()->wegcaymyqqoyewmw("\x6f\160\x74")->wmsaakuicamguoam(Setting::symcgieuakksimmu()->giiuwsmyumqwwiyq(Setting::wmesoeyeosmwmeyk)); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x68\x61\163\137\x68\145\x61\144\x65\x72", [$this, "\143\167\x79\x63\141\x77\x63\171\x67\153\x69\x61\x65\x65\147\151"])->aqaqisyssqeomwom("\x68\141\x73\x5f\146\157\157\x74\x65\x72", [$this, "\143\x77\171\x63\x61\167\143\x79\147\153\x69\141\x65\x65\147\151"]); parent::kgquecmsgcouyaya(); } public function gogaagekwoisaqgu() { $this->gswweykyogmsyawy(__("\117\x70\x74\x69\155\x69\172\141\164\x69\x6f\x6e", PR__CVR__PMPR)); } public function cwycawcygkiaeegi($umuecysoywoumgwo) { if (!$this->sgeaogakoscmysgc()) { goto qkuiwoqksgayqqmg; } $umuecysoywoumgwo = false; qkuiwoqksgayqqmg: return $umuecysoywoumgwo; } }
