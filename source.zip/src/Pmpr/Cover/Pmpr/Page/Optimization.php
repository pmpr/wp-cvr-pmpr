<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a2f440542e0             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; class Optimization extends Common { public function qiccuiwooiquycsg() { $this->ekgmmugauoasqwyc()->wegcaymyqqoyewmw("\157\160\164")->wmsaakuicamguoam(Setting::symcgieuakksimmu()->giiuwsmyumqwwiyq(Setting::wmesoeyeosmwmeyk)); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\150\x61\x73\137\x68\x65\141\x64\145\162", [$this, "\143\167\x79\x63\x61\167\143\x79\147\153\151\141\x65\x65\147\x69"])->aqaqisyssqeomwom("\x68\141\x73\137\x66\x6f\157\x74\x65\x72", [$this, "\143\x77\171\143\x61\167\x63\171\147\153\151\x61\x65\145\147\151"]); parent::kgquecmsgcouyaya(); } public function gogaagekwoisaqgu() { $this->gswweykyogmsyawy(__("\117\160\164\151\155\x69\x7a\141\x74\151\157\x6e", PR__CVR__PMPR)); } public function cwycawcygkiaeegi($umuecysoywoumgwo) { if (!$this->sgeaogakoscmysgc()) { goto twkmiuomimomscew; } $umuecysoywoumgwo = false; twkmiuomimomscew: return $umuecysoywoumgwo; } }
