<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662cf78a0568b             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; class Optimization extends Common { public function qiccuiwooiquycsg() { $this->ekgmmugauoasqwyc()->wegcaymyqqoyewmw("\x6f\x70\x74")->wmsaakuicamguoam(Setting::symcgieuakksimmu()->giiuwsmyumqwwiyq(Setting::wmesoeyeosmwmeyk)); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\150\x61\163\137\x68\145\141\144\145\162", [$this, "\143\x77\x79\143\x61\167\x63\x79\x67\x6b\151\x61\145\x65\x67\151"])->aqaqisyssqeomwom("\150\141\x73\137\x66\157\157\164\x65\x72", [$this, "\x63\167\x79\143\x61\167\x63\171\x67\153\151\x61\x65\145\x67\x69"]); parent::kgquecmsgcouyaya(); } public function gogaagekwoisaqgu() { $this->gswweykyogmsyawy(__("\117\160\164\x69\155\x69\172\x61\164\151\157\156", PR__CVR__PMPR)); } public function cwycawcygkiaeegi($umuecysoywoumgwo) { if (!$this->sgeaogakoscmysgc()) { goto saauykgakaeiyoua; } $umuecysoywoumgwo = false; saauykgakaeiyoua: return $umuecysoywoumgwo; } }
