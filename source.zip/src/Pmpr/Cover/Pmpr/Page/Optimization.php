<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6633b45bddf5b             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; class Optimization extends Common { public function qiccuiwooiquycsg() { $this->ekgmmugauoasqwyc()->wegcaymyqqoyewmw("\x6f\x70\x74")->wmsaakuicamguoam(Setting::symcgieuakksimmu()->giiuwsmyumqwwiyq(Setting::wmesoeyeosmwmeyk)); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x68\x61\x73\137\150\145\141\144\x65\162", [$this, "\143\x77\x79\143\141\167\143\x79\147\x6b\151\x61\x65\x65\147\x69"])->aqaqisyssqeomwom("\x68\x61\x73\137\x66\157\157\164\x65\x72", [$this, "\143\167\171\x63\x61\x77\x63\x79\147\x6b\151\141\145\145\147\151"]); parent::kgquecmsgcouyaya(); } public function gogaagekwoisaqgu() { $this->gswweykyogmsyawy(__("\117\160\164\x69\155\151\172\141\164\x69\x6f\x6e", PR__CVR__PMPR)); } public function cwycawcygkiaeegi($umuecysoywoumgwo) { if (!$this->sgeaogakoscmysgc()) { goto saauykgakaeiyoua; } $umuecysoywoumgwo = false; saauykgakaeiyoua: return $umuecysoywoumgwo; } }
