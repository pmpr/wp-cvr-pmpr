<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665e0f0c533e9             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; class Optimization extends Common { public function qiccuiwooiquycsg() { $this->ekgmmugauoasqwyc()->wegcaymyqqoyewmw("\157\x70\164")->wmsaakuicamguoam(Setting::symcgieuakksimmu()->giiuwsmyumqwwiyq(Setting::wmesoeyeosmwmeyk)); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x68\141\163\137\150\145\x61\144\x65\162", [$this, "\x63\x77\x79\x63\141\x77\143\x79\147\153\151\141\145\x65\147\x69"])->aqaqisyssqeomwom("\x68\x61\163\x5f\146\x6f\x6f\x74\x65\162", [$this, "\x63\167\x79\x63\x61\x77\143\x79\x67\153\151\141\145\145\147\151"]); parent::kgquecmsgcouyaya(); } public function gogaagekwoisaqgu() { $this->gswweykyogmsyawy(__("\x4f\160\164\151\155\x69\x7a\141\164\x69\x6f\156", PR__CVR__PMPR)); } public function cwycawcygkiaeegi($umuecysoywoumgwo) { if (!$this->sgeaogakoscmysgc()) { goto saauykgakaeiyoua; } $umuecysoywoumgwo = false; saauykgakaeiyoua: return $umuecysoywoumgwo; } }
