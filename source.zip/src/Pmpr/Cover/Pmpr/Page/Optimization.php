<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668707cdd97fe             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; class Optimization extends Common { public function qiccuiwooiquycsg() { $this->ekgmmugauoasqwyc()->wegcaymyqqoyewmw("\157\x70\x74")->wmsaakuicamguoam(Setting::symcgieuakksimmu()->giiuwsmyumqwwiyq(Setting::wmesoeyeosmwmeyk)); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\150\141\163\137\150\145\141\144\145\x72", [$this, "\x63\x77\171\143\141\x77\143\x79\x67\153\x69\141\x65\145\x67\x69"])->aqaqisyssqeomwom("\150\x61\163\x5f\x66\x6f\157\164\145\x72", [$this, "\143\167\171\143\x61\167\x63\x79\147\153\151\141\x65\x65\147\x69"]); parent::kgquecmsgcouyaya(); } public function gogaagekwoisaqgu() { $this->gswweykyogmsyawy(__("\x4f\160\164\x69\x6d\151\172\141\164\x69\x6f\156", PR__CVR__PMPR)); } public function cwycawcygkiaeegi($umuecysoywoumgwo) { if (!$this->sgeaogakoscmysgc()) { goto gkyawqqcmigqgaiq; } $umuecysoywoumgwo = false; gkyawqqcmigqgaiq: return $umuecysoywoumgwo; } }
