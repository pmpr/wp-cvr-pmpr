<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6606b5f370d0d             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; class Optimization extends Common { public function __construct() { $this->slug = "\x6f\x70\164"; $this->isPrivate = false; $this->hasBreadcrumb = false; parent::__construct(); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\150\141\x73\137\x68\145\141\144\145\162", [$this, "\x63\x77\x79\x63\141\x77\143\x79\x67\x6b\x69\141\145\x65\147\151"])->aqaqisyssqeomwom("\150\141\163\x5f\146\x6f\157\x74\x65\x72", [$this, "\143\167\171\x63\141\x77\x63\x79\x67\x6b\x69\141\145\145\147\151"]); parent::kgquecmsgcouyaya(); } public function gogaagekwoisaqgu() { $this->title = __("\x4f\160\x74\151\x6d\151\x7a\x61\x74\151\157\x6e", PR__CVR__PMPR); } public function cwycawcygkiaeegi($umuecysoywoumgwo) { if (!$this->sgeaogakoscmysgc()) { goto yowsmsiyimmimemc; } $umuecysoywoumgwo = false; yowsmsiyimmimemc: return $umuecysoywoumgwo; } }
