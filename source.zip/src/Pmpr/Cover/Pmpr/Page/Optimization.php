<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a42a72b7b43             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; class Optimization extends Common { public function qiccuiwooiquycsg() { $this->ekgmmugauoasqwyc()->wegcaymyqqoyewmw("\157\x70\x74")->wmsaakuicamguoam(Setting::symcgieuakksimmu()->giiuwsmyumqwwiyq(Setting::wmesoeyeosmwmeyk)); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\150\141\163\x5f\150\x65\141\144\145\162", [$this, "\143\167\x79\x63\x61\167\143\x79\x67\153\151\141\145\x65\x67\151"])->aqaqisyssqeomwom("\150\x61\x73\137\146\x6f\157\164\145\x72", [$this, "\143\x77\x79\143\141\x77\x63\171\147\153\x69\x61\x65\145\147\151"]); parent::kgquecmsgcouyaya(); } public function gogaagekwoisaqgu() { $this->gswweykyogmsyawy(__("\117\160\x74\x69\155\151\172\x61\x74\151\157\156", PR__CVR__PMPR)); } public function cwycawcygkiaeegi($umuecysoywoumgwo) { if (!$this->sgeaogakoscmysgc()) { goto twkmiuomimomscew; } $umuecysoywoumgwo = false; twkmiuomimomscew: return $umuecysoywoumgwo; } }
