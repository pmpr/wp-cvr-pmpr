<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6686f085801e1             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; class Optimization extends Common { public function qiccuiwooiquycsg() { $this->ekgmmugauoasqwyc()->wegcaymyqqoyewmw("\x6f\x70\x74")->wmsaakuicamguoam(Setting::symcgieuakksimmu()->giiuwsmyumqwwiyq(Setting::wmesoeyeosmwmeyk)); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x68\141\163\x5f\150\x65\x61\x64\145\162", [$this, "\x63\167\x79\x63\141\167\x63\171\147\153\151\141\145\x65\x67\x69"])->aqaqisyssqeomwom("\150\x61\x73\137\146\x6f\157\164\x65\162", [$this, "\x63\x77\x79\143\141\x77\143\171\x67\x6b\151\x61\x65\x65\147\x69"]); parent::kgquecmsgcouyaya(); } public function gogaagekwoisaqgu() { $this->gswweykyogmsyawy(__("\x4f\160\x74\151\155\x69\172\141\164\151\157\x6e", PR__CVR__PMPR)); } public function cwycawcygkiaeegi($umuecysoywoumgwo) { if (!$this->sgeaogakoscmysgc()) { goto gkyawqqcmigqgaiq; } $umuecysoywoumgwo = false; gkyawqqcmigqgaiq: return $umuecysoywoumgwo; } }
