<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66895809724d0             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; class Optimization extends Common { public function qiccuiwooiquycsg() { $this->ekgmmugauoasqwyc()->wegcaymyqqoyewmw("\157\160\x74")->wmsaakuicamguoam(Setting::symcgieuakksimmu()->giiuwsmyumqwwiyq(Setting::wmesoeyeosmwmeyk)); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x68\141\x73\137\x68\x65\x61\144\145\162", [$this, "\143\167\x79\143\141\167\x63\x79\147\153\x69\x61\x65\145\x67\x69"])->aqaqisyssqeomwom("\x68\x61\x73\x5f\x66\x6f\157\x74\x65\x72", [$this, "\143\x77\x79\x63\x61\167\143\x79\147\x6b\151\x61\x65\x65\x67\x69"]); parent::kgquecmsgcouyaya(); } public function gogaagekwoisaqgu() { $this->gswweykyogmsyawy(__("\117\x70\x74\x69\x6d\151\x7a\141\x74\151\157\156", PR__CVR__PMPR)); } public function cwycawcygkiaeegi($umuecysoywoumgwo) { if (!$this->sgeaogakoscmysgc()) { goto gkyawqqcmigqgaiq; } $umuecysoywoumgwo = false; gkyawqqcmigqgaiq: return $umuecysoywoumgwo; } }
