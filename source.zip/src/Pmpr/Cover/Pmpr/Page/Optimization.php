<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66aeb5c87ae9b             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; class Optimization extends Common { public function qiccuiwooiquycsg() { $this->ekgmmugauoasqwyc()->wegcaymyqqoyewmw("\x6f\160\x74")->wmsaakuicamguoam(Setting::symcgieuakksimmu()->giiuwsmyumqwwiyq(Setting::wmesoeyeosmwmeyk)); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x68\141\163\137\x68\x65\x61\x64\145\x72", [$this, "\x63\x77\171\x63\x61\167\x63\171\147\x6b\151\141\x65\x65\x67\x69"])->aqaqisyssqeomwom("\150\x61\x73\137\x66\x6f\x6f\x74\145\162", [$this, "\143\167\171\x63\141\x77\143\x79\147\153\x69\x61\145\145\x67\x69"]); parent::kgquecmsgcouyaya(); } public function gogaagekwoisaqgu() { $this->gswweykyogmsyawy(__("\x4f\160\164\x69\155\151\x7a\x61\164\x69\157\156", PR__CVR__PMPR)); } public function cwycawcygkiaeegi($umuecysoywoumgwo) { if (!$this->sgeaogakoscmysgc()) { goto yowsmsiyimmimemc; } $umuecysoywoumgwo = false; yowsmsiyimmimemc: return $umuecysoywoumgwo; } }
