<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67581a8b7701f             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; use Pmpr\Common\Foundation\Frontend\Page; class Optimization extends Page { public function qiccuiwooiquycsg() { $this->ekgmmugauoasqwyc()->wegcaymyqqoyewmw("\x6f\x70\x74")->gswweykyogmsyawy(__("\x4f\160\164\x69\155\x69\172\141\164\151\x6f\156", PR__CVR__PMPR))->wmsaakuicamguoam($this->weysguygiseoukqw(Setting::wmesoeyeosmwmeyk, 0)); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\150\141\x73\137\150\145\x61\144\x65\162", [$this, "\x63\167\x79\143\141\x77\143\x79\x67\153\151\141\x65\145\147\151"])->aqaqisyssqeomwom("\x68\141\x73\137\x66\157\x6f\x74\x65\x72", [$this, "\x63\x77\x79\x63\x61\167\143\x79\x67\153\151\141\x65\145\147\151"]); parent::kgquecmsgcouyaya(); } public function cwycawcygkiaeegi($umuecysoywoumgwo) { if ($this->sgeaogakoscmysgc()) { $umuecysoywoumgwo = false; } return $umuecysoywoumgwo; } }
