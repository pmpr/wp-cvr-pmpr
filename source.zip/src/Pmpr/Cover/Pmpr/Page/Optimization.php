<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665dbc49a1166             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; class Optimization extends Common { public function qiccuiwooiquycsg() { $this->ekgmmugauoasqwyc()->wegcaymyqqoyewmw("\x6f\160\x74")->wmsaakuicamguoam(Setting::symcgieuakksimmu()->giiuwsmyumqwwiyq(Setting::wmesoeyeosmwmeyk)); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x68\x61\x73\x5f\150\x65\141\144\145\162", [$this, "\143\x77\171\x63\x61\167\x63\171\x67\153\151\x61\x65\x65\x67\151"])->aqaqisyssqeomwom("\150\x61\x73\x5f\146\157\x6f\x74\145\162", [$this, "\x63\167\x79\143\x61\x77\143\x79\x67\153\151\x61\x65\x65\147\151"]); parent::kgquecmsgcouyaya(); } public function gogaagekwoisaqgu() { $this->gswweykyogmsyawy(__("\117\x70\x74\x69\155\x69\172\141\164\x69\157\156", PR__CVR__PMPR)); } public function cwycawcygkiaeegi($umuecysoywoumgwo) { if (!$this->sgeaogakoscmysgc()) { goto gkqiqaqecmoogmaa; } $umuecysoywoumgwo = false; gkqiqaqecmoogmaa: return $umuecysoywoumgwo; } }
