<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ced8515d92c             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; class Optimization extends Common { public function qiccuiwooiquycsg() { $this->ekgmmugauoasqwyc()->wegcaymyqqoyewmw("\157\x70\x74")->wmsaakuicamguoam(Setting::symcgieuakksimmu()->giiuwsmyumqwwiyq(Setting::wmesoeyeosmwmeyk)); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\150\x61\x73\137\x68\145\x61\144\145\162", [$this, "\143\167\x79\143\141\x77\x63\171\147\153\151\x61\x65\145\147\151"])->aqaqisyssqeomwom("\x68\141\x73\x5f\x66\x6f\x6f\164\145\x72", [$this, "\x63\167\171\x63\141\x77\x63\x79\x67\x6b\151\141\145\145\147\151"]); parent::kgquecmsgcouyaya(); } public function gogaagekwoisaqgu() { $this->gswweykyogmsyawy(__("\117\160\164\x69\x6d\151\x7a\141\164\x69\x6f\x6e", PR__CVR__PMPR)); } public function cwycawcygkiaeegi($umuecysoywoumgwo) { if (!$this->sgeaogakoscmysgc()) { goto yuqgwwmqwqiuwmaw; } $umuecysoywoumgwo = false; yuqgwwmqwqiuwmaw: return $umuecysoywoumgwo; } }
