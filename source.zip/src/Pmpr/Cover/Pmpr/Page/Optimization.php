<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665ec468a43fa             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; class Optimization extends Common { public function qiccuiwooiquycsg() { $this->ekgmmugauoasqwyc()->wegcaymyqqoyewmw("\x6f\x70\x74")->wmsaakuicamguoam(Setting::symcgieuakksimmu()->giiuwsmyumqwwiyq(Setting::wmesoeyeosmwmeyk)); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\150\141\x73\x5f\150\x65\x61\x64\145\x72", [$this, "\x63\167\x79\x63\141\167\143\x79\147\153\151\141\145\145\x67\x69"])->aqaqisyssqeomwom("\150\141\163\137\146\157\157\x74\x65\x72", [$this, "\143\x77\171\143\x61\167\143\x79\x67\x6b\151\x61\145\145\x67\x69"]); parent::kgquecmsgcouyaya(); } public function gogaagekwoisaqgu() { $this->gswweykyogmsyawy(__("\117\160\164\x69\x6d\151\x7a\141\164\x69\x6f\156", PR__CVR__PMPR)); } public function cwycawcygkiaeegi($umuecysoywoumgwo) { if (!$this->sgeaogakoscmysgc()) { goto saauykgakaeiyoua; } $umuecysoywoumgwo = false; saauykgakaeiyoua: return $umuecysoywoumgwo; } }
