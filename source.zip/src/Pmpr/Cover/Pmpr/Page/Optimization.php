<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669c358f62566             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; class Optimization extends Common { public function qiccuiwooiquycsg() { $this->ekgmmugauoasqwyc()->wegcaymyqqoyewmw("\157\x70\x74")->wmsaakuicamguoam(Setting::symcgieuakksimmu()->giiuwsmyumqwwiyq(Setting::wmesoeyeosmwmeyk)); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\150\141\163\137\x68\145\141\144\x65\x72", [$this, "\143\167\x79\143\141\x77\x63\171\147\x6b\151\141\x65\x65\x67\x69"])->aqaqisyssqeomwom("\150\x61\x73\137\146\157\x6f\164\x65\162", [$this, "\143\x77\171\x63\x61\167\x63\x79\147\153\x69\141\x65\x65\x67\151"]); parent::kgquecmsgcouyaya(); } public function gogaagekwoisaqgu() { $this->gswweykyogmsyawy(__("\x4f\160\164\151\155\151\x7a\141\x74\151\157\x6e", PR__CVR__PMPR)); } public function cwycawcygkiaeegi($umuecysoywoumgwo) { if (!$this->sgeaogakoscmysgc()) { goto aiccyaswigkaycqk; } $umuecysoywoumgwo = false; aiccyaswigkaycqk: return $umuecysoywoumgwo; } }
