<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66c65f6c2d137             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; class Optimization extends Common { public function qiccuiwooiquycsg() { $this->ekgmmugauoasqwyc()->wegcaymyqqoyewmw("\x6f\x70\x74")->wmsaakuicamguoam(Setting::symcgieuakksimmu()->giiuwsmyumqwwiyq(Setting::wmesoeyeosmwmeyk)); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\150\141\x73\x5f\x68\145\141\144\x65\162", [$this, "\x63\167\171\143\141\167\x63\x79\x67\153\151\141\145\145\x67\x69"])->aqaqisyssqeomwom("\x68\141\163\137\146\157\157\x74\x65\162", [$this, "\143\x77\171\143\141\x77\143\171\147\x6b\151\x61\145\145\x67\x69"]); parent::kgquecmsgcouyaya(); } public function gogaagekwoisaqgu() { $this->gswweykyogmsyawy(__("\x4f\160\164\151\x6d\151\172\141\164\151\157\156", PR__CVR__PMPR)); } public function cwycawcygkiaeegi($umuecysoywoumgwo) { if (!$this->sgeaogakoscmysgc()) { goto qkuiwoqksgayqqmg; } $umuecysoywoumgwo = false; qkuiwoqksgayqqmg: return $umuecysoywoumgwo; } }
