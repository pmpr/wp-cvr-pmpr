<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66b9bf433b189             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Container; class Page extends Container { public function mameiwsayuyquoeq() { Reportage::symcgieuakksimmu(); Optimization::symcgieuakksimmu(); ProfessionalWordpress::symcgieuakksimmu(); } }
