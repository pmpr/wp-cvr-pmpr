<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e4de2d54d6             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Container; class Page extends Container { public function mameiwsayuyquoeq() { Reportage::symcgieuakksimmu(); Optimization::symcgieuakksimmu(); ProfessionalWordpress::symcgieuakksimmu(); } }
