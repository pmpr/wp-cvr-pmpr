<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669eeba41d44c             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Container; class Page extends Container { public function mameiwsayuyquoeq() { Reportage::symcgieuakksimmu(); Optimization::symcgieuakksimmu(); ProfessionalWordpress::symcgieuakksimmu(); } }
