<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665ec468a43fa             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Container; class Page extends Container { public function mameiwsayuyquoeq() { Reportage::symcgieuakksimmu(); Optimization::symcgieuakksimmu(); ProfessionalWordpress::symcgieuakksimmu(); } }
