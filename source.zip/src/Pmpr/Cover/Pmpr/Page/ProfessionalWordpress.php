<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66c31d3912e5b             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; class ProfessionalWordpress extends Common { public function qiccuiwooiquycsg() { $this->ekgmmugauoasqwyc()->wegcaymyqqoyewmw("\x70\162\157\x66\x65\x73\163\151\157\x6e\141\x6c\x2d\167\x6f\162\144\x70\162\x65\x73\163")->wmsaakuicamguoam(Setting::symcgieuakksimmu()->giiuwsmyumqwwiyq(Setting::qimsgiaecyaykeyu)); parent::qiccuiwooiquycsg(); } public function gogaagekwoisaqgu() { $this->gswweykyogmsyawy(__("\x50\x72\x6f\x66\145\163\x73\151\157\x6e\x61\x6c\40\x57\157\162\x64\160\162\145\x73\x73", PR__CVR__PMPR)); } }
