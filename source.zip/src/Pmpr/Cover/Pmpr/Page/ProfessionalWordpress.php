<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce114e0e8f4             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; class ProfessionalWordpress extends Common { public function qiccuiwooiquycsg() { $this->ekgmmugauoasqwyc()->wegcaymyqqoyewmw("\160\162\157\146\145\x73\163\151\157\x6e\141\x6c\55\x77\x6f\x72\144\x70\x72\145\x73\163")->wmsaakuicamguoam(Setting::symcgieuakksimmu()->giiuwsmyumqwwiyq(Setting::qimsgiaecyaykeyu)); parent::qiccuiwooiquycsg(); } public function gogaagekwoisaqgu() { $this->gswweykyogmsyawy(__("\x50\162\157\x66\145\x73\163\151\x6f\156\141\x6c\40\x57\x6f\162\144\x70\x72\x65\163\x73", PR__CVR__PMPR)); } }
