<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66583846cd78a             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; class ProfessionalWordpress extends Common { public function qiccuiwooiquycsg() { $this->ekgmmugauoasqwyc()->wegcaymyqqoyewmw("\160\x72\x6f\146\145\x73\163\151\x6f\156\141\x6c\x2d\167\x6f\x72\x64\x70\x72\x65\x73\163")->wmsaakuicamguoam(Setting::symcgieuakksimmu()->giiuwsmyumqwwiyq(Setting::qimsgiaecyaykeyu)); parent::qiccuiwooiquycsg(); } public function gogaagekwoisaqgu() { $this->gswweykyogmsyawy(__("\x50\162\x6f\x66\145\x73\x73\x69\157\156\141\154\x20\x57\x6f\x72\x64\x70\162\x65\x73\x73", PR__CVR__PMPR)); } }
