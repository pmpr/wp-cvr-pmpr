<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668c5b6675758             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; class ProfessionalWordpress extends Common { public function qiccuiwooiquycsg() { $this->ekgmmugauoasqwyc()->wegcaymyqqoyewmw("\x70\x72\157\146\x65\163\x73\x69\157\156\141\154\x2d\167\157\x72\x64\160\162\145\x73\163")->wmsaakuicamguoam(Setting::symcgieuakksimmu()->giiuwsmyumqwwiyq(Setting::qimsgiaecyaykeyu)); parent::qiccuiwooiquycsg(); } public function gogaagekwoisaqgu() { $this->gswweykyogmsyawy(__("\120\x72\x6f\x66\x65\x73\163\151\x6f\156\141\x6c\x20\x57\157\162\x64\160\x72\145\163\x73", PR__CVR__PMPR)); } }
