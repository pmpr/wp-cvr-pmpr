<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6606b5f370d0d             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; class ProfessionalWordpress extends Common { public function __construct() { $this->slug = "\x70\x72\157\146\145\163\x73\x69\157\x6e\141\x6c\x2d\167\x6f\162\x64\160\162\x65\x73\x73"; $this->isPrivate = false; $this->hasBreadcrumb = false; parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\x50\x72\157\x66\145\x73\x73\151\x6f\156\141\154\40\x57\157\162\144\160\x72\x65\x73\x73", PR__CVR__PMPR); } }
