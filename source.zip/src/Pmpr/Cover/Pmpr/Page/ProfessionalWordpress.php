<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4a92a54a5             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; use Pmpr\Common\Foundation\Frontend\Page; class ProfessionalWordpress extends Page { public function qiccuiwooiquycsg() { $this->ekgmmugauoasqwyc()->wegcaymyqqoyewmw("\x70\162\x6f\146\x65\163\x73\x69\157\x6e\141\x6c\55\167\x6f\x72\144\x70\x72\145\163\x73")->gswweykyogmsyawy(__("\120\162\x6f\146\145\163\163\x69\x6f\156\141\154\x20\127\x6f\x72\144\x70\x72\x65\163\163", PR__CVR__PMPR))->wmsaakuicamguoam($this->weysguygiseoukqw(Setting::qimsgiaecyaykeyu)); parent::qiccuiwooiquycsg(); } }
