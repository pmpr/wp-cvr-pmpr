<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d8c776d9b3b             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; class ProfessionalWordpress extends Common { public function qiccuiwooiquycsg() { $this->ekgmmugauoasqwyc()->wegcaymyqqoyewmw("\x70\x72\x6f\146\x65\x73\x73\151\157\156\x61\x6c\x2d\167\157\162\144\160\x72\x65\163\x73")->wmsaakuicamguoam(Setting::symcgieuakksimmu()->giiuwsmyumqwwiyq(Setting::qimsgiaecyaykeyu)); parent::qiccuiwooiquycsg(); } public function gogaagekwoisaqgu() { $this->gswweykyogmsyawy(__("\120\162\x6f\146\145\x73\163\x69\x6f\156\x61\x6c\40\x57\x6f\x72\144\x70\x72\x65\163\163", PR__CVR__PMPR)); } }
