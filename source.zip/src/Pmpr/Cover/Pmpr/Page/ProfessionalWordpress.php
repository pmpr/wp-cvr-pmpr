<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             675816101f185             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; use Pmpr\Common\Foundation\Frontend\Page; class ProfessionalWordpress extends Page { public function qiccuiwooiquycsg() { $this->ekgmmugauoasqwyc()->wegcaymyqqoyewmw("\x70\162\x6f\x66\x65\x73\x73\x69\x6f\156\141\x6c\55\x77\157\162\144\160\x72\x65\x73\163")->gswweykyogmsyawy(__("\x50\162\157\x66\x65\x73\163\151\157\x6e\x61\154\x20\127\157\x72\144\160\162\x65\163\x73", PR__CVR__PMPR))->wmsaakuicamguoam($this->weysguygiseoukqw(Setting::qimsgiaecyaykeyu)); parent::qiccuiwooiquycsg(); } }
