<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ced8515d92c             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; class ProfessionalWordpress extends Common { public function qiccuiwooiquycsg() { $this->ekgmmugauoasqwyc()->wegcaymyqqoyewmw("\160\162\x6f\x66\x65\x73\163\151\157\x6e\141\154\55\167\x6f\162\x64\x70\x72\x65\x73\x73")->wmsaakuicamguoam(Setting::symcgieuakksimmu()->giiuwsmyumqwwiyq(Setting::qimsgiaecyaykeyu)); parent::qiccuiwooiquycsg(); } public function gogaagekwoisaqgu() { $this->gswweykyogmsyawy(__("\x50\x72\157\146\x65\163\x73\x69\157\x6e\x61\x6c\40\x57\157\162\x64\160\162\x65\x73\x73", PR__CVR__PMPR)); } }
