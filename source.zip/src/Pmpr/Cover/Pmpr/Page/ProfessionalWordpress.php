<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669d5b84b76a1             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; class ProfessionalWordpress extends Common { public function qiccuiwooiquycsg() { $this->ekgmmugauoasqwyc()->wegcaymyqqoyewmw("\x70\x72\157\146\145\163\x73\x69\157\x6e\141\154\55\x77\x6f\x72\x64\x70\x72\x65\x73\163")->wmsaakuicamguoam(Setting::symcgieuakksimmu()->giiuwsmyumqwwiyq(Setting::qimsgiaecyaykeyu)); parent::qiccuiwooiquycsg(); } public function gogaagekwoisaqgu() { $this->gswweykyogmsyawy(__("\120\162\157\x66\x65\x73\x73\x69\x6f\x6e\141\x6c\40\x57\x6f\x72\x64\160\162\x65\x73\x73", PR__CVR__PMPR)); } }
