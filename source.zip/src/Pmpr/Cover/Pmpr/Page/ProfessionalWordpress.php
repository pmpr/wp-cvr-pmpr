<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6681a8acaf4d8             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; class ProfessionalWordpress extends Common { public function qiccuiwooiquycsg() { $this->ekgmmugauoasqwyc()->wegcaymyqqoyewmw("\160\x72\157\x66\x65\x73\163\x69\x6f\156\x61\x6c\55\167\x6f\162\x64\x70\162\145\163\x73")->wmsaakuicamguoam(Setting::symcgieuakksimmu()->giiuwsmyumqwwiyq(Setting::qimsgiaecyaykeyu)); parent::qiccuiwooiquycsg(); } public function gogaagekwoisaqgu() { $this->gswweykyogmsyawy(__("\120\162\157\x66\x65\163\163\151\157\x6e\141\154\40\127\x6f\162\144\160\162\x65\x73\163", PR__CVR__PMPR)); } }
