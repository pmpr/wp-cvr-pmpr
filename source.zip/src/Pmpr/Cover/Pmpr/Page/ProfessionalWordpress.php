<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6714e17f99bf3             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; use Pmpr\Common\Foundation\Frontend\Page; class ProfessionalWordpress extends Page { public function qiccuiwooiquycsg() { $this->ekgmmugauoasqwyc()->wegcaymyqqoyewmw("\160\162\x6f\146\x65\x73\163\151\x6f\156\x61\x6c\x2d\167\157\162\x64\160\162\145\x73\x73")->gswweykyogmsyawy(__("\x50\x72\157\x66\x65\163\163\x69\157\x6e\141\154\x20\x57\x6f\162\x64\160\162\x65\163\x73", PR__CVR__PMPR))->wmsaakuicamguoam($this->weysguygiseoukqw(Setting::qimsgiaecyaykeyu)); parent::qiccuiwooiquycsg(); } }
