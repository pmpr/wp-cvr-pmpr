<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b6bee3838             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Page; use Pmpr\Cover\Pmpr\Setting; use Pmpr\Common\Foundation\Frontend\Page; class ProfessionalWordpress extends Page { public function qiccuiwooiquycsg() { $this->ekgmmugauoasqwyc()->wegcaymyqqoyewmw("\x70\162\x6f\x66\145\163\x73\x69\157\x6e\141\x6c\x2d\x77\x6f\162\144\160\162\x65\x73\x73")->gswweykyogmsyawy(__("\120\162\x6f\x66\145\163\163\151\x6f\x6e\x61\x6c\x20\x57\157\x72\144\x70\x72\x65\163\163", PR__CVR__PMPR))->wmsaakuicamguoam($this->weysguygiseoukqw(Setting::qimsgiaecyaykeyu)); parent::qiccuiwooiquycsg(); } }
