<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6634d46bd9359             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Template; class Template extends Common { public function mameiwsayuyquoeq() { Card::symcgieuakksimmu(); Relation::symcgieuakksimmu(); } }
