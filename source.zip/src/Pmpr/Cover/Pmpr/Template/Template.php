<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a2f440542e0             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Template; class Template extends Common { public function mameiwsayuyquoeq() { Card::symcgieuakksimmu(); Relation::symcgieuakksimmu(); } }
