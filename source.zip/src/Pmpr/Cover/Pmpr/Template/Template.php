<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669d712e470fd             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Template; class Template extends Common { public function mameiwsayuyquoeq() { Card::symcgieuakksimmu(); Relation::symcgieuakksimmu(); } }
