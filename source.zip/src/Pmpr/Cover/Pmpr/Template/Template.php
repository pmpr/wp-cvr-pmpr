<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669c358f62566             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Template; class Template extends Common { public function mameiwsayuyquoeq() { Card::symcgieuakksimmu(); Relation::symcgieuakksimmu(); } }
