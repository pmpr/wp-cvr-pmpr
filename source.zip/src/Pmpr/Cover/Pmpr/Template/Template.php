<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a42a72b7b43             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Template; class Template extends Common { public function mameiwsayuyquoeq() { Card::symcgieuakksimmu(); Relation::symcgieuakksimmu(); } }
