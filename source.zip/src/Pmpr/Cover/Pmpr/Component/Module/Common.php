<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce6cb67dbd5             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Component\Module; use Pmpr\Cover\Pmpr\Container; abstract class Common extends Container { }
