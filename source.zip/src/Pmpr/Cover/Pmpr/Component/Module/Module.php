<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669eeba41d44c             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Component\Module; class Module extends Common { public function mameiwsayuyquoeq() { Contact::symcgieuakksimmu(); } }
