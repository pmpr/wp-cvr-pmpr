<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66c65f6c2d137             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Component\Module; class Module extends Common { public function mameiwsayuyquoeq() { Contact::symcgieuakksimmu(); } }
