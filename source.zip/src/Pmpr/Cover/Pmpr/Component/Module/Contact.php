<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce733cb0b0d             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Component\Module; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; use Pmpr\Common\Foundation\Interfaces\Constants; class Contact extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\147\145\164\137\x63\x6f\x6e\164\x61\x63\x74\x5f\x66\x6f\x72\x6d\137\x66\151\145\x6c\x64\163", [$this, "\147\x69\157\155\147\x61\x79\x69\161\145\x63\143\147\x61\x65\x67"]); } public function giomgayiqeccgaeg($ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $aiowsaccomcoikus) { if (!($aiowsaccomcoikus instanceof Field && Constants::iueeekcmggceyscu === $aiowsaccomcoikus->mwikyscisascoeea())) { goto omykokikgocoikec; } $aiowsaccomcoikus->qigsyyqgewgskemg("\142\x74\x6e\x2d\160\162\x69\155\141\x72\x79\40\x68\157\x76\x65\x72\55\x6f\165\164\x6c\151\x6e\145\x20\144\55\146\154\x65\x78"); omykokikgocoikec: suuskagowwgsouqw: } kgmeiwiakwicgkkk: return $ikgwqyuyckaewsow; } }
