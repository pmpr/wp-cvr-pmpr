<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6678837767a70             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Component\Module; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; class Contact extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\147\x65\164\x5f\x63\157\156\164\x61\x63\x74\x5f\146\x6f\x72\x6d\137\146\151\145\154\144\163", [$this, "\x67\x69\157\155\147\x61\171\151\x71\x65\143\x63\x67\x61\145\147"]); } public function giomgayiqeccgaeg($ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $aiowsaccomcoikus) { if (!$aiowsaccomcoikus instanceof Field) { goto qkcyqocqqwmqgqww; } if (!(self::iueeekcmggceyscu === $aiowsaccomcoikus->mwikyscisascoeea())) { goto ssoucoucsgccekwe; } $aiowsaccomcoikus->qigsyyqgewgskemg("\x62\164\156\55\160\x72\151\x6d\141\x72\x79\40\150\157\166\145\x72\55\x6f\x75\164\x6c\151\156\x65\40\x64\x2d\146\154\x65\x78"); ssoucoucsgccekwe: qkcyqocqqwmqgqww: qqewoyookaskiuek: } iggyqogweyosuikc: return $ikgwqyuyckaewsow; } }
