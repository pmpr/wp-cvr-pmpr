<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665e0f0c533e9             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Component\Module; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; class Contact extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x67\145\164\x5f\143\157\x6e\x74\x61\x63\164\x5f\146\157\162\155\x5f\146\x69\145\154\x64\x73", [$this, "\x67\151\157\x6d\x67\x61\171\151\x71\145\x63\143\147\x61\145\147"]); } public function giomgayiqeccgaeg($ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $aiowsaccomcoikus) { if (!$aiowsaccomcoikus instanceof Field) { goto qiiigwkqeoewsuwm; } if (!(self::iueeekcmggceyscu === $aiowsaccomcoikus->mwikyscisascoeea())) { goto okkmcocqokkskasy; } $aiowsaccomcoikus->qigsyyqgewgskemg("\x62\164\x6e\x2d\x70\x72\151\x6d\x61\x72\x79\40\x68\x6f\166\x65\x72\55\x6f\165\164\x6c\x69\156\145\x20\x64\x2d\x66\x6c\x65\x78"); okkmcocqokkskasy: qiiigwkqeoewsuwm: esikeyqyuikmaiek: } iwsmmkqaoksmocok: return $ikgwqyuyckaewsow; } }
