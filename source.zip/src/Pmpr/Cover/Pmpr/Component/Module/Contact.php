<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669c358f62566             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Component\Module; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; class Contact extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\147\145\164\137\x63\x6f\156\164\141\143\164\x5f\146\157\162\155\x5f\146\151\145\154\x64\163", [$this, "\x67\151\157\x6d\x67\x61\x79\151\x71\x65\143\x63\147\141\x65\147"]); } public function giomgayiqeccgaeg($ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $aiowsaccomcoikus) { if (!$aiowsaccomcoikus instanceof Field) { goto sciwggaeogcoesiu; } if (!(self::iueeekcmggceyscu === $aiowsaccomcoikus->mwikyscisascoeea())) { goto mkwskuycuyguqqok; } $aiowsaccomcoikus->qigsyyqgewgskemg("\x62\164\x6e\x2d\x70\162\151\155\x61\x72\171\x20\150\x6f\166\145\162\55\157\x75\x74\x6c\x69\x6e\145\x20\x64\55\x66\x6c\x65\170"); mkwskuycuyguqqok: sciwggaeogcoesiu: kuicqywysciceggs: } cuykwgmswkskqkyi: return $ikgwqyuyckaewsow; } }
