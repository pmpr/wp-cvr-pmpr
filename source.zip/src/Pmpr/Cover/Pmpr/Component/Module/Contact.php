<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8625742f             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Component\Module; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; use Pmpr\Common\Foundation\Interfaces\Constants; class Contact extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\147\x65\164\137\x63\x6f\156\x74\141\143\x74\137\x66\157\162\155\137\146\151\x65\x6c\x64\x73", [$this, "\147\151\x6f\155\147\141\x79\151\x71\145\143\x63\147\x61\145\x67"]); } public function giomgayiqeccgaeg($ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $aiowsaccomcoikus) { if (!($aiowsaccomcoikus instanceof Field && Constants::iueeekcmggceyscu === $aiowsaccomcoikus->mwikyscisascoeea())) { goto igooksugieceoege; } $aiowsaccomcoikus->qigsyyqgewgskemg("\142\164\x6e\x2d\x70\162\151\x6d\x61\x72\171\x20\x68\x6f\x76\145\x72\55\x6f\165\164\x6c\x69\x6e\145\40\x64\x2d\146\154\145\x78"); igooksugieceoege: cewmoqyysgsmuiya: } scisgsyemmsekgos: return $ikgwqyuyckaewsow; } }
