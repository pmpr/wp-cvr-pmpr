<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6637344f0b8b9             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Component\Module; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; class Contact extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\147\x65\164\x5f\143\157\x6e\164\x61\x63\164\137\x66\x6f\x72\155\137\x66\x69\145\154\144\x73", [$this, "\x67\x69\x6f\155\x67\141\x79\151\161\x65\143\143\x67\x61\x65\147"]); } public function giomgayiqeccgaeg($ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $aiowsaccomcoikus) { if (!$aiowsaccomcoikus instanceof Field) { goto mceucsaeouuwyumm; } if (!(self::iueeekcmggceyscu === $aiowsaccomcoikus->mwikyscisascoeea())) { goto gkqiqaqecmoogmaa; } $aiowsaccomcoikus->qigsyyqgewgskemg("\142\164\x6e\55\160\162\x69\155\141\162\171\40\150\157\x76\145\x72\x2d\x6f\165\x74\x6c\151\x6e\145\40\x64\x2d\x66\154\145\170"); gkqiqaqecmoogmaa: mceucsaeouuwyumm: kwyimqumkuuyaiku: } mqimkwickkgqqeoi: return $ikgwqyuyckaewsow; } }
