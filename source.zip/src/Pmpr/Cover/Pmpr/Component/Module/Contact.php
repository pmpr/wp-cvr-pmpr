<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce114e0e8f4             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Component\Module; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; use Pmpr\Common\Foundation\Interfaces\Constants; class Contact extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x67\145\164\137\143\x6f\x6e\164\x61\x63\164\x5f\146\157\162\155\137\x66\x69\x65\154\x64\163", [$this, "\147\x69\x6f\x6d\x67\141\171\151\161\145\x63\143\147\x61\145\147"]); } public function giomgayiqeccgaeg($ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $aiowsaccomcoikus) { if (!($aiowsaccomcoikus instanceof Field && Constants::iueeekcmggceyscu === $aiowsaccomcoikus->mwikyscisascoeea())) { goto omykokikgocoikec; } $aiowsaccomcoikus->qigsyyqgewgskemg("\x62\x74\x6e\x2d\160\162\151\155\141\162\171\x20\150\157\x76\x65\x72\55\x6f\x75\x74\x6c\151\x6e\x65\x20\x64\x2d\x66\154\x65\x78"); omykokikgocoikec: suuskagowwgsouqw: } kgmeiwiakwicgkkk: return $ikgwqyuyckaewsow; } }
