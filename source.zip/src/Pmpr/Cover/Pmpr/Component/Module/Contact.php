<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ced9b261c92             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Component\Module; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; use Pmpr\Common\Foundation\Interfaces\Constants; class Contact extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x67\x65\164\137\143\x6f\x6e\x74\141\143\164\137\146\157\162\155\x5f\146\151\145\154\x64\x73", [$this, "\x67\x69\x6f\155\147\141\x79\x69\161\145\x63\143\x67\141\145\x67"]); } public function giomgayiqeccgaeg($ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $aiowsaccomcoikus) { if (!($aiowsaccomcoikus instanceof Field && Constants::iueeekcmggceyscu === $aiowsaccomcoikus->mwikyscisascoeea())) { goto omykokikgocoikec; } $aiowsaccomcoikus->qigsyyqgewgskemg("\142\164\156\55\160\x72\151\x6d\141\x72\171\x20\150\157\166\145\162\55\x6f\x75\x74\154\x69\156\x65\x20\x64\x2d\146\x6c\145\170"); omykokikgocoikec: suuskagowwgsouqw: } kgmeiwiakwicgkkk: return $ikgwqyuyckaewsow; } }
