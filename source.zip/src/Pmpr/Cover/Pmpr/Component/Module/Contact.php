<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6681a8acaf4d8             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Component\Module; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; class Contact extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x67\145\x74\137\143\157\156\x74\x61\143\x74\137\146\x6f\x72\155\x5f\146\x69\145\154\x64\163", [$this, "\147\151\157\155\147\141\171\x69\161\145\143\x63\x67\141\x65\x67"]); } public function giomgayiqeccgaeg($ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $aiowsaccomcoikus) { if (!$aiowsaccomcoikus instanceof Field) { goto qkcyqocqqwmqgqww; } if (!(self::iueeekcmggceyscu === $aiowsaccomcoikus->mwikyscisascoeea())) { goto ssoucoucsgccekwe; } $aiowsaccomcoikus->qigsyyqgewgskemg("\x62\x74\156\55\x70\162\151\x6d\x61\x72\171\40\x68\x6f\166\x65\162\x2d\157\x75\164\x6c\151\156\x65\x20\x64\x2d\146\154\x65\x78"); ssoucoucsgccekwe: qkcyqocqqwmqgqww: qqewoyookaskiuek: } iggyqogweyosuikc: return $ikgwqyuyckaewsow; } }
