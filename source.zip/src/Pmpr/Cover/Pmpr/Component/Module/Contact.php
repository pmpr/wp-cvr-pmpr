<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66b6183f51930             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Component\Module; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; class Contact extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x67\x65\x74\137\x63\x6f\156\164\141\x63\x74\x5f\x66\157\162\x6d\x5f\146\x69\145\154\x64\x73", [$this, "\147\x69\x6f\x6d\147\141\x79\151\161\x65\143\x63\x67\141\145\147"]); } public function giomgayiqeccgaeg($ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $aiowsaccomcoikus) { if (!$aiowsaccomcoikus instanceof Field) { goto suuskagowwgsouqw; } if (!(self::iueeekcmggceyscu === $aiowsaccomcoikus->mwikyscisascoeea())) { goto kgmeiwiakwicgkkk; } $aiowsaccomcoikus->qigsyyqgewgskemg("\142\x74\x6e\x2d\x70\162\x69\155\141\x72\171\40\x68\x6f\166\x65\162\x2d\157\165\x74\154\151\156\x65\x20\144\55\x66\x6c\x65\x78"); kgmeiwiakwicgkkk: suuskagowwgsouqw: cwswueuqoamqasya: } kicwiowcogmauwiy: return $ikgwqyuyckaewsow; } }
