<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6621af0415f73             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Component\Module; use Pmpr\Common\Foundation\FormMaker\Front\Field\Field; class Contact extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\147\145\x74\x5f\143\x6f\x6e\164\141\143\164\137\x66\x6f\162\155\x5f\x66\151\x65\154\144\x73", [$this, "\147\151\x6f\155\147\141\x79\x69\x71\x65\143\143\147\x61\x65\x67"]); } public function giomgayiqeccgaeg($ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $aiowsaccomcoikus) { if (!$aiowsaccomcoikus instanceof Field) { goto mceucsaeouuwyumm; } if (!(self::iueeekcmggceyscu === $aiowsaccomcoikus->mwikyscisascoeea())) { goto gkqiqaqecmoogmaa; } $aiowsaccomcoikus->qigsyyqgewgskemg("\x62\164\156\55\160\x72\x69\155\141\x72\x79\x20\x68\157\166\145\x72\55\157\165\x74\154\x69\156\x65\x20\144\x2d\146\154\145\x78"); gkqiqaqecmoogmaa: mceucsaeouuwyumm: kwyimqumkuuyaiku: } mqimkwickkgqqeoi: return $ikgwqyuyckaewsow; } }
