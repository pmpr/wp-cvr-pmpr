<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e4de2d54d6             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Component\Module; use Pmpr\Common\Foundation\FormMaker\Front\Field\Field; class Contact extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x67\145\164\x5f\x63\x6f\156\x74\x61\x63\164\x5f\x66\x6f\162\x6d\137\x66\x69\145\154\x64\x73", [$this, "\147\151\157\x6d\147\141\x79\x69\161\145\x63\143\x67\x61\x65\147"]); } public function giomgayiqeccgaeg($ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $aiowsaccomcoikus) { if (!$aiowsaccomcoikus instanceof Field) { goto ikuuiauwouuqawuw; } if (!(self::iueeekcmggceyscu === $aiowsaccomcoikus->mwikyscisascoeea())) { goto uckewycoogsogwiy; } $aiowsaccomcoikus->qigsyyqgewgskemg("\142\x74\x6e\55\160\x72\x69\155\x61\162\171\x20\150\157\166\x65\162\x2d\x6f\165\x74\x6c\151\x6e\145\40\144\55\146\x6c\x65\x78"); uckewycoogsogwiy: ikuuiauwouuqawuw: kwiggogcgciwuwqk: } yykqaowwsqgqysmq: return $ikgwqyuyckaewsow; } }
