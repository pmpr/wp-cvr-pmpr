<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6684009825136             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Component\Module; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; class Contact extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x67\145\x74\137\x63\157\x6e\164\141\143\164\137\146\x6f\x72\155\x5f\146\x69\145\x6c\x64\x73", [$this, "\x67\151\x6f\x6d\147\x61\171\x69\161\145\143\143\x67\x61\145\x67"]); } public function giomgayiqeccgaeg($ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $aiowsaccomcoikus) { if (!$aiowsaccomcoikus instanceof Field) { goto qkcyqocqqwmqgqww; } if (!(self::iueeekcmggceyscu === $aiowsaccomcoikus->mwikyscisascoeea())) { goto ssoucoucsgccekwe; } $aiowsaccomcoikus->qigsyyqgewgskemg("\142\x74\156\x2d\x70\x72\151\155\x61\162\171\40\x68\x6f\x76\145\162\x2d\x6f\165\x74\x6c\x69\156\x65\x20\x64\55\x66\154\145\170"); ssoucoucsgccekwe: qkcyqocqqwmqgqww: qqewoyookaskiuek: } iggyqogweyosuikc: return $ikgwqyuyckaewsow; } }
