<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66583846cd78a             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Component\Module; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; class Contact extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x67\145\164\137\x63\157\156\164\x61\x63\x74\137\146\x6f\162\155\137\x66\x69\x65\x6c\x64\163", [$this, "\x67\151\157\155\x67\141\171\151\x71\x65\143\143\x67\141\x65\147"]); } public function giomgayiqeccgaeg($ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $aiowsaccomcoikus) { if (!$aiowsaccomcoikus instanceof Field) { goto suqcsgaosywaauuu; } if (!(self::iueeekcmggceyscu === $aiowsaccomcoikus->mwikyscisascoeea())) { goto mscgewkcqcoowweg; } $aiowsaccomcoikus->qigsyyqgewgskemg("\x62\164\x6e\x2d\160\x72\x69\x6d\141\x72\171\40\x68\x6f\166\x65\162\x2d\x6f\165\x74\154\151\x6e\x65\x20\144\x2d\x66\x6c\x65\x78"); mscgewkcqcoowweg: suqcsgaosywaauuu: ikqeeaysmqgcgawq: } esaqcqqwuussiiwo: return $ikgwqyuyckaewsow; } }
