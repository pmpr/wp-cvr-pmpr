<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d8c776d9b3b             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Component\Module; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; use Pmpr\Common\Foundation\Interfaces\Constants; class Contact extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x67\145\164\x5f\x63\157\x6e\x74\x61\x63\x74\137\146\x6f\x72\155\x5f\146\x69\145\154\x64\163", [$this, "\147\x69\x6f\155\147\x61\x79\151\161\145\143\143\147\141\145\147"]); } public function giomgayiqeccgaeg($ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $aiowsaccomcoikus) { if (!($aiowsaccomcoikus instanceof Field && Constants::iueeekcmggceyscu === $aiowsaccomcoikus->mwikyscisascoeea())) { goto quyogmwugsyoaaiu; } $aiowsaccomcoikus->qigsyyqgewgskemg("\142\164\156\x2d\x70\x72\151\x6d\141\162\x79\40\150\x6f\x76\x65\162\55\157\x75\x74\154\151\156\145\40\x64\x2d\x66\154\145\170"); quyogmwugsyoaaiu: skuqigsokaguscas: } sgiwoiscywusgmmm: return $ikgwqyuyckaewsow; } }
