<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661d98bae5930             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Component\Module; use Pmpr\Common\Foundation\FormMaker\Front\Field\Field; class Contact extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\147\x65\164\137\x63\x6f\156\164\141\143\x74\x5f\146\x6f\x72\155\x5f\x66\151\145\154\144\x73", [$this, "\147\x69\x6f\155\x67\x61\171\x69\161\x65\143\143\147\x61\x65\x67"]); } public function giomgayiqeccgaeg($ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $aiowsaccomcoikus) { if (!$aiowsaccomcoikus instanceof Field) { goto ikuuiauwouuqawuw; } if (!(self::iueeekcmggceyscu === $aiowsaccomcoikus->mwikyscisascoeea())) { goto uckewycoogsogwiy; } $aiowsaccomcoikus->qigsyyqgewgskemg("\142\x74\x6e\x2d\160\162\151\x6d\141\x72\171\x20\x68\x6f\166\x65\162\x2d\157\x75\164\x6c\151\156\145\x20\x64\x2d\146\x6c\x65\170"); uckewycoogsogwiy: ikuuiauwouuqawuw: kwiggogcgciwuwqk: } yykqaowwsqgqysmq: return $ikgwqyuyckaewsow; } }
