<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669ada6f97df7             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Component\Module; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; class Contact extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x67\145\164\x5f\143\157\x6e\x74\141\143\164\137\x66\157\162\155\137\146\151\x65\x6c\x64\163", [$this, "\x67\151\157\155\x67\x61\171\151\x71\145\x63\x63\147\141\x65\147"]); } public function giomgayiqeccgaeg($ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $aiowsaccomcoikus) { if (!$aiowsaccomcoikus instanceof Field) { goto sciwggaeogcoesiu; } if (!(self::iueeekcmggceyscu === $aiowsaccomcoikus->mwikyscisascoeea())) { goto mkwskuycuyguqqok; } $aiowsaccomcoikus->qigsyyqgewgskemg("\142\164\156\55\160\x72\151\155\x61\x72\x79\x20\150\157\166\145\162\x2d\x6f\165\164\154\151\x6e\x65\x20\144\x2d\146\154\x65\x78"); mkwskuycuyguqqok: sciwggaeogcoesiu: kuicqywysciceggs: } cuykwgmswkskqkyi: return $ikgwqyuyckaewsow; } }
