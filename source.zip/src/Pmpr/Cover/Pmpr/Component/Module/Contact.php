<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66c508e944d8a             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Component\Module; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; class Contact extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x67\x65\164\137\x63\157\156\x74\x61\x63\164\x5f\x66\x6f\162\x6d\x5f\146\151\x65\154\144\163", [$this, "\x67\x69\157\155\x67\x61\171\x69\161\x65\x63\x63\x67\141\145\147"]); } public function giomgayiqeccgaeg($ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $aiowsaccomcoikus) { if (!$aiowsaccomcoikus instanceof Field) { goto suuskagowwgsouqw; } if (!(self::iueeekcmggceyscu === $aiowsaccomcoikus->mwikyscisascoeea())) { goto kgmeiwiakwicgkkk; } $aiowsaccomcoikus->qigsyyqgewgskemg("\142\164\156\x2d\x70\x72\151\155\141\162\x79\x20\150\x6f\166\x65\162\55\157\x75\164\x6c\x69\156\x65\x20\x64\55\x66\x6c\x65\170"); kgmeiwiakwicgkkk: suuskagowwgsouqw: cwswueuqoamqasya: } kicwiowcogmauwiy: return $ikgwqyuyckaewsow; } }
