<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669d712e470fd             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Component\Module; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; class Contact extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x67\145\x74\137\x63\157\156\164\x61\143\164\x5f\x66\157\162\155\x5f\x66\x69\x65\154\x64\x73", [$this, "\x67\x69\157\x6d\x67\141\171\x69\161\145\x63\x63\147\141\145\x67"]); } public function giomgayiqeccgaeg($ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $aiowsaccomcoikus) { if (!$aiowsaccomcoikus instanceof Field) { goto sciwggaeogcoesiu; } if (!(self::iueeekcmggceyscu === $aiowsaccomcoikus->mwikyscisascoeea())) { goto mkwskuycuyguqqok; } $aiowsaccomcoikus->qigsyyqgewgskemg("\142\x74\156\x2d\x70\162\x69\155\141\162\x79\x20\150\x6f\x76\x65\x72\x2d\157\x75\x74\x6c\151\x6e\x65\x20\144\x2d\x66\x6c\x65\170"); mkwskuycuyguqqok: sciwggaeogcoesiu: kuicqywysciceggs: } cuykwgmswkskqkyi: return $ikgwqyuyckaewsow; } }
