<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ebe653ec9             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Component\Module; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; use Pmpr\Common\Foundation\Interfaces\Constants; class Contact extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x67\x65\x74\x5f\x63\x6f\x6e\164\141\143\x74\137\x66\x6f\162\x6d\x5f\x66\151\145\154\144\163", [$this, "\147\151\157\155\x67\x61\171\x69\161\x65\143\143\147\x61\x65\x67"]); } public function giomgayiqeccgaeg($ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $aiowsaccomcoikus) { if (!($aiowsaccomcoikus instanceof Field && Constants::iueeekcmggceyscu === $aiowsaccomcoikus->mwikyscisascoeea())) { goto quyogmwugsyoaaiu; } $aiowsaccomcoikus->qigsyyqgewgskemg("\x62\164\x6e\55\x70\162\151\x6d\141\x72\x79\40\x68\157\166\x65\162\55\x6f\x75\164\154\x69\x6e\145\40\x64\55\x66\x6c\145\x78"); quyogmwugsyoaaiu: skuqigsokaguscas: } sgiwoiscywusgmmm: return $ikgwqyuyckaewsow; } }
