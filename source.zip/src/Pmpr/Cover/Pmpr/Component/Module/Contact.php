<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e6f5ab992a             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Component\Module; use Pmpr\Common\Foundation\FormMaker\Front\Field\Field; class Contact extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x67\x65\164\137\143\x6f\x6e\164\x61\x63\164\x5f\x66\157\162\x6d\x5f\146\151\145\x6c\x64\x73", [$this, "\147\151\x6f\x6d\147\x61\x79\x69\161\145\143\143\x67\141\145\147"]); } public function giomgayiqeccgaeg($ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $aiowsaccomcoikus) { if (!$aiowsaccomcoikus instanceof Field) { goto ikuuiauwouuqawuw; } if (!(self::iueeekcmggceyscu === $aiowsaccomcoikus->mwikyscisascoeea())) { goto uckewycoogsogwiy; } $aiowsaccomcoikus->qigsyyqgewgskemg("\142\x74\156\55\x70\x72\x69\155\141\x72\171\40\x68\x6f\x76\x65\162\x2d\157\x75\164\154\151\156\x65\x20\x64\x2d\x66\x6c\145\x78"); uckewycoogsogwiy: ikuuiauwouuqawuw: kwiggogcgciwuwqk: } yykqaowwsqgqysmq: return $ikgwqyuyckaewsow; } }
