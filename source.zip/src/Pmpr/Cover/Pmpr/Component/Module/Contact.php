<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67581a8b7701f             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Component\Module; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Cover\Pmpr\Container; class Contact extends Container { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\147\x65\x74\x5f\x63\x6f\x6e\164\141\x63\x74\137\146\x6f\x72\155\137\146\x69\x65\x6c\144\163", [$this, "\147\151\x6f\155\147\141\x79\x69\161\x65\x63\x63\x67\141\x65\147"]); } public function giomgayiqeccgaeg($ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $aiowsaccomcoikus) { if ($aiowsaccomcoikus instanceof Field && Constants::iueeekcmggceyscu === $aiowsaccomcoikus->mwikyscisascoeea()) { $aiowsaccomcoikus->qigsyyqgewgskemg("\142\164\156\x2d\160\162\x69\x6d\141\162\x79\40\x68\157\166\145\162\x2d\x6f\x75\x74\x6c\151\156\x65\40\x64\55\x66\154\x65\170"); } } return $ikgwqyuyckaewsow; } }
