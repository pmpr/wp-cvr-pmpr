<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a42a72b7b43             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Component\Module; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; class Contact extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\147\145\x74\137\143\x6f\156\164\x61\x63\x74\137\146\x6f\x72\x6d\x5f\x66\x69\145\x6c\144\x73", [$this, "\147\151\157\155\x67\x61\171\151\161\x65\x63\x63\147\x61\x65\147"]); } public function giomgayiqeccgaeg($ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $aiowsaccomcoikus) { if (!$aiowsaccomcoikus instanceof Field) { goto suuskagowwgsouqw; } if (!(self::iueeekcmggceyscu === $aiowsaccomcoikus->mwikyscisascoeea())) { goto kgmeiwiakwicgkkk; } $aiowsaccomcoikus->qigsyyqgewgskemg("\x62\x74\x6e\x2d\160\162\151\x6d\141\162\171\40\150\x6f\x76\x65\x72\55\157\165\x74\154\x69\156\x65\40\144\x2d\146\x6c\145\170"); kgmeiwiakwicgkkk: suuskagowwgsouqw: cwswueuqoamqasya: } kicwiowcogmauwiy: return $ikgwqyuyckaewsow; } }
