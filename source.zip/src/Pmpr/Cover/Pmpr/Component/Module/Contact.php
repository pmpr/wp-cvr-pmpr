<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb56afe7646             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Component\Module; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; class Contact extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x67\145\164\x5f\143\x6f\156\x74\141\143\164\137\146\157\x72\x6d\x5f\x66\151\145\154\x64\163", [$this, "\x67\151\157\x6d\x67\x61\x79\x69\x71\x65\143\x63\147\141\x65\147"]); } public function giomgayiqeccgaeg($ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $aiowsaccomcoikus) { if (!$aiowsaccomcoikus instanceof Field) { goto suuskagowwgsouqw; } if (!(self::iueeekcmggceyscu === $aiowsaccomcoikus->mwikyscisascoeea())) { goto kgmeiwiakwicgkkk; } $aiowsaccomcoikus->qigsyyqgewgskemg("\x62\x74\156\x2d\160\162\x69\155\141\x72\171\x20\x68\157\166\x65\162\55\x6f\165\x74\x6c\x69\156\145\x20\144\55\x66\x6c\145\170"); kgmeiwiakwicgkkk: suuskagowwgsouqw: cwswueuqoamqasya: } kicwiowcogmauwiy: return $ikgwqyuyckaewsow; } }
