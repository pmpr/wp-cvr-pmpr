<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661da299c54f1             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Component\Module; use Pmpr\Common\Foundation\FormMaker\Front\Field\Field; class Contact extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x67\x65\164\137\x63\157\x6e\164\141\x63\164\137\x66\x6f\162\x6d\137\146\x69\145\x6c\x64\x73", [$this, "\x67\151\x6f\x6d\147\141\171\151\161\x65\x63\x63\147\141\145\x67"]); } public function giomgayiqeccgaeg($ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $aiowsaccomcoikus) { if (!$aiowsaccomcoikus instanceof Field) { goto ikuuiauwouuqawuw; } if (!(self::iueeekcmggceyscu === $aiowsaccomcoikus->mwikyscisascoeea())) { goto uckewycoogsogwiy; } $aiowsaccomcoikus->qigsyyqgewgskemg("\x62\x74\156\x2d\x70\162\151\155\x61\x72\x79\x20\150\x6f\166\145\x72\x2d\x6f\165\x74\x6c\x69\156\145\x20\144\55\x66\154\145\x78"); uckewycoogsogwiy: ikuuiauwouuqawuw: kwiggogcgciwuwqk: } yykqaowwsqgqysmq: return $ikgwqyuyckaewsow; } }
