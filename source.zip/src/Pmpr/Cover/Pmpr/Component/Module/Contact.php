<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66812eb5d80af             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Component\Module; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; class Contact extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\147\145\164\x5f\143\157\x6e\x74\x61\143\x74\x5f\x66\x6f\x72\x6d\x5f\146\151\x65\x6c\x64\x73", [$this, "\x67\151\157\155\147\x61\171\x69\161\145\x63\x63\x67\x61\x65\147"]); } public function giomgayiqeccgaeg($ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $aiowsaccomcoikus) { if (!$aiowsaccomcoikus instanceof Field) { goto qkcyqocqqwmqgqww; } if (!(self::iueeekcmggceyscu === $aiowsaccomcoikus->mwikyscisascoeea())) { goto ssoucoucsgccekwe; } $aiowsaccomcoikus->qigsyyqgewgskemg("\142\164\156\x2d\x70\x72\151\155\141\x72\171\x20\150\157\166\145\162\x2d\157\x75\x74\x6c\151\x6e\145\x20\x64\55\x66\x6c\x65\170"); ssoucoucsgccekwe: qkcyqocqqwmqgqww: qqewoyookaskiuek: } iggyqogweyosuikc: return $ikgwqyuyckaewsow; } }
