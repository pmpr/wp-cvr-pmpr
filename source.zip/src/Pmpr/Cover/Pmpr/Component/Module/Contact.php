<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678a9fdb37aae             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Component\Module; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Cover\Pmpr\Container; class Contact extends Container { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x67\x65\164\137\x63\x6f\156\x74\x61\143\164\x5f\146\157\162\x6d\x5f\146\x69\145\154\x64\x73", [$this, "\x67\151\157\x6d\x67\141\171\151\161\145\x63\143\x67\141\145\x67"]); } public function giomgayiqeccgaeg($ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $aiowsaccomcoikus) { if ($aiowsaccomcoikus instanceof Field && Constants::iueeekcmggceyscu === $aiowsaccomcoikus->mwikyscisascoeea()) { $aiowsaccomcoikus->qigsyyqgewgskemg("\x62\164\156\x2d\160\x72\151\x6d\x61\162\x79\40\x68\157\166\145\162\55\157\165\164\x6c\151\156\x65\x20\x64\x2d\x66\x6c\x65\170"); } } return $ikgwqyuyckaewsow; } }
