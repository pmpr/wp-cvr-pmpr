<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc4b4e670e             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Component\Module; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Cover\Pmpr\Container; class Contact extends Container { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\147\x65\x74\x5f\143\x6f\x6e\x74\141\x63\164\137\146\x6f\162\x6d\137\x66\151\145\x6c\x64\163", [$this, "\x67\151\157\x6d\147\x61\171\151\x71\145\143\x63\x67\141\x65\147"]); } public function giomgayiqeccgaeg($ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $aiowsaccomcoikus) { if ($aiowsaccomcoikus instanceof Field && Constants::iueeekcmggceyscu === $aiowsaccomcoikus->mwikyscisascoeea()) { $aiowsaccomcoikus->qigsyyqgewgskemg("\142\164\x6e\55\x70\162\151\155\141\162\x79\x20\150\x6f\x76\x65\x72\55\x6f\x75\x74\154\151\x6e\145\x20\144\55\x66\154\x65\170"); } } return $ikgwqyuyckaewsow; } }
