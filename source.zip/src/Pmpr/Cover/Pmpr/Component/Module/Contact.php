<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668dab879d304             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Component\Module; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; class Contact extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x67\x65\164\x5f\143\157\x6e\x74\x61\143\164\137\x66\157\x72\x6d\x5f\146\x69\x65\154\144\x73", [$this, "\x67\151\x6f\x6d\147\x61\x79\x69\161\x65\143\x63\x67\x61\145\x67"]); } public function giomgayiqeccgaeg($ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $aiowsaccomcoikus) { if (!$aiowsaccomcoikus instanceof Field) { goto sciwggaeogcoesiu; } if (!(self::iueeekcmggceyscu === $aiowsaccomcoikus->mwikyscisascoeea())) { goto mkwskuycuyguqqok; } $aiowsaccomcoikus->qigsyyqgewgskemg("\x62\x74\x6e\x2d\x70\x72\x69\155\141\x72\171\x20\x68\x6f\166\x65\162\x2d\x6f\165\x74\154\x69\x6e\145\x20\x64\x2d\x66\154\145\170"); mkwskuycuyguqqok: sciwggaeogcoesiu: kuicqywysciceggs: } cuykwgmswkskqkyi: return $ikgwqyuyckaewsow; } }
