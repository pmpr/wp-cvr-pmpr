<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a2f440542e0             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Component\Module; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; class Contact extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\147\145\x74\137\143\x6f\x6e\164\x61\143\x74\x5f\x66\x6f\162\x6d\137\146\151\x65\x6c\144\163", [$this, "\147\x69\157\155\x67\141\171\151\161\x65\143\x63\x67\x61\145\x67"]); } public function giomgayiqeccgaeg($ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $aiowsaccomcoikus) { if (!$aiowsaccomcoikus instanceof Field) { goto kaiesowkgwogqseg; } if (!(self::iueeekcmggceyscu === $aiowsaccomcoikus->mwikyscisascoeea())) { goto egaymskkosukqeao; } $aiowsaccomcoikus->qigsyyqgewgskemg("\142\164\x6e\x2d\160\162\x69\x6d\x61\x72\x79\x20\x68\x6f\x76\145\x72\55\x6f\x75\x74\154\151\x6e\x65\40\x64\x2d\x66\154\145\x78"); egaymskkosukqeao: kaiesowkgwogqseg: cwikoaeqmmoimmso: } acggikioyeueeowg: return $ikgwqyuyckaewsow; } }
