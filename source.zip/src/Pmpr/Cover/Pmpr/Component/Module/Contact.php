<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66c7b6d27cadb             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Component\Module; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; class Contact extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x67\x65\x74\x5f\x63\x6f\156\x74\x61\143\164\x5f\146\x6f\162\x6d\137\x66\151\145\154\144\163", [$this, "\x67\151\157\x6d\x67\141\x79\151\x71\x65\x63\143\147\x61\x65\147"]); } public function giomgayiqeccgaeg($ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $aiowsaccomcoikus) { if (!$aiowsaccomcoikus instanceof Field) { goto suuskagowwgsouqw; } if (!(self::iueeekcmggceyscu === $aiowsaccomcoikus->mwikyscisascoeea())) { goto kgmeiwiakwicgkkk; } $aiowsaccomcoikus->qigsyyqgewgskemg("\x62\164\x6e\55\x70\162\151\155\141\x72\x79\40\150\x6f\166\145\162\x2d\157\x75\x74\x6c\x69\x6e\145\x20\144\x2d\x66\x6c\x65\170"); kgmeiwiakwicgkkk: suuskagowwgsouqw: cwswueuqoamqasya: } kicwiowcogmauwiy: return $ikgwqyuyckaewsow; } }
