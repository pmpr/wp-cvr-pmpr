<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ef50abe1cd3             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Component\Module; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; use Pmpr\Common\Foundation\Interfaces\Constants; class Contact extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\147\145\x74\137\x63\x6f\x6e\164\x61\143\164\137\146\x6f\x72\155\x5f\146\151\x65\x6c\x64\x73", [$this, "\147\x69\157\155\x67\141\x79\151\161\x65\143\143\x67\141\x65\x67"]); } public function giomgayiqeccgaeg($ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $aiowsaccomcoikus) { if (!($aiowsaccomcoikus instanceof Field && Constants::iueeekcmggceyscu === $aiowsaccomcoikus->mwikyscisascoeea())) { goto igooksugieceoege; } $aiowsaccomcoikus->qigsyyqgewgskemg("\142\x74\x6e\55\x70\162\x69\155\x61\162\171\x20\x68\157\x76\x65\x72\x2d\x6f\165\x74\x6c\x69\x6e\x65\x20\x64\x2d\x66\x6c\145\x78"); igooksugieceoege: cewmoqyysgsmuiya: } scisgsyemmsekgos: return $ikgwqyuyckaewsow; } }
