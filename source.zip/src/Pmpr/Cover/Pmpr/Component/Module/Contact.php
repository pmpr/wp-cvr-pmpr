<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6616500702db5             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Component\Module; use Pmpr\Common\Foundation\FormMaker\Front\Field\Field; class Contact extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x67\x65\164\x5f\143\157\x6e\x74\x61\143\164\x5f\146\x6f\x72\155\137\x66\x69\145\154\144\x73", [$this, "\147\151\x6f\155\x67\141\171\151\161\145\143\143\147\141\145\147"]); } public function giomgayiqeccgaeg($ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $aiowsaccomcoikus) { if (!$aiowsaccomcoikus instanceof Field) { goto ikuuiauwouuqawuw; } if (!(self::iueeekcmggceyscu === $aiowsaccomcoikus->mwikyscisascoeea())) { goto uckewycoogsogwiy; } $aiowsaccomcoikus->qigsyyqgewgskemg("\142\164\x6e\x2d\160\x72\151\x6d\x61\x72\x79\40\x68\157\166\145\x72\55\157\x75\164\154\x69\156\x65\x20\x64\x2d\146\154\x65\x78"); uckewycoogsogwiy: ikuuiauwouuqawuw: kwiggogcgciwuwqk: } yykqaowwsqgqysmq: return $ikgwqyuyckaewsow; } }
