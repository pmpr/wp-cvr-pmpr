<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66aeb5c87ae9b             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Component\Module; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; class Contact extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x67\145\x74\137\143\157\x6e\x74\141\143\x74\137\146\157\162\155\x5f\146\151\x65\154\144\163", [$this, "\x67\x69\157\155\x67\x61\171\151\161\x65\x63\143\x67\x61\145\147"]); } public function giomgayiqeccgaeg($ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $aiowsaccomcoikus) { if (!$aiowsaccomcoikus instanceof Field) { goto mogkoocsoeuyoqqa; } if (!(self::iueeekcmggceyscu === $aiowsaccomcoikus->mwikyscisascoeea())) { goto wsesqmcqoiyyqkqi; } $aiowsaccomcoikus->qigsyyqgewgskemg("\x62\x74\156\x2d\160\x72\151\155\141\x72\171\40\x68\157\x76\x65\x72\55\157\165\x74\x6c\x69\x6e\x65\x20\x64\55\146\x6c\145\x78"); wsesqmcqoiyyqkqi: mogkoocsoeuyoqqa: iesekaeqeomeuaui: } oyeyomcgkmgymogq: return $ikgwqyuyckaewsow; } }
