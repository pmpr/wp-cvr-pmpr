<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ced8515d92c             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Component\Module; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; use Pmpr\Common\Foundation\Interfaces\Constants; class Contact extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x67\145\x74\137\143\x6f\156\164\141\x63\164\137\x66\x6f\x72\155\x5f\146\151\x65\154\x64\163", [$this, "\147\x69\157\155\x67\141\x79\x69\x71\x65\x63\x63\147\x61\145\147"]); } public function giomgayiqeccgaeg($ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $aiowsaccomcoikus) { if (!($aiowsaccomcoikus instanceof Field && Constants::iueeekcmggceyscu === $aiowsaccomcoikus->mwikyscisascoeea())) { goto omykokikgocoikec; } $aiowsaccomcoikus->qigsyyqgewgskemg("\142\x74\x6e\x2d\160\162\151\x6d\x61\x72\x79\x20\x68\157\x76\145\162\x2d\157\165\x74\154\x69\x6e\x65\40\144\x2d\x66\x6c\145\x78"); omykokikgocoikec: suuskagowwgsouqw: } kgmeiwiakwicgkkk: return $ikgwqyuyckaewsow; } }
