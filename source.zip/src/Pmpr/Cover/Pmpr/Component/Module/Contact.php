<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4a92a54a5             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Component\Module; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Cover\Pmpr\Container; class Contact extends Container { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\147\x65\164\137\143\157\x6e\x74\x61\x63\164\x5f\x66\157\162\x6d\137\x66\x69\x65\x6c\144\163", [$this, "\147\151\157\155\x67\x61\171\151\x71\145\143\x63\147\141\145\147"]); } public function giomgayiqeccgaeg($ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $aiowsaccomcoikus) { if ($aiowsaccomcoikus instanceof Field && Constants::iueeekcmggceyscu === $aiowsaccomcoikus->mwikyscisascoeea()) { $aiowsaccomcoikus->qigsyyqgewgskemg("\x62\164\x6e\55\x70\x72\151\x6d\141\162\x79\x20\150\x6f\166\x65\x72\x2d\x6f\x75\x74\154\151\156\x65\x20\144\x2d\x66\154\145\170"); } } return $ikgwqyuyckaewsow; } }
