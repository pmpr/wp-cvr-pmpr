<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6634d46bd9359             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Component\Module; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; class Contact extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\147\x65\164\x5f\143\x6f\x6e\164\x61\x63\164\137\146\157\x72\155\137\146\x69\145\154\x64\x73", [$this, "\x67\x69\x6f\x6d\x67\x61\x79\x69\161\145\x63\x63\x67\141\x65\x67"]); } public function giomgayiqeccgaeg($ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $aiowsaccomcoikus) { if (!$aiowsaccomcoikus instanceof Field) { goto mceucsaeouuwyumm; } if (!(self::iueeekcmggceyscu === $aiowsaccomcoikus->mwikyscisascoeea())) { goto gkqiqaqecmoogmaa; } $aiowsaccomcoikus->qigsyyqgewgskemg("\x62\x74\156\55\160\x72\x69\x6d\x61\162\x79\40\x68\x6f\166\145\162\x2d\x6f\x75\164\x6c\x69\156\145\40\144\55\x66\154\x65\x78"); gkqiqaqecmoogmaa: mceucsaeouuwyumm: kwyimqumkuuyaiku: } mqimkwickkgqqeoi: return $ikgwqyuyckaewsow; } }
