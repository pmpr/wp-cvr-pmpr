<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665dd88caac68             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Component\Module; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; class Contact extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x67\145\x74\137\143\x6f\x6e\164\141\x63\x74\137\146\157\x72\x6d\137\146\x69\x65\x6c\144\x73", [$this, "\147\x69\x6f\155\x67\141\x79\x69\161\x65\x63\x63\x67\x61\145\x67"]); } public function giomgayiqeccgaeg($ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $aiowsaccomcoikus) { if (!$aiowsaccomcoikus instanceof Field) { goto suqcsgaosywaauuu; } if (!(self::iueeekcmggceyscu === $aiowsaccomcoikus->mwikyscisascoeea())) { goto mscgewkcqcoowweg; } $aiowsaccomcoikus->qigsyyqgewgskemg("\x62\164\x6e\x2d\160\162\x69\155\141\x72\171\x20\x68\x6f\x76\145\x72\55\157\x75\164\154\x69\156\145\40\144\x2d\146\154\145\170"); mscgewkcqcoowweg: suqcsgaosywaauuu: ikqeeaysmqgcgawq: } esaqcqqwuussiiwo: return $ikgwqyuyckaewsow; } }
