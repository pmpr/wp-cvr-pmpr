<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669eeba41d44c             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Component\Module; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; class Contact extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\147\x65\x74\137\x63\x6f\x6e\164\141\143\x74\x5f\x66\x6f\162\155\137\x66\151\x65\x6c\x64\x73", [$this, "\147\x69\x6f\x6d\x67\x61\x79\151\x71\x65\x63\x63\147\141\x65\147"]); } public function giomgayiqeccgaeg($ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $aiowsaccomcoikus) { if (!$aiowsaccomcoikus instanceof Field) { goto sciwggaeogcoesiu; } if (!(self::iueeekcmggceyscu === $aiowsaccomcoikus->mwikyscisascoeea())) { goto mkwskuycuyguqqok; } $aiowsaccomcoikus->qigsyyqgewgskemg("\142\x74\156\x2d\x70\162\x69\155\x61\x72\x79\x20\x68\157\166\x65\x72\x2d\157\165\x74\x6c\151\x6e\x65\40\x64\55\x66\154\x65\170"); mkwskuycuyguqqok: sciwggaeogcoesiu: kuicqywysciceggs: } cuykwgmswkskqkyi: return $ikgwqyuyckaewsow; } }
