<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6637dd982391a             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Component\Module; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; class Contact extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\147\x65\164\x5f\143\157\x6e\x74\141\143\x74\137\x66\x6f\x72\x6d\137\146\151\x65\154\x64\x73", [$this, "\147\151\157\x6d\147\x61\171\x69\x71\145\x63\x63\x67\x61\x65\147"]); } public function giomgayiqeccgaeg($ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $aiowsaccomcoikus) { if (!$aiowsaccomcoikus instanceof Field) { goto mceucsaeouuwyumm; } if (!(self::iueeekcmggceyscu === $aiowsaccomcoikus->mwikyscisascoeea())) { goto gkqiqaqecmoogmaa; } $aiowsaccomcoikus->qigsyyqgewgskemg("\x62\164\156\55\160\x72\151\x6d\x61\x72\171\x20\150\x6f\166\145\162\55\x6f\x75\164\154\151\156\145\40\x64\x2d\146\154\145\x78"); gkqiqaqecmoogmaa: mceucsaeouuwyumm: kwyimqumkuuyaiku: } mqimkwickkgqqeoi: return $ikgwqyuyckaewsow; } }
