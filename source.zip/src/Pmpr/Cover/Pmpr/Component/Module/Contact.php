<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d1dbc97f5c2             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Component\Module; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; use Pmpr\Common\Foundation\Interfaces\Constants; class Contact extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\147\x65\x74\x5f\x63\x6f\x6e\x74\141\x63\x74\x5f\146\x6f\x72\155\x5f\x66\x69\145\154\x64\163", [$this, "\147\x69\157\x6d\147\141\x79\151\161\145\143\143\x67\141\145\147"]); } public function giomgayiqeccgaeg($ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $aiowsaccomcoikus) { if (!($aiowsaccomcoikus instanceof Field && Constants::iueeekcmggceyscu === $aiowsaccomcoikus->mwikyscisascoeea())) { goto omykokikgocoikec; } $aiowsaccomcoikus->qigsyyqgewgskemg("\142\164\156\x2d\x70\x72\151\x6d\141\162\x79\x20\150\157\x76\145\162\x2d\157\165\x74\x6c\151\156\145\x20\144\55\146\154\145\x78"); omykokikgocoikec: suuskagowwgsouqw: } kgmeiwiakwicgkkk: return $ikgwqyuyckaewsow; } }
