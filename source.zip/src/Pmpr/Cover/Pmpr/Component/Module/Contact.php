<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665ec468a43fa             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Component\Module; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; class Contact extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x67\145\164\x5f\143\157\x6e\164\141\x63\164\x5f\146\x6f\162\155\x5f\146\x69\145\x6c\x64\163", [$this, "\147\151\157\155\147\141\x79\x69\x71\x65\x63\143\147\x61\145\x67"]); } public function giomgayiqeccgaeg($ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $aiowsaccomcoikus) { if (!$aiowsaccomcoikus instanceof Field) { goto qiiigwkqeoewsuwm; } if (!(self::iueeekcmggceyscu === $aiowsaccomcoikus->mwikyscisascoeea())) { goto okkmcocqokkskasy; } $aiowsaccomcoikus->qigsyyqgewgskemg("\x62\164\156\x2d\160\x72\151\x6d\x61\x72\171\x20\150\157\x76\x65\162\55\x6f\165\164\154\x69\156\145\40\x64\x2d\x66\x6c\145\170"); okkmcocqokkskasy: qiiigwkqeoewsuwm: esikeyqyuikmaiek: } iwsmmkqaoksmocok: return $ikgwqyuyckaewsow; } }
