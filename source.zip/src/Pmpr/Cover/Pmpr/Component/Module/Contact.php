<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b6bee3838             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Component\Module; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Cover\Pmpr\Container; class Contact extends Container { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x67\145\x74\x5f\143\157\x6e\164\x61\x63\164\x5f\146\157\162\155\x5f\146\x69\145\154\x64\x73", [$this, "\x67\x69\x6f\x6d\x67\x61\x79\151\161\x65\143\143\147\x61\x65\147"]); } public function giomgayiqeccgaeg($ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $aiowsaccomcoikus) { if ($aiowsaccomcoikus instanceof Field && Constants::iueeekcmggceyscu === $aiowsaccomcoikus->mwikyscisascoeea()) { $aiowsaccomcoikus->qigsyyqgewgskemg("\x62\x74\x6e\x2d\160\162\x69\155\141\x72\171\40\150\157\166\145\x72\55\x6f\x75\164\154\151\x6e\x65\40\144\x2d\146\154\145\x78"); } } return $ikgwqyuyckaewsow; } }
