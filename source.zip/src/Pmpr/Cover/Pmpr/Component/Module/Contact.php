<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665dbc49a1166             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Component\Module; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; class Contact extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x67\x65\x74\137\x63\x6f\156\x74\141\143\164\x5f\x66\x6f\x72\x6d\x5f\146\151\x65\154\x64\163", [$this, "\x67\x69\x6f\155\147\141\171\151\161\145\x63\143\147\141\x65\x67"]); } public function giomgayiqeccgaeg($ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $aiowsaccomcoikus) { if (!$aiowsaccomcoikus instanceof Field) { goto suqcsgaosywaauuu; } if (!(self::iueeekcmggceyscu === $aiowsaccomcoikus->mwikyscisascoeea())) { goto mscgewkcqcoowweg; } $aiowsaccomcoikus->qigsyyqgewgskemg("\142\164\x6e\x2d\x70\162\x69\x6d\x61\x72\x79\x20\150\157\166\145\162\55\157\165\164\154\x69\156\145\40\x64\55\x66\154\145\x78"); mscgewkcqcoowweg: suqcsgaosywaauuu: ikqeeaysmqgcgawq: } esaqcqqwuussiiwo: return $ikgwqyuyckaewsow; } }
