<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6714e17f99bf3             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Component\Module; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Cover\Pmpr\Container; class Contact extends Container { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x67\145\164\x5f\x63\157\156\164\141\x63\x74\137\x66\x6f\x72\x6d\x5f\146\151\145\x6c\x64\x73", [$this, "\x67\x69\157\155\x67\x61\x79\x69\x71\145\143\143\x67\x61\x65\147"]); } public function giomgayiqeccgaeg($ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $aiowsaccomcoikus) { if ($aiowsaccomcoikus instanceof Field && Constants::iueeekcmggceyscu === $aiowsaccomcoikus->mwikyscisascoeea()) { $aiowsaccomcoikus->qigsyyqgewgskemg("\142\164\156\55\x70\162\x69\155\x61\162\171\40\x68\157\x76\x65\x72\55\x6f\x75\x74\x6c\151\x6e\x65\x20\x64\x2d\x66\x6c\145\170"); } } return $ikgwqyuyckaewsow; } }
