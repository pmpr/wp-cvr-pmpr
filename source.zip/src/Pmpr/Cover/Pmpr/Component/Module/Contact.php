<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             675816101f185             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Component\Module; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Cover\Pmpr\Container; class Contact extends Container { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x67\145\164\x5f\x63\x6f\156\164\141\x63\x74\137\x66\x6f\x72\x6d\x5f\146\x69\x65\x6c\x64\x73", [$this, "\147\x69\x6f\155\x67\141\171\x69\161\x65\x63\x63\x67\x61\145\x67"]); } public function giomgayiqeccgaeg($ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $aiowsaccomcoikus) { if ($aiowsaccomcoikus instanceof Field && Constants::iueeekcmggceyscu === $aiowsaccomcoikus->mwikyscisascoeea()) { $aiowsaccomcoikus->qigsyyqgewgskemg("\x62\x74\x6e\55\x70\162\151\x6d\x61\162\171\x20\x68\x6f\x76\145\x72\55\x6f\x75\x74\154\x69\x6e\145\x20\144\x2d\x66\x6c\x65\x78"); } } return $ikgwqyuyckaewsow; } }
