<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6633b45bddf5b             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Component\Module; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; class Contact extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x67\x65\x74\137\143\x6f\x6e\x74\x61\143\x74\x5f\146\157\162\x6d\x5f\x66\x69\x65\x6c\144\163", [$this, "\x67\151\157\x6d\147\141\x79\x69\x71\145\143\x63\147\141\145\x67"]); } public function giomgayiqeccgaeg($ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $aiowsaccomcoikus) { if (!$aiowsaccomcoikus instanceof Field) { goto mceucsaeouuwyumm; } if (!(self::iueeekcmggceyscu === $aiowsaccomcoikus->mwikyscisascoeea())) { goto gkqiqaqecmoogmaa; } $aiowsaccomcoikus->qigsyyqgewgskemg("\142\x74\156\x2d\x70\x72\151\x6d\x61\x72\x79\x20\150\157\166\x65\x72\55\157\x75\x74\154\x69\156\145\x20\x64\x2d\x66\154\x65\x78"); gkqiqaqecmoogmaa: mceucsaeouuwyumm: kwyimqumkuuyaiku: } mqimkwickkgqqeoi: return $ikgwqyuyckaewsow; } }
