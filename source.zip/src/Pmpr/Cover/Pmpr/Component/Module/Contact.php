<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669d717e9761b             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Component\Module; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; class Contact extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x67\145\x74\x5f\x63\157\156\164\141\x63\x74\137\146\x6f\x72\155\137\146\151\145\x6c\144\x73", [$this, "\x67\x69\157\x6d\147\x61\171\x69\161\x65\x63\x63\x67\x61\145\x67"]); } public function giomgayiqeccgaeg($ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $aiowsaccomcoikus) { if (!$aiowsaccomcoikus instanceof Field) { goto sciwggaeogcoesiu; } if (!(self::iueeekcmggceyscu === $aiowsaccomcoikus->mwikyscisascoeea())) { goto mkwskuycuyguqqok; } $aiowsaccomcoikus->qigsyyqgewgskemg("\x62\x74\x6e\55\160\162\x69\x6d\x61\x72\x79\x20\x68\x6f\x76\145\162\x2d\157\x75\x74\x6c\x69\x6e\145\40\x64\x2d\146\154\x65\x78"); mkwskuycuyguqqok: sciwggaeogcoesiu: kuicqywysciceggs: } cuykwgmswkskqkyi: return $ikgwqyuyckaewsow; } }
