<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668c5b6675758             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Component\Module; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; class Contact extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x67\145\164\x5f\x63\x6f\x6e\x74\141\x63\x74\x5f\146\x6f\162\x6d\137\x66\151\x65\x6c\144\163", [$this, "\x67\151\157\x6d\x67\141\171\151\161\145\143\x63\147\x61\145\147"]); } public function giomgayiqeccgaeg($ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $aiowsaccomcoikus) { if (!$aiowsaccomcoikus instanceof Field) { goto qkcyqocqqwmqgqww; } if (!(self::iueeekcmggceyscu === $aiowsaccomcoikus->mwikyscisascoeea())) { goto ssoucoucsgccekwe; } $aiowsaccomcoikus->qigsyyqgewgskemg("\x62\164\x6e\55\x70\162\151\155\x61\162\x79\x20\x68\157\x76\x65\162\x2d\157\x75\x74\x6c\x69\156\145\40\x64\x2d\146\x6c\x65\170"); ssoucoucsgccekwe: qkcyqocqqwmqgqww: qqewoyookaskiuek: } iggyqogweyosuikc: return $ikgwqyuyckaewsow; } }
