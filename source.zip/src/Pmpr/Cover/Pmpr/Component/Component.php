<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661da299c54f1             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Component; use Pmpr\Cover\Pmpr\Component\Module\Module; use Pmpr\Cover\Pmpr\Container; class Component extends Container { public function mameiwsayuyquoeq() { Module::symcgieuakksimmu(); } }
