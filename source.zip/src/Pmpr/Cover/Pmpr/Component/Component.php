<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665e0f0c533e9             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Component; use Pmpr\Cover\Pmpr\Component\Module\Module; use Pmpr\Cover\Pmpr\Container; class Component extends Container { public function mameiwsayuyquoeq() { Module::symcgieuakksimmu(); } }
