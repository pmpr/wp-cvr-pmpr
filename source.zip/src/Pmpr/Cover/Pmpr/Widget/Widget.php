<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d8c776d9b3b             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Widget; use Pmpr\Cover\Pmpr\Container; class Widget extends Container { public function mameiwsayuyquoeq() { Advertise::symcgieuakksimmu(); } }
