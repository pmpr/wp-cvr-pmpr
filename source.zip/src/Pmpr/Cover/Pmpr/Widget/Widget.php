<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6681a8acaf4d8             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Widget; use Pmpr\Cover\Pmpr\Container; class Widget extends Container { public function mameiwsayuyquoeq() { Advertise::symcgieuakksimmu(); } }
