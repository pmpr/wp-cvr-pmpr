<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6634d46bd9359             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Widget; use Pmpr\Common\Foundation\Widget; abstract class Common extends Widget { }
