<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6686f085801e1             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Widget; use Pmpr\Common\Foundation\Widget; abstract class Common extends Widget { }
