<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66c31d3912e5b             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Widget; use Pmpr\Common\Foundation\Widget; abstract class Common extends Widget { }
