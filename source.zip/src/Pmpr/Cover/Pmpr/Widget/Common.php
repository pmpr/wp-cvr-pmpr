<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66c7b6d27cadb             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Widget; use Pmpr\Common\Foundation\Widget; abstract class Common extends Widget { }
