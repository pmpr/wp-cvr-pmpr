<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665c232750499             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; class AMP extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\141\155\x70\x5f\x6e\x61\166", [$this, "\x6e\153\171\x63\x73\167\x65\x69\x61\x67\x67\x75\x63\x73\x75\161"])->waqewsckuayqguos("\141\155\160\137\x68\145\x61\144\145\162\137\145\156\144", [$this, "\163\167\157\x71\x6d\x67\141\163\x79\157\x67\161\165\x6f\x65\157"]); } public function nkycsweiaggucsuq() { $this->ewcsyqaaigkicgse("\162\145\156\144\x65\162\x5f\154\157\x67\x6f", [self::waguuiqqgsysuukq => [180, 60], self::kicoscymgmgqeqgy => false, "\143\x6f\x6e\x74\141\x69\x6e\145\162\137\143\x6c\141\163\x73" => "\144\x2d\146\154\145\170\40\152\165\163\x74\x69\x66\171\x2d\143\x6f\156\164\x65\x6e\164\x2d\143\x65\x6e\164\145\162"]); } public function swoqmgasyogquoeo() { echo $this->iuygowkemiiwqmiw("\150\145\x61\x64\145\x72\137\145\156\x64", ["\156\157\x6e\145\137\141\155\x70" => __("\116\157\x6e\x65\40\x41\115\x50\40\x56\145\162\x73\151\157\x6e", PR__CVR__PMPR)]); } }
