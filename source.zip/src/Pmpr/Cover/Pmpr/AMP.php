<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66b6183f51930             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; class AMP extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\141\155\x70\x5f\156\141\x76", [$this, "\156\153\171\x63\163\x77\x65\151\x61\147\147\x75\143\x73\x75\161"])->waqewsckuayqguos("\141\x6d\160\x5f\x68\145\x61\x64\145\162\137\145\x6e\144", [$this, "\163\x77\157\x71\x6d\x67\x61\163\171\x6f\147\x71\x75\157\x65\157"]); } public function nkycsweiaggucsuq() { $this->ewcsyqaaigkicgse("\162\x65\x6e\144\x65\162\137\x6c\157\x67\x6f", [self::waguuiqqgsysuukq => [180, 60], self::kicoscymgmgqeqgy => false, "\x63\x6f\x6e\164\x61\x69\156\x65\x72\x5f\x63\154\141\x73\x73" => "\144\x2d\x66\x6c\145\170\40\x6a\165\163\x74\151\x66\x79\55\x63\157\x6e\164\x65\156\164\x2d\143\145\156\164\x65\162"]); } public function swoqmgasyogquoeo() { echo $this->iuygowkemiiwqmiw("\150\x65\141\x64\x65\x72\137\x65\156\144", ["\156\157\156\145\x5f\141\x6d\160" => __("\116\157\x6e\x65\40\x41\115\120\40\x56\x65\162\x73\151\157\x6e", PR__CVR__PMPR)]); } }
