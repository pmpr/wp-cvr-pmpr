<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66b9bf433b189             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; class AMP extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x61\155\x70\137\x6e\141\166", [$this, "\156\153\171\x63\163\x77\145\151\141\147\x67\x75\x63\x73\x75\161"])->waqewsckuayqguos("\141\x6d\160\137\x68\x65\141\x64\x65\162\137\145\156\144", [$this, "\x73\x77\157\x71\x6d\147\x61\163\171\x6f\147\x71\165\157\145\x6f"]); } public function nkycsweiaggucsuq() { $this->ewcsyqaaigkicgse("\162\145\x6e\x64\x65\162\137\154\x6f\x67\157", [self::waguuiqqgsysuukq => [180, 60], self::kicoscymgmgqeqgy => false, "\143\x6f\156\x74\141\151\156\x65\162\137\143\154\141\163\163" => "\144\x2d\x66\154\145\x78\40\x6a\x75\163\x74\151\x66\171\x2d\x63\x6f\x6e\x74\145\156\164\x2d\143\x65\x6e\164\x65\162"]); } public function swoqmgasyogquoeo() { echo $this->iuygowkemiiwqmiw("\x68\145\141\x64\145\x72\137\145\x6e\x64", ["\156\x6f\156\x65\137\x61\x6d\160" => __("\x4e\157\x6e\x65\x20\101\x4d\x50\x20\126\x65\162\x73\x69\x6f\x6e", PR__CVR__PMPR)]); } }
