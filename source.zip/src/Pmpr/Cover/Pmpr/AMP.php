<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669d5b84b76a1             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; class AMP extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\141\x6d\160\x5f\x6e\x61\166", [$this, "\156\x6b\171\143\163\167\x65\x69\141\x67\147\x75\x63\163\165\161"])->waqewsckuayqguos("\141\155\160\137\150\145\141\144\145\162\x5f\145\156\144", [$this, "\163\167\157\161\x6d\147\x61\x73\x79\x6f\147\x71\x75\x6f\145\x6f"]); } public function nkycsweiaggucsuq() { $this->ewcsyqaaigkicgse("\x72\x65\156\x64\145\162\x5f\x6c\x6f\147\157", [self::waguuiqqgsysuukq => [180, 60], self::kicoscymgmgqeqgy => false, "\x63\157\x6e\164\x61\x69\x6e\x65\x72\137\x63\x6c\141\163\163" => "\x64\x2d\x66\154\x65\170\40\x6a\165\163\x74\151\146\171\55\x63\x6f\156\x74\145\156\x74\55\x63\x65\x6e\x74\x65\162"]); } public function swoqmgasyogquoeo() { echo $this->iuygowkemiiwqmiw("\x68\x65\141\144\145\162\137\x65\156\144", ["\156\157\156\x65\137\141\x6d\x70" => __("\116\x6f\x6e\145\40\x41\x4d\x50\x20\x56\145\x72\163\151\x6f\156", PR__CVR__PMPR)]); } }
