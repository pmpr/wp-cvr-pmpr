<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6633b45bddf5b             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; class AMP extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\141\155\160\x5f\x6e\141\x76", [$this, "\156\x6b\171\143\x73\x77\x65\151\141\x67\147\x75\143\163\x75\161"])->waqewsckuayqguos("\x61\x6d\160\x5f\150\145\x61\x64\x65\x72\137\145\156\144", [$this, "\163\167\x6f\x71\155\x67\x61\x73\x79\x6f\147\x71\165\x6f\x65\x6f"]); } public function nkycsweiaggucsuq() { $this->ewcsyqaaigkicgse("\162\x65\156\x64\145\162\137\154\157\147\x6f", [self::waguuiqqgsysuukq => [180, 60], self::kicoscymgmgqeqgy => false, "\x63\x6f\x6e\x74\141\x69\156\x65\x72\137\143\x6c\x61\x73\163" => "\x64\55\x66\x6c\145\x78\x20\152\165\x73\164\151\146\171\55\x63\157\156\164\145\x6e\164\x2d\143\145\156\x74\145\162"]); } public function swoqmgasyogquoeo() { echo $this->iuygowkemiiwqmiw("\150\x65\x61\x64\145\162\x5f\145\156\144", ["\156\x6f\156\x65\x5f\141\x6d\160" => __("\x4e\157\x6e\x65\x20\101\x4d\120\x20\126\x65\162\x73\151\157\156", PR__CVR__PMPR)]); } }
