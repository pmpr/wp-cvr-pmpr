<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668f1c0882705             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; class AMP extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x61\x6d\160\137\156\x61\x76", [$this, "\x6e\x6b\x79\143\163\x77\145\151\x61\x67\147\165\143\163\x75\161"])->waqewsckuayqguos("\141\x6d\160\x5f\x68\x65\141\x64\x65\x72\x5f\x65\x6e\144", [$this, "\163\x77\x6f\161\x6d\147\x61\163\x79\157\147\161\x75\157\x65\x6f"]); } public function nkycsweiaggucsuq() { $this->ewcsyqaaigkicgse("\162\x65\x6e\144\x65\162\x5f\154\157\x67\157", [self::waguuiqqgsysuukq => [180, 60], self::kicoscymgmgqeqgy => false, "\x63\157\156\x74\x61\151\x6e\145\162\x5f\143\x6c\x61\x73\x73" => "\x64\x2d\x66\x6c\145\x78\x20\152\165\x73\x74\151\146\171\x2d\143\157\156\164\x65\x6e\164\x2d\x63\x65\156\x74\x65\x72"]); } public function swoqmgasyogquoeo() { echo $this->iuygowkemiiwqmiw("\x68\x65\141\144\145\x72\137\x65\x6e\144", ["\x6e\x6f\x6e\145\137\141\155\160" => __("\x4e\157\x6e\x65\x20\x41\115\x50\x20\126\x65\x72\163\x69\x6f\x6e", PR__CVR__PMPR)]); } }
