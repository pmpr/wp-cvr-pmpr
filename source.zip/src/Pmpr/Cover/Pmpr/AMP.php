<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6616500702db5             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; class AMP extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\141\x6d\x70\x5f\156\141\166", [$this, "\156\x6b\x79\x63\x73\167\145\151\x61\147\147\165\x63\163\x75\x71"])->waqewsckuayqguos("\141\x6d\160\x5f\150\x65\141\x64\x65\162\x5f\145\x6e\x64", [$this, "\163\167\157\x71\155\x67\x61\x73\171\157\147\161\x75\157\145\x6f"]); } public function nkycsweiaggucsuq() { $this->ewcsyqaaigkicgse("\x72\x65\156\144\x65\x72\x5f\154\157\147\157", [self::waguuiqqgsysuukq => [180, 60], self::kicoscymgmgqeqgy => false, "\x63\157\x6e\164\x61\151\x6e\x65\162\x5f\x63\154\x61\163\163" => "\144\x2d\146\x6c\145\x78\x20\x6a\x75\163\x74\151\x66\171\55\143\x6f\x6e\164\x65\156\x74\x2d\x63\x65\156\164\145\162"]); } public function swoqmgasyogquoeo() { echo $this->iuygowkemiiwqmiw("\150\145\141\x64\145\162\x5f\x65\x6e\x64", ["\x6e\x6f\156\145\137\x61\155\x70" => __("\x4e\x6f\x6e\x65\40\x41\x4d\120\40\x56\x65\162\x73\151\157\156", PR__CVR__PMPR)]); } }
