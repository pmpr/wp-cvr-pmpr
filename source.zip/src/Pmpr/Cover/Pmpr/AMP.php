<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6637344f0b8b9             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; class AMP extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x61\x6d\x70\137\156\141\166", [$this, "\x6e\x6b\x79\143\163\167\145\x69\141\x67\x67\165\x63\x73\x75\161"])->waqewsckuayqguos("\141\x6d\160\137\150\145\x61\x64\x65\x72\137\x65\x6e\x64", [$this, "\163\x77\x6f\x71\155\147\141\163\171\x6f\147\x71\x75\x6f\145\157"]); } public function nkycsweiaggucsuq() { $this->ewcsyqaaigkicgse("\x72\x65\x6e\x64\x65\162\x5f\x6c\157\x67\x6f", [self::waguuiqqgsysuukq => [180, 60], self::kicoscymgmgqeqgy => false, "\143\157\x6e\x74\141\x69\156\145\162\137\143\154\141\x73\163" => "\x64\55\146\154\x65\170\x20\152\x75\x73\x74\x69\146\x79\55\x63\157\x6e\164\145\156\164\55\143\x65\x6e\x74\145\162"]); } public function swoqmgasyogquoeo() { echo $this->iuygowkemiiwqmiw("\x68\145\x61\144\x65\162\137\x65\x6e\144", ["\156\x6f\x6e\x65\x5f\x61\155\160" => __("\116\157\156\x65\40\101\x4d\120\x20\126\145\x72\x73\151\x6f\x6e", PR__CVR__PMPR)]); } }
