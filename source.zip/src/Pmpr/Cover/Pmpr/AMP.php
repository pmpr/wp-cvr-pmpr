<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66c65f6c2d137             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; class AMP extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\141\155\160\x5f\156\x61\x76", [$this, "\x6e\x6b\171\143\163\167\145\151\x61\x67\147\165\143\163\165\161"])->waqewsckuayqguos("\141\x6d\160\x5f\x68\x65\141\x64\145\x72\137\x65\156\144", [$this, "\163\x77\157\x71\x6d\147\141\x73\x79\x6f\x67\x71\x75\157\145\157"]); } public function nkycsweiaggucsuq() { $this->ewcsyqaaigkicgse("\162\145\x6e\x64\x65\x72\137\154\x6f\x67\x6f", [self::waguuiqqgsysuukq => [180, 60], self::kicoscymgmgqeqgy => false, "\143\x6f\x6e\x74\x61\151\x6e\145\x72\137\143\154\141\x73\163" => "\144\55\x66\x6c\145\x78\40\152\x75\x73\x74\151\x66\x79\x2d\143\x6f\x6e\164\x65\x6e\x74\55\x63\x65\x6e\164\145\x72"]); } public function swoqmgasyogquoeo() { echo $this->iuygowkemiiwqmiw("\x68\145\141\144\145\x72\137\145\156\144", ["\x6e\x6f\156\x65\x5f\x61\155\160" => __("\116\157\156\145\x20\101\115\120\40\126\x65\x72\x73\x69\x6f\x6e", PR__CVR__PMPR)]); } }
