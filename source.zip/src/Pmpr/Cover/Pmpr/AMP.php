<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668c5b6675758             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; class AMP extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x61\155\160\x5f\x6e\141\166", [$this, "\156\x6b\x79\x63\163\167\x65\x69\141\x67\x67\165\x63\163\165\x71"])->waqewsckuayqguos("\x61\155\160\137\x68\x65\x61\x64\145\x72\137\145\x6e\x64", [$this, "\x73\x77\x6f\x71\x6d\x67\x61\x73\x79\157\147\x71\165\x6f\145\157"]); } public function nkycsweiaggucsuq() { $this->ewcsyqaaigkicgse("\x72\x65\x6e\x64\x65\x72\137\154\157\x67\x6f", [self::waguuiqqgsysuukq => [180, 60], self::kicoscymgmgqeqgy => false, "\x63\x6f\x6e\164\141\151\156\x65\x72\137\143\154\141\163\163" => "\144\55\x66\x6c\x65\x78\40\x6a\x75\163\x74\151\146\171\55\x63\157\156\164\145\x6e\164\55\x63\145\x6e\164\x65\x72"]); } public function swoqmgasyogquoeo() { echo $this->iuygowkemiiwqmiw("\150\145\x61\144\x65\x72\137\145\156\144", ["\x6e\157\156\x65\137\141\155\x70" => __("\x4e\157\x6e\x65\x20\x41\115\x50\x20\126\x65\162\163\x69\x6f\156", PR__CVR__PMPR)]); } }
