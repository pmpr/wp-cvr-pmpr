<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66812eb5d80af             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; class AMP extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x61\x6d\x70\x5f\156\x61\166", [$this, "\x6e\153\171\x63\163\167\145\x69\141\147\147\165\143\x73\165\161"])->waqewsckuayqguos("\x61\x6d\x70\137\150\x65\141\x64\x65\162\137\x65\156\x64", [$this, "\163\167\157\x71\x6d\147\141\163\x79\x6f\x67\161\x75\x6f\145\x6f"]); } public function nkycsweiaggucsuq() { $this->ewcsyqaaigkicgse("\162\145\x6e\144\x65\x72\x5f\x6c\157\147\157", [self::waguuiqqgsysuukq => [180, 60], self::kicoscymgmgqeqgy => false, "\143\x6f\x6e\x74\x61\151\156\145\162\x5f\x63\x6c\x61\x73\163" => "\x64\x2d\x66\x6c\x65\170\x20\x6a\x75\x73\x74\151\146\x79\55\143\157\156\x74\x65\156\x74\x2d\143\x65\x6e\x74\x65\162"]); } public function swoqmgasyogquoeo() { echo $this->iuygowkemiiwqmiw("\150\145\x61\144\145\x72\137\x65\x6e\144", ["\x6e\157\x6e\145\137\x61\x6d\160" => __("\116\157\156\145\x20\101\x4d\x50\40\x56\x65\162\163\x69\x6f\156", PR__CVR__PMPR)]); } }
