<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669c49f78f111             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; class AMP extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\141\x6d\160\137\x6e\x61\x76", [$this, "\156\153\x79\143\x73\x77\145\151\141\147\x67\165\143\x73\165\161"])->waqewsckuayqguos("\x61\155\160\x5f\x68\x65\141\x64\x65\x72\x5f\x65\156\144", [$this, "\163\x77\157\161\x6d\x67\x61\163\x79\157\x67\x71\x75\157\145\x6f"]); } public function nkycsweiaggucsuq() { $this->ewcsyqaaigkicgse("\x72\x65\x6e\x64\x65\x72\x5f\x6c\157\147\x6f", [self::waguuiqqgsysuukq => [180, 60], self::kicoscymgmgqeqgy => false, "\x63\x6f\x6e\x74\x61\151\156\145\162\x5f\x63\154\x61\163\163" => "\x64\55\146\154\145\170\40\152\165\163\164\x69\146\171\55\x63\157\x6e\x74\145\156\164\55\143\145\x6e\x74\x65\x72"]); } public function swoqmgasyogquoeo() { echo $this->iuygowkemiiwqmiw("\150\x65\141\x64\x65\x72\x5f\145\x6e\144", ["\x6e\x6f\x6e\x65\137\x61\155\x70" => __("\116\x6f\x6e\145\40\101\x4d\120\40\x56\x65\x72\163\151\x6f\x6e", PR__CVR__PMPR)]); } }
