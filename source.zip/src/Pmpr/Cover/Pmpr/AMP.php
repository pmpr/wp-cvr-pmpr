<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ced9b261c92             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; use Pmpr\Common\Foundation\Interfaces\Constants; class AMP extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x61\x6d\x70\x5f\156\x61\166", [$this, "\156\x6b\171\143\x73\x77\145\151\x61\147\147\x75\x63\x73\165\161"])->waqewsckuayqguos("\x61\x6d\160\x5f\x68\x65\x61\144\x65\162\x5f\x65\x6e\144", [$this, "\x73\167\157\x71\x6d\147\x61\163\171\157\147\161\x75\x6f\145\x6f"]); } public function nkycsweiaggucsuq() { $this->ewcsyqaaigkicgse("\162\x65\x6e\x64\x65\162\137\x6c\157\x67\x6f", [Constants::waguuiqqgsysuukq => [180, 60], Constants::kicoscymgmgqeqgy => false, "\x63\157\156\x74\x61\151\156\145\162\137\x63\x6c\141\x73\163" => "\x64\x2d\146\154\145\x78\x20\152\165\163\164\x69\x66\171\x2d\x63\x6f\156\164\x65\x6e\164\x2d\x63\145\x6e\164\x65\x72"]); } public function swoqmgasyogquoeo() { echo $this->iuygowkemiiwqmiw("\x68\x65\x61\144\x65\x72\x5f\x65\x6e\x64", ["\x6e\x6f\156\x65\137\x61\x6d\160" => __("\116\157\156\x65\40\101\115\120\x20\126\x65\162\x73\151\157\x6e", PR__CVR__PMPR)]); } }
