<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668707cdd97fe             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; class AMP extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x61\x6d\160\x5f\x6e\x61\x76", [$this, "\156\x6b\171\143\x73\x77\145\x69\x61\147\x67\x75\x63\163\x75\161"])->waqewsckuayqguos("\x61\x6d\160\137\150\145\x61\144\x65\162\137\x65\x6e\x64", [$this, "\163\x77\157\161\x6d\x67\141\x73\171\157\x67\161\x75\x6f\x65\x6f"]); } public function nkycsweiaggucsuq() { $this->ewcsyqaaigkicgse("\162\145\156\x64\x65\x72\137\154\x6f\147\157", [self::waguuiqqgsysuukq => [180, 60], self::kicoscymgmgqeqgy => false, "\143\157\156\x74\x61\151\156\145\x72\137\143\154\x61\163\163" => "\144\55\146\x6c\145\170\40\152\x75\x73\164\151\x66\171\55\143\157\156\164\145\156\x74\x2d\143\x65\x6e\x74\145\x72"]); } public function swoqmgasyogquoeo() { echo $this->iuygowkemiiwqmiw("\150\145\x61\x64\145\x72\x5f\145\156\x64", ["\x6e\157\156\145\137\141\x6d\x70" => __("\x4e\157\156\x65\x20\101\x4d\120\x20\x56\x65\x72\163\x69\x6f\x6e", PR__CVR__PMPR)]); } }
