<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             675816101f185             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; use Pmpr\Common\Foundation\Interfaces\Constants; class AMP extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x61\x6d\160\137\156\x61\x76", [$this, "\156\153\x79\x63\x73\167\145\x69\x61\147\x67\165\143\163\165\161"])->waqewsckuayqguos("\141\x6d\160\x5f\x68\x65\x61\144\145\x72\x5f\x65\156\x64", [$this, "\x73\167\x6f\161\155\x67\x61\x73\x79\157\x67\x71\x75\x6f\145\157"]); } public function nkycsweiaggucsuq() { $this->ewcsyqaaigkicgse("\162\145\x6e\144\x65\162\x5f\x6c\x6f\147\157", [Constants::waguuiqqgsysuukq => [180, 60], Constants::kicoscymgmgqeqgy => false, "\x63\x6f\156\x74\x61\151\x6e\145\x72\x5f\143\x6c\141\x73\x73" => "\144\55\146\154\145\x78\40\x6a\165\x73\x74\x69\146\x79\55\143\x6f\x6e\x74\x65\x6e\164\x2d\143\145\156\164\145\x72"]); } public function swoqmgasyogquoeo() { echo $this->iuygowkemiiwqmiw("\x68\x65\x61\x64\145\162\x5f\x65\x6e\x64", ["\x6e\x6f\156\145\x5f\141\155\160" => __("\x4e\157\x6e\145\x20\101\115\x50\40\126\145\162\163\x69\x6f\156", PR__CVR__PMPR)]); } }
