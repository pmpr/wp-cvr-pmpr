<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4a92a54a5             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; use Pmpr\Common\Foundation\Interfaces\Constants; class AMP extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x61\x6d\x70\137\156\x61\x76", [$this, "\156\x6b\171\x63\x73\167\145\x69\141\x67\x67\165\143\163\165\161"])->waqewsckuayqguos("\141\155\x70\x5f\x68\x65\x61\x64\x65\162\x5f\145\156\144", [$this, "\x73\x77\157\161\155\147\141\x73\171\x6f\x67\161\x75\x6f\x65\x6f"]); } public function nkycsweiaggucsuq() { $this->ewcsyqaaigkicgse("\x72\x65\156\144\145\162\137\x6c\x6f\147\x6f", [Constants::waguuiqqgsysuukq => [180, 60], Constants::kicoscymgmgqeqgy => false, "\x63\x6f\x6e\x74\x61\151\x6e\145\162\137\143\x6c\141\163\x73" => "\x64\x2d\x66\154\x65\x78\40\x6a\165\x73\x74\x69\x66\x79\55\143\x6f\156\x74\x65\x6e\164\x2d\143\x65\x6e\164\x65\x72"]); } public function swoqmgasyogquoeo() { echo $this->iuygowkemiiwqmiw("\x68\145\141\x64\x65\162\x5f\145\156\x64", ["\156\157\156\x65\x5f\141\155\x70" => __("\x4e\x6f\x6e\x65\x20\x41\x4d\120\x20\x56\x65\162\163\x69\x6f\156", PR__CVR__PMPR)]); } }
