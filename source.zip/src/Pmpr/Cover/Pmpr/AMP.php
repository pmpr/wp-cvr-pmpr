<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a42a72b7b43             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; class AMP extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\141\155\x70\137\156\141\166", [$this, "\156\153\x79\143\163\167\x65\x69\141\147\147\165\143\x73\165\x71"])->waqewsckuayqguos("\141\155\160\137\x68\145\x61\144\145\x72\x5f\x65\x6e\x64", [$this, "\163\x77\x6f\161\x6d\147\141\x73\171\157\147\x71\165\x6f\145\157"]); } public function nkycsweiaggucsuq() { $this->ewcsyqaaigkicgse("\162\x65\156\144\x65\162\137\x6c\157\x67\157", [self::waguuiqqgsysuukq => [180, 60], self::kicoscymgmgqeqgy => false, "\x63\157\x6e\164\x61\151\x6e\145\x72\137\x63\x6c\141\x73\x73" => "\x64\55\x66\154\x65\x78\40\x6a\165\x73\164\x69\146\171\x2d\143\x6f\x6e\164\x65\156\x74\x2d\143\145\156\x74\x65\162"]); } public function swoqmgasyogquoeo() { echo $this->iuygowkemiiwqmiw("\x68\x65\x61\144\x65\162\137\145\x6e\144", ["\156\x6f\156\x65\x5f\141\x6d\160" => __("\x4e\157\156\145\40\x41\x4d\120\x20\x56\x65\x72\x73\151\x6f\156", PR__CVR__PMPR)]); } }
