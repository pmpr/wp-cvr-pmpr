<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ef50abe1cd3             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; use Pmpr\Common\Foundation\Interfaces\Constants; class AMP extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\141\155\160\x5f\156\141\166", [$this, "\x6e\x6b\171\x63\163\x77\145\151\141\x67\x67\x75\143\x73\x75\x71"])->waqewsckuayqguos("\x61\x6d\160\137\x68\x65\141\144\x65\x72\x5f\145\156\x64", [$this, "\163\x77\157\x71\x6d\147\141\163\x79\x6f\147\161\x75\157\145\157"]); } public function nkycsweiaggucsuq() { $this->ewcsyqaaigkicgse("\x72\x65\x6e\x64\145\162\x5f\154\x6f\x67\157", [Constants::waguuiqqgsysuukq => [180, 60], Constants::kicoscymgmgqeqgy => false, "\x63\157\x6e\164\141\x69\156\x65\162\x5f\x63\154\141\x73\x73" => "\x64\55\146\154\x65\170\x20\152\165\163\164\x69\146\171\x2d\143\157\x6e\x74\x65\x6e\x74\x2d\143\x65\x6e\x74\145\x72"]); } public function swoqmgasyogquoeo() { echo $this->iuygowkemiiwqmiw("\150\x65\x61\x64\145\162\x5f\x65\156\144", ["\x6e\157\156\145\x5f\x61\x6d\x70" => __("\116\x6f\x6e\x65\40\x41\115\x50\x20\126\x65\162\163\x69\x6f\156", PR__CVR__PMPR)]); } }
