<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665dd88caac68             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; class AMP extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\141\155\x70\x5f\156\141\x76", [$this, "\156\x6b\x79\x63\163\x77\145\151\x61\147\147\x75\143\163\x75\x71"])->waqewsckuayqguos("\141\x6d\x70\x5f\x68\145\x61\144\145\162\x5f\145\156\144", [$this, "\163\x77\x6f\161\x6d\147\x61\x73\171\x6f\147\161\165\157\145\x6f"]); } public function nkycsweiaggucsuq() { $this->ewcsyqaaigkicgse("\x72\x65\156\x64\x65\162\137\154\157\147\x6f", [self::waguuiqqgsysuukq => [180, 60], self::kicoscymgmgqeqgy => false, "\143\x6f\x6e\164\x61\151\x6e\x65\x72\137\x63\x6c\x61\x73\163" => "\144\x2d\x66\x6c\145\170\40\152\165\x73\164\151\146\171\x2d\x63\157\x6e\x74\145\x6e\164\55\x63\145\x6e\164\x65\162"]); } public function swoqmgasyogquoeo() { echo $this->iuygowkemiiwqmiw("\x68\145\141\144\x65\x72\x5f\145\x6e\144", ["\156\x6f\x6e\x65\x5f\141\x6d\x70" => __("\x4e\157\x6e\x65\40\101\115\x50\40\126\x65\x72\x73\x69\157\156", PR__CVR__PMPR)]); } }
