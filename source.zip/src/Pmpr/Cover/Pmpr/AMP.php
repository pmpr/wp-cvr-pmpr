<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6681a8acaf4d8             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; class AMP extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\141\155\160\137\x6e\x61\x76", [$this, "\x6e\x6b\171\143\x73\x77\145\151\141\147\147\x75\x63\163\165\x71"])->waqewsckuayqguos("\x61\x6d\160\x5f\150\145\141\144\x65\162\137\145\x6e\144", [$this, "\x73\x77\x6f\161\x6d\x67\141\163\171\157\x67\161\165\x6f\145\157"]); } public function nkycsweiaggucsuq() { $this->ewcsyqaaigkicgse("\162\145\156\x64\145\162\x5f\154\157\147\157", [self::waguuiqqgsysuukq => [180, 60], self::kicoscymgmgqeqgy => false, "\143\157\156\164\x61\x69\x6e\x65\162\137\x63\x6c\x61\x73\x73" => "\144\x2d\146\154\x65\170\x20\152\165\x73\x74\x69\x66\171\x2d\143\x6f\x6e\164\145\156\x74\55\143\x65\156\x74\x65\x72"]); } public function swoqmgasyogquoeo() { echo $this->iuygowkemiiwqmiw("\x68\145\141\x64\145\162\x5f\x65\x6e\x64", ["\156\x6f\156\145\137\141\155\160" => __("\x4e\x6f\156\x65\x20\101\x4d\120\x20\126\x65\162\163\x69\x6f\156", PR__CVR__PMPR)]); } }
