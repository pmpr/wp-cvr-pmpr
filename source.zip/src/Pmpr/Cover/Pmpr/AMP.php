<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67581a8b7701f             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; use Pmpr\Common\Foundation\Interfaces\Constants; class AMP extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\141\155\160\x5f\x6e\x61\x76", [$this, "\156\x6b\171\143\163\167\145\151\141\147\x67\x75\x63\x73\165\161"])->waqewsckuayqguos("\141\155\x70\137\150\x65\141\x64\x65\162\x5f\x65\x6e\x64", [$this, "\163\167\157\161\x6d\x67\141\x73\x79\157\147\161\x75\x6f\x65\157"]); } public function nkycsweiaggucsuq() { $this->ewcsyqaaigkicgse("\162\145\156\x64\145\162\137\154\x6f\147\x6f", [Constants::waguuiqqgsysuukq => [180, 60], Constants::kicoscymgmgqeqgy => false, "\x63\x6f\156\164\x61\x69\156\x65\162\137\143\154\141\x73\163" => "\144\55\146\x6c\x65\170\x20\x6a\165\163\164\151\146\171\x2d\143\157\x6e\164\145\x6e\164\55\x63\145\156\164\145\162"]); } public function swoqmgasyogquoeo() { echo $this->iuygowkemiiwqmiw("\x68\145\141\144\145\162\137\x65\156\144", ["\156\x6f\x6e\145\137\141\155\160" => __("\x4e\x6f\x6e\145\x20\101\115\120\40\126\x65\162\x73\x69\157\156", PR__CVR__PMPR)]); } }
