<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669c358f62566             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; class AMP extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x61\155\x70\x5f\156\141\x76", [$this, "\156\x6b\171\143\163\167\x65\151\x61\x67\147\x75\x63\x73\x75\161"])->waqewsckuayqguos("\141\x6d\x70\x5f\x68\x65\141\144\145\162\x5f\145\x6e\144", [$this, "\163\167\x6f\x71\155\147\x61\x73\x79\157\x67\161\165\157\x65\x6f"]); } public function nkycsweiaggucsuq() { $this->ewcsyqaaigkicgse("\x72\x65\156\x64\x65\x72\137\x6c\x6f\x67\x6f", [self::waguuiqqgsysuukq => [180, 60], self::kicoscymgmgqeqgy => false, "\x63\157\156\x74\141\x69\156\x65\x72\137\x63\x6c\141\x73\163" => "\144\x2d\146\x6c\145\170\40\x6a\x75\x73\164\151\x66\x79\55\x63\157\x6e\164\145\156\x74\x2d\x63\145\x6e\x74\145\x72"]); } public function swoqmgasyogquoeo() { echo $this->iuygowkemiiwqmiw("\150\x65\x61\x64\x65\x72\x5f\x65\x6e\x64", ["\156\157\x6e\145\137\141\x6d\x70" => __("\x4e\x6f\156\145\40\x41\x4d\x50\40\x56\x65\x72\x73\x69\x6f\x6e", PR__CVR__PMPR)]); } }
