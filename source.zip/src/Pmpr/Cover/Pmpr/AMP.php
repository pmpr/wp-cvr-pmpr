<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6686f085801e1             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; class AMP extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x61\x6d\x70\137\x6e\x61\166", [$this, "\156\x6b\171\x63\x73\167\x65\151\x61\x67\147\x75\143\163\x75\161"])->waqewsckuayqguos("\x61\155\160\x5f\x68\x65\x61\x64\145\x72\x5f\x65\156\144", [$this, "\x73\x77\x6f\x71\x6d\147\x61\x73\x79\157\x67\161\x75\157\145\x6f"]); } public function nkycsweiaggucsuq() { $this->ewcsyqaaigkicgse("\162\145\156\144\145\162\x5f\154\157\x67\157", [self::waguuiqqgsysuukq => [180, 60], self::kicoscymgmgqeqgy => false, "\x63\x6f\156\164\141\151\156\145\162\137\143\x6c\x61\x73\x73" => "\144\x2d\x66\154\145\170\x20\152\x75\163\164\151\x66\171\x2d\143\157\156\164\x65\156\x74\55\143\145\156\164\x65\x72"]); } public function swoqmgasyogquoeo() { echo $this->iuygowkemiiwqmiw("\x68\145\x61\x64\x65\162\137\145\156\144", ["\x6e\157\156\x65\137\x61\x6d\x70" => __("\116\157\x6e\145\x20\x41\x4d\x50\40\126\x65\162\x73\151\x6f\x6e", PR__CVR__PMPR)]); } }
