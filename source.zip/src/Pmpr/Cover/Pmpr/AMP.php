<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce6cb67dbd5             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; use Pmpr\Common\Foundation\Interfaces\Constants; class AMP extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\141\x6d\x70\x5f\156\x61\x76", [$this, "\156\153\x79\x63\x73\x77\145\151\141\x67\147\165\x63\x73\165\161"])->waqewsckuayqguos("\x61\155\160\x5f\150\x65\141\144\145\x72\x5f\145\x6e\144", [$this, "\x73\x77\x6f\161\155\147\141\163\171\157\x67\x71\165\x6f\145\157"]); } public function nkycsweiaggucsuq() { $this->ewcsyqaaigkicgse("\x72\145\156\x64\145\x72\137\154\157\147\x6f", [Constants::waguuiqqgsysuukq => [180, 60], Constants::kicoscymgmgqeqgy => false, "\143\157\x6e\164\141\151\x6e\145\x72\x5f\x63\x6c\141\x73\x73" => "\144\x2d\x66\x6c\145\x78\x20\x6a\x75\x73\x74\x69\146\x79\55\143\x6f\156\x74\x65\156\164\x2d\143\x65\156\164\x65\162"]); } public function swoqmgasyogquoeo() { echo $this->iuygowkemiiwqmiw("\150\145\141\144\x65\162\x5f\145\156\x64", ["\x6e\157\x6e\x65\x5f\141\x6d\160" => __("\116\157\x6e\x65\40\x41\115\x50\x20\x56\145\162\163\x69\157\156", PR__CVR__PMPR)]); } }
