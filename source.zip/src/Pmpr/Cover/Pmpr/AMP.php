<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66aeb5c87ae9b             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; class AMP extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\141\x6d\x70\137\156\x61\166", [$this, "\x6e\x6b\171\143\163\x77\x65\x69\141\147\x67\165\x63\163\x75\x71"])->waqewsckuayqguos("\141\x6d\x70\137\150\x65\141\x64\145\162\x5f\145\x6e\x64", [$this, "\163\x77\157\161\155\147\x61\163\x79\157\x67\161\165\157\145\157"]); } public function nkycsweiaggucsuq() { $this->ewcsyqaaigkicgse("\162\145\156\144\x65\x72\137\154\x6f\x67\157", [self::waguuiqqgsysuukq => [180, 60], self::kicoscymgmgqeqgy => false, "\143\157\x6e\164\141\x69\x6e\x65\x72\x5f\x63\x6c\x61\x73\x73" => "\144\55\146\x6c\145\x78\x20\x6a\x75\x73\164\151\x66\171\x2d\143\x6f\156\x74\145\156\164\x2d\143\x65\156\x74\145\162"]); } public function swoqmgasyogquoeo() { echo $this->iuygowkemiiwqmiw("\x68\145\141\144\x65\162\137\x65\156\144", ["\156\x6f\x6e\x65\137\141\155\160" => __("\x4e\x6f\156\145\x20\x41\x4d\x50\40\x56\145\162\x73\151\157\x6e", PR__CVR__PMPR)]); } }
