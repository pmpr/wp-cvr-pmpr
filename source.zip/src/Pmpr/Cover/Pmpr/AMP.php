<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b6bee3838             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; use Pmpr\Common\Foundation\Interfaces\Constants; class AMP extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\141\x6d\160\x5f\156\x61\x76", [$this, "\156\x6b\171\x63\x73\x77\145\151\141\x67\147\x75\x63\163\165\x71"])->waqewsckuayqguos("\x61\x6d\x70\137\x68\x65\141\x64\145\x72\x5f\x65\156\x64", [$this, "\x73\167\157\161\x6d\x67\141\163\x79\x6f\147\161\x75\157\x65\157"]); } public function nkycsweiaggucsuq() { $this->ewcsyqaaigkicgse("\162\x65\156\x64\x65\162\137\x6c\x6f\x67\x6f", [Constants::waguuiqqgsysuukq => [180, 60], Constants::kicoscymgmgqeqgy => false, "\143\x6f\156\164\x61\151\156\x65\162\x5f\143\x6c\x61\163\163" => "\x64\55\x66\154\x65\x78\x20\x6a\x75\163\164\x69\x66\x79\x2d\143\157\x6e\x74\x65\x6e\164\55\143\x65\156\x74\145\162"]); } public function swoqmgasyogquoeo() { echo $this->iuygowkemiiwqmiw("\x68\x65\141\144\145\162\137\x65\x6e\144", ["\156\x6f\156\145\137\x61\x6d\160" => __("\x4e\157\156\x65\40\x41\x4d\120\x20\126\x65\x72\x73\151\x6f\156", PR__CVR__PMPR)]); } }
