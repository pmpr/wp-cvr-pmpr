<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d8c776d9b3b             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; use Pmpr\Common\Foundation\Interfaces\Constants; class AMP extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x61\x6d\x70\x5f\x6e\141\166", [$this, "\156\x6b\x79\143\x73\167\145\x69\141\147\x67\x75\143\x73\165\x71"])->waqewsckuayqguos("\141\155\160\137\150\145\x61\x64\x65\162\137\145\x6e\144", [$this, "\x73\x77\x6f\161\x6d\147\x61\163\171\157\147\x71\x75\157\145\x6f"]); } public function nkycsweiaggucsuq() { $this->ewcsyqaaigkicgse("\x72\145\x6e\x64\145\x72\137\154\157\x67\157", [Constants::waguuiqqgsysuukq => [180, 60], Constants::kicoscymgmgqeqgy => false, "\143\157\156\x74\x61\151\156\145\x72\x5f\x63\154\x61\163\163" => "\x64\x2d\146\154\145\x78\40\x6a\x75\x73\164\x69\x66\x79\x2d\x63\x6f\156\164\x65\x6e\x74\x2d\x63\x65\156\164\145\162"]); } public function swoqmgasyogquoeo() { echo $this->iuygowkemiiwqmiw("\x68\145\x61\144\x65\x72\x5f\x65\156\x64", ["\x6e\157\x6e\x65\x5f\141\155\x70" => __("\x4e\x6f\156\x65\40\x41\115\120\40\x56\145\162\x73\x69\x6f\156", PR__CVR__PMPR)]); } }
