<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669ada6f97df7             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; class AMP extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x61\155\160\137\156\x61\x76", [$this, "\x6e\153\171\x63\163\x77\145\151\141\147\x67\165\x63\x73\x75\161"])->waqewsckuayqguos("\141\x6d\160\x5f\x68\145\141\144\145\x72\137\145\x6e\144", [$this, "\163\x77\x6f\x71\155\x67\x61\163\x79\157\147\x71\165\x6f\x65\x6f"]); } public function nkycsweiaggucsuq() { $this->ewcsyqaaigkicgse("\162\x65\x6e\144\x65\162\137\154\x6f\x67\157", [self::waguuiqqgsysuukq => [180, 60], self::kicoscymgmgqeqgy => false, "\x63\x6f\x6e\x74\x61\151\x6e\x65\162\137\143\154\141\x73\163" => "\x64\x2d\x66\154\x65\170\x20\152\x75\x73\164\151\x66\x79\55\143\x6f\x6e\164\145\x6e\164\55\143\x65\156\x74\x65\x72"]); } public function swoqmgasyogquoeo() { echo $this->iuygowkemiiwqmiw("\x68\145\x61\144\x65\162\137\145\x6e\x64", ["\x6e\157\x6e\x65\137\141\x6d\x70" => __("\116\157\156\x65\40\x41\x4d\x50\x20\x56\x65\162\163\x69\157\156", PR__CVR__PMPR)]); } }
