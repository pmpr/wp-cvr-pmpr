<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669d717e9761b             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; class AMP extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x61\x6d\x70\x5f\156\x61\x76", [$this, "\156\x6b\171\143\x73\167\x65\151\x61\147\x67\165\143\x73\165\x71"])->waqewsckuayqguos("\141\155\160\137\150\x65\141\x64\x65\x72\137\145\x6e\x64", [$this, "\163\167\x6f\x71\x6d\147\141\163\171\x6f\147\161\165\157\145\x6f"]); } public function nkycsweiaggucsuq() { $this->ewcsyqaaigkicgse("\x72\x65\x6e\144\x65\x72\137\154\x6f\147\x6f", [self::waguuiqqgsysuukq => [180, 60], self::kicoscymgmgqeqgy => false, "\143\157\x6e\x74\141\x69\x6e\145\162\x5f\143\x6c\x61\163\x73" => "\x64\55\x66\154\145\170\40\x6a\165\163\x74\151\146\x79\55\x63\x6f\156\164\145\x6e\164\55\143\x65\156\164\x65\x72"]); } public function swoqmgasyogquoeo() { echo $this->iuygowkemiiwqmiw("\x68\x65\141\144\145\x72\x5f\145\x6e\x64", ["\156\x6f\x6e\x65\x5f\141\x6d\160" => __("\116\x6f\x6e\x65\x20\101\115\x50\x20\x56\145\x72\x73\x69\157\x6e", PR__CVR__PMPR)]); } }
