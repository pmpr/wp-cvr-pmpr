<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68e59ec395f62             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; use Pmpr\Common\Foundation\Interfaces\Constants; class AMP extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos('amp_nav', [$this, 'nkycsweiaggucsuq'])->waqewsckuayqguos('amp_header_end', [$this, 'swoqmgasyogquoeo']); } public function nkycsweiaggucsuq() { $this->ewcsyqaaigkicgse('render_logo', [Constants::waguuiqqgsysuukq => [180, 60], Constants::kicoscymgmgqeqgy => false, 'container_class' => 'd-flex justify-content-center']); } public function swoqmgasyogquoeo() { echo $this->iuygowkemiiwqmiw('header_end', ['none_amp' => __('None AMP Version', PR__CVR__PMPR)]); } }
