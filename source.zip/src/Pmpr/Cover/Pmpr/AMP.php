<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc4b4e670e             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; use Pmpr\Common\Foundation\Interfaces\Constants; class AMP extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\141\x6d\160\137\156\141\166", [$this, "\156\x6b\x79\x63\x73\x77\145\151\x61\147\x67\165\143\x73\165\x71"])->waqewsckuayqguos("\141\x6d\160\x5f\x68\x65\x61\144\145\162\137\145\x6e\144", [$this, "\x73\x77\157\161\x6d\x67\x61\x73\x79\x6f\x67\161\x75\x6f\x65\157"]); } public function nkycsweiaggucsuq() { $this->ewcsyqaaigkicgse("\162\x65\156\x64\x65\162\137\x6c\x6f\147\x6f", [Constants::waguuiqqgsysuukq => [180, 60], Constants::kicoscymgmgqeqgy => false, "\143\157\156\x74\x61\x69\156\145\x72\137\x63\154\x61\163\x73" => "\144\55\x66\x6c\x65\x78\x20\x6a\165\163\164\151\x66\171\x2d\x63\157\156\x74\x65\156\164\55\143\x65\x6e\164\x65\162"]); } public function swoqmgasyogquoeo() { echo $this->iuygowkemiiwqmiw("\x68\x65\x61\144\145\x72\x5f\145\x6e\144", ["\156\157\x6e\145\137\141\x6d\160" => __("\116\157\156\145\x20\101\115\x50\40\x56\x65\x72\163\151\157\156", PR__CVR__PMPR)]); } }
