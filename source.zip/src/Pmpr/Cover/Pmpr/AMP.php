<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6684009825136             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; class AMP extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\141\155\160\137\156\141\166", [$this, "\x6e\153\171\143\163\167\x65\x69\x61\x67\147\165\143\163\x75\x71"])->waqewsckuayqguos("\x61\x6d\x70\x5f\x68\x65\141\144\x65\x72\137\145\156\x64", [$this, "\x73\x77\x6f\x71\155\x67\x61\x73\171\157\147\x71\x75\x6f\x65\x6f"]); } public function nkycsweiaggucsuq() { $this->ewcsyqaaigkicgse("\162\145\156\x64\145\x72\137\154\x6f\147\x6f", [self::waguuiqqgsysuukq => [180, 60], self::kicoscymgmgqeqgy => false, "\x63\157\x6e\164\x61\151\x6e\145\162\137\x63\x6c\x61\x73\163" => "\x64\x2d\x66\x6c\x65\x78\x20\x6a\165\x73\164\151\146\171\x2d\143\x6f\x6e\x74\x65\156\x74\55\143\145\x6e\164\145\162"]); } public function swoqmgasyogquoeo() { echo $this->iuygowkemiiwqmiw("\x68\145\x61\x64\x65\x72\137\x65\156\144", ["\156\157\x6e\145\137\x61\x6d\160" => __("\x4e\x6f\156\145\x20\x41\115\120\40\x56\x65\x72\163\x69\x6f\x6e", PR__CVR__PMPR)]); } }
