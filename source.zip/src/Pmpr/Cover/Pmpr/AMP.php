<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661da299c54f1             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; class AMP extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\141\x6d\x70\137\x6e\141\x76", [$this, "\x6e\153\171\x63\163\167\x65\x69\x61\x67\x67\x75\143\163\x75\161"])->waqewsckuayqguos("\141\x6d\160\x5f\150\x65\141\x64\145\x72\137\x65\x6e\144", [$this, "\x73\x77\x6f\x71\x6d\x67\141\x73\171\x6f\x67\x71\x75\157\145\x6f"]); } public function nkycsweiaggucsuq() { $this->ewcsyqaaigkicgse("\x72\145\x6e\x64\145\x72\137\x6c\157\x67\157", [self::waguuiqqgsysuukq => [180, 60], self::kicoscymgmgqeqgy => false, "\x63\157\x6e\x74\141\151\x6e\145\162\x5f\143\154\x61\x73\x73" => "\x64\x2d\x66\x6c\145\170\40\x6a\x75\163\x74\x69\146\171\55\143\157\156\164\145\x6e\x74\x2d\143\x65\x6e\x74\145\162"]); } public function swoqmgasyogquoeo() { echo $this->iuygowkemiiwqmiw("\150\x65\x61\144\x65\x72\x5f\145\x6e\144", ["\x6e\157\x6e\x65\137\x61\155\x70" => __("\x4e\x6f\156\x65\40\101\115\120\x20\126\x65\162\163\151\157\x6e", PR__CVR__PMPR)]); } }
