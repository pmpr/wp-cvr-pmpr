<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6634d46bd9359             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; class AMP extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\141\x6d\160\137\x6e\x61\x76", [$this, "\x6e\153\171\x63\163\167\145\x69\x61\147\x67\165\x63\x73\165\x71"])->waqewsckuayqguos("\x61\155\x70\x5f\150\145\141\x64\x65\x72\x5f\145\x6e\144", [$this, "\x73\x77\x6f\x71\155\147\x61\x73\x79\x6f\x67\x71\x75\x6f\145\x6f"]); } public function nkycsweiaggucsuq() { $this->ewcsyqaaigkicgse("\162\x65\x6e\x64\145\162\x5f\154\157\x67\x6f", [self::waguuiqqgsysuukq => [180, 60], self::kicoscymgmgqeqgy => false, "\143\157\x6e\x74\x61\151\156\145\162\137\143\154\x61\x73\163" => "\144\55\146\x6c\x65\170\40\x6a\x75\163\164\151\146\x79\x2d\143\157\156\x74\x65\156\x74\x2d\x63\145\x6e\x74\x65\162"]); } public function swoqmgasyogquoeo() { echo $this->iuygowkemiiwqmiw("\x68\x65\141\x64\x65\162\137\x65\156\144", ["\156\157\156\x65\137\141\155\x70" => __("\116\157\156\x65\x20\101\x4d\120\x20\x56\x65\x72\163\x69\157\156", PR__CVR__PMPR)]); } }
