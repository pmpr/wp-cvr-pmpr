<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662cf78a0568b             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; class AMP extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x61\155\x70\137\156\141\166", [$this, "\x6e\153\x79\x63\x73\167\145\151\x61\x67\147\x75\x63\x73\x75\161"])->waqewsckuayqguos("\x61\x6d\x70\x5f\x68\x65\141\x64\x65\162\137\145\x6e\144", [$this, "\x73\x77\157\x71\x6d\147\141\163\x79\x6f\x67\x71\x75\x6f\x65\157"]); } public function nkycsweiaggucsuq() { $this->ewcsyqaaigkicgse("\162\x65\156\144\145\162\x5f\154\x6f\147\x6f", [self::waguuiqqgsysuukq => [180, 60], self::kicoscymgmgqeqgy => false, "\143\157\x6e\164\x61\151\156\145\x72\137\143\x6c\x61\163\163" => "\x64\x2d\x66\154\x65\x78\40\x6a\165\x73\164\x69\x66\x79\x2d\x63\x6f\156\164\145\156\164\55\143\x65\156\164\145\x72"]); } public function swoqmgasyogquoeo() { echo $this->iuygowkemiiwqmiw("\150\145\x61\144\145\162\137\145\x6e\144", ["\x6e\x6f\156\x65\x5f\x61\155\160" => __("\x4e\157\x6e\x65\40\x41\x4d\120\40\x56\145\x72\163\x69\157\x6e", PR__CVR__PMPR)]); } }
