<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66c7b6d27cadb             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; class AMP extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x61\155\x70\x5f\x6e\141\166", [$this, "\x6e\x6b\x79\143\163\167\145\x69\x61\147\x67\x75\x63\163\165\161"])->waqewsckuayqguos("\x61\x6d\160\137\150\145\141\x64\145\x72\x5f\145\x6e\144", [$this, "\163\x77\x6f\161\155\x67\x61\163\x79\x6f\x67\x71\165\x6f\145\x6f"]); } public function nkycsweiaggucsuq() { $this->ewcsyqaaigkicgse("\162\145\156\x64\145\162\x5f\x6c\157\147\x6f", [self::waguuiqqgsysuukq => [180, 60], self::kicoscymgmgqeqgy => false, "\x63\157\x6e\164\141\x69\x6e\x65\162\x5f\x63\x6c\141\163\x73" => "\x64\x2d\x66\x6c\145\x78\40\x6a\x75\163\164\x69\x66\x79\x2d\x63\157\x6e\x74\x65\x6e\164\55\x63\145\156\164\145\x72"]); } public function swoqmgasyogquoeo() { echo $this->iuygowkemiiwqmiw("\150\145\141\x64\x65\x72\x5f\x65\x6e\x64", ["\x6e\157\156\x65\137\x61\x6d\160" => __("\x4e\157\156\145\40\101\115\x50\40\x56\145\x72\163\151\x6f\x6e", PR__CVR__PMPR)]); } }
