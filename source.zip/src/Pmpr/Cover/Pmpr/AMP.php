<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d1dbc97f5c2             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; use Pmpr\Common\Foundation\Interfaces\Constants; class AMP extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x61\x6d\x70\x5f\x6e\x61\166", [$this, "\x6e\x6b\171\143\x73\x77\x65\151\x61\x67\147\x75\143\x73\165\x71"])->waqewsckuayqguos("\x61\155\160\x5f\150\x65\141\144\145\x72\137\145\x6e\144", [$this, "\163\167\x6f\x71\x6d\147\x61\x73\171\x6f\x67\161\x75\x6f\145\157"]); } public function nkycsweiaggucsuq() { $this->ewcsyqaaigkicgse("\162\x65\156\x64\145\x72\137\x6c\157\147\x6f", [Constants::waguuiqqgsysuukq => [180, 60], Constants::kicoscymgmgqeqgy => false, "\143\157\x6e\x74\x61\x69\156\145\x72\137\143\154\x61\163\x73" => "\x64\55\x66\x6c\x65\x78\40\x6a\x75\x73\x74\151\x66\171\x2d\143\x6f\x6e\164\x65\156\164\55\x63\x65\156\164\x65\162"]); } public function swoqmgasyogquoeo() { echo $this->iuygowkemiiwqmiw("\x68\x65\x61\144\x65\x72\x5f\x65\156\144", ["\x6e\x6f\156\145\x5f\x61\x6d\x70" => __("\x4e\x6f\156\145\x20\101\115\x50\x20\x56\x65\x72\163\x69\157\x6e", PR__CVR__PMPR)]); } }
