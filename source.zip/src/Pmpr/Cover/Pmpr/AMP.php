<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668dab879d304             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; class AMP extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x61\155\x70\137\x6e\141\166", [$this, "\156\x6b\171\x63\x73\167\145\151\141\147\147\x75\x63\x73\x75\161"])->waqewsckuayqguos("\141\155\160\137\x68\145\141\144\145\x72\x5f\145\156\144", [$this, "\x73\x77\x6f\161\x6d\x67\141\163\x79\157\x67\161\x75\x6f\x65\157"]); } public function nkycsweiaggucsuq() { $this->ewcsyqaaigkicgse("\x72\x65\156\x64\145\162\137\x6c\x6f\147\157", [self::waguuiqqgsysuukq => [180, 60], self::kicoscymgmgqeqgy => false, "\143\157\x6e\x74\x61\151\156\145\x72\x5f\x63\154\141\163\x73" => "\x64\55\x66\x6c\x65\x78\40\x6a\165\163\164\151\x66\171\x2d\x63\x6f\x6e\164\x65\156\x74\55\x63\145\156\164\x65\x72"]); } public function swoqmgasyogquoeo() { echo $this->iuygowkemiiwqmiw("\150\x65\141\144\x65\x72\137\x65\x6e\144", ["\x6e\157\156\145\x5f\141\155\x70" => __("\116\157\x6e\145\40\101\115\120\x20\x56\145\162\163\x69\157\156", PR__CVR__PMPR)]); } }
