<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a2f440542e0             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; class AMP extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\141\155\160\x5f\156\x61\x76", [$this, "\156\x6b\x79\143\163\167\x65\151\x61\147\147\x75\143\x73\x75\x71"])->waqewsckuayqguos("\x61\x6d\160\137\x68\x65\x61\x64\x65\x72\x5f\145\x6e\x64", [$this, "\163\167\x6f\x71\x6d\x67\141\163\171\157\x67\161\x75\x6f\145\157"]); } public function nkycsweiaggucsuq() { $this->ewcsyqaaigkicgse("\x72\145\x6e\x64\x65\x72\137\154\x6f\147\157", [self::waguuiqqgsysuukq => [180, 60], self::kicoscymgmgqeqgy => false, "\x63\x6f\x6e\x74\x61\151\x6e\145\162\137\143\x6c\141\x73\x73" => "\144\55\146\x6c\x65\x78\x20\x6a\165\x73\x74\151\x66\x79\x2d\143\157\156\x74\x65\156\164\x2d\x63\145\x6e\164\145\162"]); } public function swoqmgasyogquoeo() { echo $this->iuygowkemiiwqmiw("\x68\145\x61\144\x65\162\x5f\x65\156\x64", ["\x6e\157\x6e\x65\137\x61\x6d\x70" => __("\116\x6f\156\x65\x20\101\115\120\40\126\145\x72\163\x69\x6f\156", PR__CVR__PMPR)]); } }
