<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665dbc49a1166             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; class AMP extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x61\x6d\x70\137\x6e\141\x76", [$this, "\156\x6b\171\x63\163\x77\145\x69\x61\x67\x67\x75\x63\x73\x75\161"])->waqewsckuayqguos("\141\x6d\x70\137\150\x65\x61\x64\x65\162\x5f\x65\156\x64", [$this, "\x73\167\157\x71\155\147\x61\163\171\157\x67\x71\165\157\145\157"]); } public function nkycsweiaggucsuq() { $this->ewcsyqaaigkicgse("\162\145\x6e\144\x65\162\137\x6c\x6f\x67\157", [self::waguuiqqgsysuukq => [180, 60], self::kicoscymgmgqeqgy => false, "\143\157\x6e\164\x61\151\x6e\x65\x72\x5f\x63\154\x61\x73\x73" => "\144\55\x66\154\145\x78\40\x6a\165\163\x74\x69\x66\171\55\x63\157\156\x74\145\156\164\x2d\143\145\x6e\x74\145\x72"]); } public function swoqmgasyogquoeo() { echo $this->iuygowkemiiwqmiw("\x68\x65\x61\x64\145\x72\x5f\145\x6e\144", ["\x6e\x6f\x6e\145\137\x61\x6d\x70" => __("\x4e\157\156\x65\40\x41\x4d\120\40\x56\x65\162\163\x69\x6f\156", PR__CVR__PMPR)]); } }
