<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665ec468a43fa             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; class AMP extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\141\155\160\x5f\156\x61\166", [$this, "\156\153\171\x63\163\x77\145\151\x61\147\147\165\143\163\x75\161"])->waqewsckuayqguos("\x61\155\160\137\x68\x65\x61\x64\145\162\137\145\156\x64", [$this, "\x73\x77\157\x71\155\x67\x61\x73\x79\157\147\x71\165\157\145\x6f"]); } public function nkycsweiaggucsuq() { $this->ewcsyqaaigkicgse("\x72\x65\156\144\x65\x72\x5f\x6c\157\x67\157", [self::waguuiqqgsysuukq => [180, 60], self::kicoscymgmgqeqgy => false, "\143\x6f\x6e\x74\x61\x69\156\x65\x72\x5f\143\154\141\x73\163" => "\144\x2d\146\154\145\x78\x20\x6a\x75\163\x74\x69\x66\x79\x2d\143\157\x6e\x74\145\x6e\164\55\143\x65\156\x74\145\x72"]); } public function swoqmgasyogquoeo() { echo $this->iuygowkemiiwqmiw("\x68\145\x61\x64\145\162\137\x65\x6e\144", ["\x6e\x6f\x6e\145\137\x61\155\x70" => __("\116\x6f\x6e\x65\x20\x41\115\120\x20\x56\145\x72\x73\151\x6f\156", PR__CVR__PMPR)]); } }
