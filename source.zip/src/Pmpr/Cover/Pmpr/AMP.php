<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669d712e470fd             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; class AMP extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\141\155\160\x5f\156\x61\x76", [$this, "\156\153\171\x63\x73\167\x65\151\x61\x67\147\x75\143\x73\165\161"])->waqewsckuayqguos("\141\155\x70\137\x68\145\x61\x64\145\162\137\x65\x6e\x64", [$this, "\x73\167\x6f\x71\155\147\141\163\x79\x6f\x67\161\x75\157\x65\157"]); } public function nkycsweiaggucsuq() { $this->ewcsyqaaigkicgse("\x72\145\x6e\x64\x65\x72\x5f\154\157\147\157", [self::waguuiqqgsysuukq => [180, 60], self::kicoscymgmgqeqgy => false, "\x63\x6f\x6e\164\141\151\156\x65\162\x5f\143\154\141\x73\x73" => "\144\x2d\146\x6c\x65\x78\40\x6a\x75\x73\164\x69\x66\171\x2d\143\157\156\164\x65\156\x74\55\143\x65\x6e\x74\x65\x72"]); } public function swoqmgasyogquoeo() { echo $this->iuygowkemiiwqmiw("\150\x65\x61\x64\x65\162\137\145\156\x64", ["\156\x6f\x6e\x65\x5f\141\155\160" => __("\x4e\157\156\x65\x20\101\115\120\40\x56\x65\x72\163\151\157\156", PR__CVR__PMPR)]); } }
