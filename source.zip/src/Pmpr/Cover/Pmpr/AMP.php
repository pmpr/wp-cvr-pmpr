<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6606b5f370d0d             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; class AMP extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x61\155\x70\137\156\x61\166", [$this, "\156\153\x79\143\163\167\x65\151\x61\x67\x67\165\x63\x73\165\x71"])->waqewsckuayqguos("\141\155\x70\137\x68\145\x61\x64\x65\x72\x5f\x65\x6e\x64", [$this, "\163\x77\157\x71\155\x67\141\163\x79\157\147\161\165\157\145\157"]); } public function nkycsweiaggucsuq() { $this->ewcsyqaaigkicgse("\x72\x65\156\x64\x65\x72\137\154\157\x67\157", [self::waguuiqqgsysuukq => [180, 60], self::kicoscymgmgqeqgy => false, "\x63\157\156\x74\x61\151\156\x65\162\x5f\143\154\141\x73\163" => "\144\55\x66\154\145\x78\x20\152\x75\163\164\151\x66\171\x2d\x63\157\156\x74\145\156\164\55\x63\145\156\x74\x65\162"]); } public function swoqmgasyogquoeo() { echo $this->iuygowkemiiwqmiw("\x68\x65\141\144\145\x72\137\145\x6e\144", ["\156\157\x6e\145\x5f\x61\x6d\x70" => __("\x4e\157\x6e\145\x20\101\115\x50\40\126\x65\x72\x73\151\x6f\156", PR__CVR__PMPR)]); } }
