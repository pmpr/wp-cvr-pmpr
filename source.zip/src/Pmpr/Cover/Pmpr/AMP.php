<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66c508e944d8a             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; class AMP extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\141\x6d\160\137\156\x61\x76", [$this, "\156\x6b\171\143\163\x77\145\x69\141\x67\147\x75\143\163\x75\161"])->waqewsckuayqguos("\141\x6d\x70\137\x68\145\141\144\145\162\137\x65\x6e\x64", [$this, "\163\x77\157\161\155\147\141\x73\x79\157\x67\161\165\x6f\145\157"]); } public function nkycsweiaggucsuq() { $this->ewcsyqaaigkicgse("\162\x65\x6e\144\145\x72\x5f\x6c\157\x67\x6f", [self::waguuiqqgsysuukq => [180, 60], self::kicoscymgmgqeqgy => false, "\x63\157\156\164\x61\151\156\145\162\137\143\x6c\141\163\163" => "\x64\55\x66\x6c\x65\170\40\x6a\x75\x73\164\151\x66\x79\55\x63\157\x6e\164\145\x6e\164\x2d\x63\x65\156\164\145\162"]); } public function swoqmgasyogquoeo() { echo $this->iuygowkemiiwqmiw("\150\x65\x61\x64\x65\x72\137\145\x6e\144", ["\x6e\157\156\x65\137\141\x6d\160" => __("\x4e\157\156\x65\x20\101\x4d\120\x20\126\145\x72\163\x69\157\156", PR__CVR__PMPR)]); } }
