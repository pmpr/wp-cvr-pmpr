<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6637506095a97             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; class AMP extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x61\155\x70\x5f\156\x61\166", [$this, "\x6e\x6b\x79\143\163\x77\x65\151\141\x67\x67\165\x63\x73\165\x71"])->waqewsckuayqguos("\141\155\x70\137\x68\x65\141\x64\145\x72\x5f\x65\156\144", [$this, "\x73\x77\x6f\x71\x6d\x67\x61\x73\171\157\x67\x71\x75\157\x65\157"]); } public function nkycsweiaggucsuq() { $this->ewcsyqaaigkicgse("\x72\145\156\x64\x65\162\137\154\157\147\x6f", [self::waguuiqqgsysuukq => [180, 60], self::kicoscymgmgqeqgy => false, "\143\157\156\164\141\x69\156\145\162\137\143\154\x61\163\163" => "\144\55\x66\x6c\145\170\x20\152\x75\163\x74\151\x66\x79\x2d\143\157\x6e\x74\145\156\x74\55\x63\145\156\x74\145\162"]); } public function swoqmgasyogquoeo() { echo $this->iuygowkemiiwqmiw("\150\x65\x61\x64\145\x72\x5f\145\156\x64", ["\156\157\156\145\x5f\x61\155\x70" => __("\x4e\157\x6e\145\40\x41\115\120\x20\126\145\162\x73\x69\x6f\x6e", PR__CVR__PMPR)]); } }
