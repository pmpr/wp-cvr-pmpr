<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cf889e20710             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; use Pmpr\Common\Foundation\Interfaces\Constants; class AMP extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x61\x6d\x70\137\x6e\141\166", [$this, "\x6e\x6b\171\x63\163\x77\x65\151\141\x67\147\x75\x63\163\165\161"])->waqewsckuayqguos("\141\x6d\x70\137\150\145\141\x64\x65\162\137\145\156\144", [$this, "\x73\167\x6f\161\155\x67\x61\x73\171\x6f\147\161\x75\x6f\145\157"]); } public function nkycsweiaggucsuq() { $this->ewcsyqaaigkicgse("\x72\x65\156\x64\x65\x72\x5f\x6c\x6f\x67\157", [Constants::waguuiqqgsysuukq => [180, 60], Constants::kicoscymgmgqeqgy => false, "\x63\x6f\156\x74\x61\x69\x6e\x65\x72\137\x63\x6c\141\x73\163" => "\x64\x2d\146\154\x65\170\x20\x6a\165\163\x74\x69\146\x79\x2d\143\157\156\x74\145\x6e\164\x2d\x63\x65\x6e\x74\x65\162"]); } public function swoqmgasyogquoeo() { echo $this->iuygowkemiiwqmiw("\x68\145\x61\144\x65\162\x5f\x65\x6e\144", ["\156\157\156\145\137\x61\155\160" => __("\x4e\x6f\156\x65\40\101\115\x50\40\x56\x65\162\163\151\157\x6e", PR__CVR__PMPR)]); } }
