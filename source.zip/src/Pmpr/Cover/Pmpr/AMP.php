<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8625742f             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; use Pmpr\Common\Foundation\Interfaces\Constants; class AMP extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x61\x6d\160\137\x6e\x61\x76", [$this, "\x6e\153\171\x63\x73\167\145\151\141\x67\x67\x75\143\163\x75\161"])->waqewsckuayqguos("\141\x6d\160\137\150\145\141\144\x65\x72\137\145\x6e\144", [$this, "\163\x77\157\x71\x6d\x67\141\163\x79\x6f\x67\161\x75\x6f\145\157"]); } public function nkycsweiaggucsuq() { $this->ewcsyqaaigkicgse("\162\145\x6e\x64\x65\162\x5f\154\157\147\157", [Constants::waguuiqqgsysuukq => [180, 60], Constants::kicoscymgmgqeqgy => false, "\143\157\x6e\164\141\x69\156\x65\x72\x5f\143\154\x61\x73\x73" => "\144\x2d\146\x6c\x65\170\40\x6a\165\x73\x74\x69\146\171\55\143\x6f\x6e\x74\145\x6e\x74\55\x63\145\156\164\x65\162"]); } public function swoqmgasyogquoeo() { echo $this->iuygowkemiiwqmiw("\150\145\x61\x64\x65\x72\x5f\145\156\x64", ["\156\157\156\145\137\x61\155\x70" => __("\x4e\x6f\x6e\145\x20\x41\x4d\120\x20\126\145\162\x73\x69\x6f\156", PR__CVR__PMPR)]); } }
