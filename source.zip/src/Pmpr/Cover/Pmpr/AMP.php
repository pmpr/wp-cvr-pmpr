<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669d561d8bd6d             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; class AMP extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x61\155\x70\x5f\156\141\x76", [$this, "\156\x6b\171\143\x73\167\145\x69\x61\x67\x67\165\x63\163\x75\x71"])->waqewsckuayqguos("\x61\x6d\160\x5f\150\x65\x61\x64\x65\162\137\145\x6e\144", [$this, "\x73\167\157\x71\x6d\147\x61\163\x79\x6f\x67\161\x75\157\x65\157"]); } public function nkycsweiaggucsuq() { $this->ewcsyqaaigkicgse("\162\x65\156\144\x65\x72\x5f\x6c\x6f\147\157", [self::waguuiqqgsysuukq => [180, 60], self::kicoscymgmgqeqgy => false, "\x63\157\x6e\164\x61\151\156\x65\162\x5f\x63\x6c\141\163\x73" => "\x64\x2d\x66\x6c\x65\170\x20\x6a\x75\163\164\x69\146\x79\55\143\157\156\x74\145\x6e\164\55\x63\x65\x6e\x74\145\x72"]); } public function swoqmgasyogquoeo() { echo $this->iuygowkemiiwqmiw("\150\x65\x61\x64\x65\x72\137\145\156\x64", ["\x6e\x6f\156\x65\x5f\141\x6d\x70" => __("\x4e\157\156\145\40\101\x4d\x50\40\x56\145\x72\x73\151\157\x6e", PR__CVR__PMPR)]); } }
