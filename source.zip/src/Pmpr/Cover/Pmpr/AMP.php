<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb56afe7646             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; class AMP extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\141\155\x70\x5f\x6e\141\x76", [$this, "\x6e\x6b\x79\x63\x73\x77\145\151\x61\147\x67\x75\143\163\165\161"])->waqewsckuayqguos("\141\x6d\160\x5f\x68\x65\141\144\145\162\137\x65\x6e\144", [$this, "\x73\x77\157\x71\155\x67\x61\x73\171\x6f\147\x71\x75\157\x65\157"]); } public function nkycsweiaggucsuq() { $this->ewcsyqaaigkicgse("\x72\x65\x6e\144\145\x72\x5f\154\x6f\x67\157", [self::waguuiqqgsysuukq => [180, 60], self::kicoscymgmgqeqgy => false, "\143\157\156\x74\141\151\x6e\x65\162\x5f\x63\x6c\x61\x73\x73" => "\144\x2d\146\154\x65\170\x20\x6a\165\163\164\151\146\x79\55\143\157\156\x74\145\156\x74\55\143\x65\156\164\x65\x72"]); } public function swoqmgasyogquoeo() { echo $this->iuygowkemiiwqmiw("\x68\x65\141\144\145\162\137\145\156\144", ["\156\157\x6e\x65\x5f\141\155\160" => __("\116\157\x6e\145\x20\101\115\120\x20\x56\x65\x72\163\151\x6f\156", PR__CVR__PMPR)]); } }
