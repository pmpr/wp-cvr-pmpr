<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66895809724d0             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; class AMP extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\141\x6d\160\137\156\141\166", [$this, "\x6e\x6b\171\x63\163\167\145\x69\141\x67\x67\165\143\x73\x75\161"])->waqewsckuayqguos("\x61\x6d\x70\137\150\x65\x61\144\x65\162\137\145\x6e\x64", [$this, "\163\x77\x6f\161\x6d\x67\141\163\171\x6f\x67\x71\165\x6f\145\x6f"]); } public function nkycsweiaggucsuq() { $this->ewcsyqaaigkicgse("\162\x65\x6e\144\145\x72\x5f\154\157\147\157", [self::waguuiqqgsysuukq => [180, 60], self::kicoscymgmgqeqgy => false, "\143\x6f\156\x74\x61\x69\156\145\162\137\143\154\141\x73\163" => "\x64\x2d\146\x6c\x65\x78\x20\152\x75\163\164\x69\146\171\55\x63\x6f\156\x74\145\156\x74\x2d\x63\x65\156\x74\145\x72"]); } public function swoqmgasyogquoeo() { echo $this->iuygowkemiiwqmiw("\150\145\x61\144\145\x72\x5f\x65\x6e\x64", ["\x6e\157\156\145\x5f\141\155\x70" => __("\116\x6f\x6e\x65\x20\x41\x4d\x50\40\126\145\x72\x73\151\157\x6e", PR__CVR__PMPR)]); } }
