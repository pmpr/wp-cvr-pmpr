<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66c31d3912e5b             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; class AMP extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x61\x6d\160\137\156\x61\166", [$this, "\156\x6b\x79\x63\x73\167\145\x69\141\x67\x67\x75\143\163\x75\x71"])->waqewsckuayqguos("\141\x6d\160\137\x68\145\141\144\x65\162\x5f\145\156\x64", [$this, "\x73\167\x6f\x71\x6d\x67\x61\x73\x79\157\147\161\x75\x6f\145\157"]); } public function nkycsweiaggucsuq() { $this->ewcsyqaaigkicgse("\x72\145\x6e\144\x65\162\x5f\x6c\x6f\x67\157", [self::waguuiqqgsysuukq => [180, 60], self::kicoscymgmgqeqgy => false, "\143\x6f\156\164\x61\x69\x6e\145\162\137\x63\154\x61\x73\163" => "\144\55\x66\x6c\145\x78\40\x6a\x75\163\164\151\x66\171\55\143\157\x6e\x74\145\x6e\x74\x2d\143\x65\x6e\x74\x65\x72"]); } public function swoqmgasyogquoeo() { echo $this->iuygowkemiiwqmiw("\150\145\x61\x64\x65\x72\x5f\x65\x6e\144", ["\156\157\156\145\137\x61\x6d\160" => __("\116\x6f\x6e\145\x20\101\115\120\x20\126\x65\x72\x73\x69\157\x6e", PR__CVR__PMPR)]); } }
