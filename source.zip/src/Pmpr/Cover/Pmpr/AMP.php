<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ced8515d92c             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; use Pmpr\Common\Foundation\Interfaces\Constants; class AMP extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x61\155\x70\137\156\141\x76", [$this, "\156\x6b\x79\143\x73\167\145\151\141\x67\147\x75\143\x73\165\x71"])->waqewsckuayqguos("\141\155\160\x5f\x68\145\141\144\x65\x72\x5f\145\156\144", [$this, "\163\167\157\x71\x6d\147\141\x73\171\x6f\x67\161\x75\157\x65\x6f"]); } public function nkycsweiaggucsuq() { $this->ewcsyqaaigkicgse("\x72\145\x6e\x64\145\x72\x5f\154\x6f\147\157", [Constants::waguuiqqgsysuukq => [180, 60], Constants::kicoscymgmgqeqgy => false, "\x63\157\x6e\x74\141\151\156\x65\x72\x5f\x63\154\x61\x73\163" => "\144\x2d\146\154\145\170\x20\x6a\x75\163\164\x69\x66\171\x2d\x63\157\x6e\x74\145\x6e\x74\x2d\x63\145\156\x74\145\x72"]); } public function swoqmgasyogquoeo() { echo $this->iuygowkemiiwqmiw("\x68\x65\141\x64\x65\x72\x5f\145\156\x64", ["\156\x6f\x6e\x65\x5f\141\155\160" => __("\116\157\x6e\145\40\101\115\120\40\x56\x65\162\x73\x69\157\156", PR__CVR__PMPR)]); } }
