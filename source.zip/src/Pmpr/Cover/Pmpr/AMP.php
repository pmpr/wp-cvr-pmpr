<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce114e0e8f4             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; use Pmpr\Common\Foundation\Interfaces\Constants; class AMP extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x61\155\x70\137\x6e\x61\x76", [$this, "\x6e\153\171\143\163\167\x65\x69\141\x67\x67\165\x63\x73\x75\x71"])->waqewsckuayqguos("\141\x6d\160\137\150\x65\x61\x64\x65\162\x5f\145\x6e\144", [$this, "\x73\x77\x6f\161\x6d\147\x61\163\171\x6f\147\x71\x75\157\x65\x6f"]); } public function nkycsweiaggucsuq() { $this->ewcsyqaaigkicgse("\162\x65\156\144\x65\162\137\x6c\x6f\x67\x6f", [Constants::waguuiqqgsysuukq => [180, 60], Constants::kicoscymgmgqeqgy => false, "\x63\157\x6e\164\141\151\156\x65\162\137\x63\x6c\x61\163\163" => "\144\55\x66\x6c\145\170\x20\152\165\x73\164\151\146\171\55\143\x6f\156\x74\145\x6e\x74\x2d\143\x65\156\164\x65\162"]); } public function swoqmgasyogquoeo() { echo $this->iuygowkemiiwqmiw("\x68\145\141\144\x65\x72\x5f\x65\156\144", ["\x6e\x6f\x6e\x65\137\141\155\160" => __("\x4e\x6f\x6e\x65\40\101\x4d\120\40\x56\145\162\163\151\157\156", PR__CVR__PMPR)]); } }
