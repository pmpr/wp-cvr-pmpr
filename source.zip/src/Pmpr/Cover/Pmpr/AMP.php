<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66bd2143b21cb             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; class AMP extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\141\155\x70\x5f\x6e\141\x76", [$this, "\156\153\x79\143\x73\x77\145\151\141\147\147\165\x63\x73\x75\x71"])->waqewsckuayqguos("\141\x6d\160\x5f\150\145\x61\144\x65\162\137\x65\x6e\144", [$this, "\163\167\x6f\x71\x6d\147\x61\x73\x79\x6f\147\161\165\x6f\x65\157"]); } public function nkycsweiaggucsuq() { $this->ewcsyqaaigkicgse("\x72\145\156\x64\145\162\137\154\157\147\x6f", [self::waguuiqqgsysuukq => [180, 60], self::kicoscymgmgqeqgy => false, "\143\157\156\x74\x61\x69\156\145\x72\x5f\143\154\x61\163\163" => "\144\x2d\x66\154\x65\170\x20\x6a\x75\x73\164\151\146\x79\x2d\143\157\156\x74\x65\156\x74\55\x63\145\x6e\164\145\162"]); } public function swoqmgasyogquoeo() { echo $this->iuygowkemiiwqmiw("\150\145\x61\144\145\162\137\x65\x6e\x64", ["\156\157\156\145\137\141\155\x70" => __("\x4e\x6f\156\145\40\101\x4d\120\x20\126\145\162\x73\x69\157\x6e", PR__CVR__PMPR)]); } }
