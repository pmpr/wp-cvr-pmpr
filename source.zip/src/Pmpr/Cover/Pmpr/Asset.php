<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ced9b261c92             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; class Asset extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\145\x6e\x71\x75\145\x75\x65\x5f\x6d\x75\x6c\x74\151\x73\x74\145\x70\x5f\x61\x73\x73\x65\x74\163", [$this, "\153\141\163\x63\x63\155\x6d\x6d\171\x71\161\x77\x75\x61\141\171"]); } public function kasccmmmyqqwuaay() { $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->oeoquuwkoywiuesy($eygsasmqycagyayw->awgyqswkqywwmkye("\x6d\x75\154\164\x69\x73\x74\x65\x70", $eygsasmqycagyayw->get("\155\165\x6c\x74\x69\163\x74\x65\x70\56\143\x73\163"))); } }
