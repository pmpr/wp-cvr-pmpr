<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669eeba41d44c             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; class Asset extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\145\156\161\x75\145\165\x65\137\x6d\165\x6c\x74\151\163\x74\x65\160\x5f\x61\163\x73\145\164\163", [$this, "\153\x61\163\x63\x63\x6d\x6d\x6d\171\x71\x71\x77\165\x61\141\x79"]); } public function kasccmmmyqqwuaay() { $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->oeoquuwkoywiuesy($eygsasmqycagyayw->awgyqswkqywwmkye("\x6d\x75\x6c\164\151\x73\164\145\x70", $eygsasmqycagyayw->get("\x6d\x75\154\x74\x69\x73\164\145\x70\x2e\143\x73\x73"))); } }
