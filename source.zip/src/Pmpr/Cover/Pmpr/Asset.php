<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6684009825136             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; class Asset extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x65\156\161\x75\145\165\x65\137\155\165\154\164\151\x73\164\145\x70\x5f\141\x73\x73\x65\x74\x73", [$this, "\153\x61\163\x63\x63\x6d\x6d\x6d\171\x71\x71\x77\x75\x61\141\x79"]); } public function kasccmmmyqqwuaay() { $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->oeoquuwkoywiuesy($eygsasmqycagyayw->awgyqswkqywwmkye("\x6d\x75\154\x74\x69\163\164\x65\x70", $eygsasmqycagyayw->get("\x6d\165\154\x74\x69\163\164\x65\x70\56\143\163\163"))); } }
