<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8625742f             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; class Asset extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x65\156\161\x75\145\x75\x65\137\155\165\x6c\x74\151\x73\164\145\160\137\x61\x73\163\145\164\x73", [$this, "\153\141\x73\x63\x63\155\155\x6d\171\161\x71\167\165\x61\141\x79"]); } public function kasccmmmyqqwuaay() { $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->oeoquuwkoywiuesy($eygsasmqycagyayw->awgyqswkqywwmkye("\155\165\154\x74\x69\163\x74\x65\x70", $eygsasmqycagyayw->get("\155\x75\154\164\151\x73\x74\x65\160\x2e\x63\x73\x73"))); } }
