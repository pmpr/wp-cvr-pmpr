<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6681a8acaf4d8             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; class Asset extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\145\x6e\x71\x75\x65\x75\145\137\x6d\x75\154\164\151\x73\x74\145\x70\x5f\141\163\x73\145\x74\x73", [$this, "\153\x61\x73\x63\x63\155\x6d\x6d\x79\161\x71\x77\165\141\x61\x79"]); } public function kasccmmmyqqwuaay() { $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->oeoquuwkoywiuesy($eygsasmqycagyayw->awgyqswkqywwmkye("\x6d\165\154\164\151\x73\164\x65\160", $eygsasmqycagyayw->get("\x6d\x75\154\x74\x69\163\164\x65\x70\x2e\143\x73\163"))); } }
