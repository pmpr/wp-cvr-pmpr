<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66895809724d0             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; class Asset extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x65\x6e\161\165\x65\165\145\137\155\165\154\x74\151\x73\164\145\x70\137\x61\x73\163\145\x74\x73", [$this, "\153\x61\x73\143\x63\155\155\x6d\x79\161\161\167\x75\x61\141\171"]); } public function kasccmmmyqqwuaay() { $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->oeoquuwkoywiuesy($eygsasmqycagyayw->awgyqswkqywwmkye("\x6d\x75\154\x74\151\163\x74\x65\x70", $eygsasmqycagyayw->get("\x6d\165\154\164\151\x73\x74\x65\160\x2e\143\163\163"))); } }
