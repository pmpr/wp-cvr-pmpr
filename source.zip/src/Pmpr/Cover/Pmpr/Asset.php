<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6686f085801e1             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; class Asset extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x65\x6e\x71\165\x65\x75\145\137\155\165\154\164\151\163\164\145\x70\x5f\141\163\x73\x65\x74\163", [$this, "\x6b\x61\163\143\x63\x6d\155\x6d\171\x71\x71\x77\165\x61\141\x79"]); } public function kasccmmmyqqwuaay() { $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->oeoquuwkoywiuesy($eygsasmqycagyayw->awgyqswkqywwmkye("\155\x75\154\164\151\163\164\145\x70", $eygsasmqycagyayw->get("\155\x75\154\x74\x69\x73\164\145\160\x2e\x63\163\x73"))); } }
