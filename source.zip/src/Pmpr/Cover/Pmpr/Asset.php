<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669d5b84b76a1             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; class Asset extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\145\x6e\161\x75\x65\165\145\137\155\165\x6c\164\x69\163\164\145\160\137\x61\163\x73\x65\x74\x73", [$this, "\x6b\x61\163\143\143\155\155\x6d\x79\x71\161\167\x75\141\141\x79"]); } public function kasccmmmyqqwuaay() { $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->oeoquuwkoywiuesy($eygsasmqycagyayw->awgyqswkqywwmkye("\x6d\x75\x6c\164\151\x73\x74\145\160", $eygsasmqycagyayw->get("\x6d\165\x6c\x74\151\163\164\x65\x70\x2e\143\x73\x73"))); } }
