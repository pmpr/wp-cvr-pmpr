<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce6cb67dbd5             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; class Asset extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\145\x6e\x71\165\145\165\x65\137\x6d\x75\154\164\x69\163\164\145\160\x5f\x61\x73\163\145\x74\x73", [$this, "\153\141\x73\x63\x63\155\x6d\x6d\171\x71\161\167\165\x61\141\171"]); } public function kasccmmmyqqwuaay() { $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->oeoquuwkoywiuesy($eygsasmqycagyayw->awgyqswkqywwmkye("\x6d\x75\x6c\164\x69\163\x74\145\160", $eygsasmqycagyayw->get("\x6d\x75\x6c\x74\x69\163\164\145\x70\56\143\x73\x73"))); } }
