<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66c508e944d8a             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; class Asset extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x65\x6e\161\x75\145\x75\x65\x5f\x6d\165\154\x74\151\163\x74\145\160\x5f\x61\x73\x73\x65\x74\163", [$this, "\x6b\x61\x73\143\x63\x6d\155\155\x79\161\161\167\x75\141\141\x79"]); } public function kasccmmmyqqwuaay() { $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->oeoquuwkoywiuesy($eygsasmqycagyayw->awgyqswkqywwmkye("\155\165\x6c\x74\151\163\164\145\x70", $eygsasmqycagyayw->get("\155\165\x6c\x74\x69\163\164\145\x70\x2e\143\163\x73"))); } }
