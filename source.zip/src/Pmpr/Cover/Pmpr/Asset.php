<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669c49f78f111             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; class Asset extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x65\156\161\x75\145\165\x65\137\155\165\x6c\x74\151\163\164\145\x70\137\x61\163\163\145\x74\x73", [$this, "\x6b\141\x73\x63\x63\155\x6d\155\x79\161\161\x77\x75\x61\x61\x79"]); } public function kasccmmmyqqwuaay() { $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->oeoquuwkoywiuesy($eygsasmqycagyayw->awgyqswkqywwmkye("\155\x75\x6c\x74\151\x73\x74\x65\x70", $eygsasmqycagyayw->get("\155\165\154\x74\151\163\164\x65\x70\x2e\x63\163\x73"))); } }
