<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668c5b6675758             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; class Asset extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\145\156\161\165\145\x75\x65\x5f\x6d\x75\154\164\151\x73\x74\145\160\x5f\141\163\163\145\164\x73", [$this, "\x6b\141\x73\143\143\x6d\x6d\155\x79\x71\161\x77\165\141\141\x79"]); } public function kasccmmmyqqwuaay() { $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->oeoquuwkoywiuesy($eygsasmqycagyayw->awgyqswkqywwmkye("\x6d\x75\x6c\164\151\163\164\145\x70", $eygsasmqycagyayw->get("\155\x75\x6c\x74\151\163\164\145\160\x2e\x63\163\163"))); } }
