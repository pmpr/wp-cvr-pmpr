<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce114e0e8f4             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; class Asset extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\145\156\161\x75\x65\165\x65\137\155\165\x6c\164\151\163\164\145\x70\137\x61\x73\x73\x65\164\163", [$this, "\x6b\141\163\x63\143\x6d\155\155\171\161\161\167\x75\141\141\171"]); } public function kasccmmmyqqwuaay() { $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->oeoquuwkoywiuesy($eygsasmqycagyayw->awgyqswkqywwmkye("\155\165\x6c\164\x69\x73\x74\x65\x70", $eygsasmqycagyayw->get("\155\165\154\164\x69\163\x74\145\160\x2e\143\163\163"))); } }
