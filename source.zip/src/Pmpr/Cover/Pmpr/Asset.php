<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66812eb5d80af             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; class Asset extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x65\156\x71\165\x65\165\x65\x5f\x6d\x75\x6c\164\x69\x73\164\x65\x70\x5f\141\163\x73\x65\x74\x73", [$this, "\x6b\x61\163\143\143\155\x6d\x6d\171\161\161\167\x75\141\x61\171"]); } public function kasccmmmyqqwuaay() { $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->oeoquuwkoywiuesy($eygsasmqycagyayw->awgyqswkqywwmkye("\155\165\154\164\x69\x73\164\x65\x70", $eygsasmqycagyayw->get("\x6d\x75\x6c\x74\x69\x73\164\x65\x70\x2e\x63\163\163"))); } }
