<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66aeb5c87ae9b             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; class Asset extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x65\x6e\x71\165\145\165\145\x5f\x6d\x75\x6c\164\x69\x73\x74\145\x70\x5f\x61\163\x73\x65\164\x73", [$this, "\153\141\x73\x63\143\155\155\x6d\171\x71\x71\x77\165\x61\x61\171"]); } public function kasccmmmyqqwuaay() { $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->oeoquuwkoywiuesy($eygsasmqycagyayw->awgyqswkqywwmkye("\x6d\165\x6c\x74\x69\163\164\x65\x70", $eygsasmqycagyayw->get("\155\x75\154\164\151\163\x74\x65\x70\x2e\143\x73\x73"))); } }
