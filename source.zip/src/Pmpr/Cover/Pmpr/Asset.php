<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66c31d3912e5b             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; class Asset extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\145\x6e\161\x75\145\x75\145\x5f\x6d\x75\x6c\164\x69\163\164\145\x70\x5f\141\163\x73\145\164\163", [$this, "\153\141\x73\143\143\155\155\x6d\171\161\161\167\x75\141\141\x79"]); } public function kasccmmmyqqwuaay() { $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->oeoquuwkoywiuesy($eygsasmqycagyayw->awgyqswkqywwmkye("\155\165\x6c\x74\x69\x73\x74\145\x70", $eygsasmqycagyayw->get("\x6d\x75\x6c\x74\x69\163\164\x65\x70\x2e\x63\163\x73"))); } }
