<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668dab879d304             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; class Asset extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\145\156\161\x75\145\165\x65\x5f\155\165\154\164\151\163\164\x65\160\x5f\x61\163\163\x65\164\163", [$this, "\x6b\x61\x73\x63\x63\x6d\155\155\x79\161\161\x77\x75\141\x61\171"]); } public function kasccmmmyqqwuaay() { $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->oeoquuwkoywiuesy($eygsasmqycagyayw->awgyqswkqywwmkye("\x6d\x75\x6c\164\x69\x73\x74\145\160", $eygsasmqycagyayw->get("\155\165\154\x74\151\163\164\x65\160\x2e\143\x73\x73"))); } }
