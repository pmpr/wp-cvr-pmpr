<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66b6183f51930             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; class Asset extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x65\x6e\x71\165\x65\165\145\x5f\155\x75\x6c\x74\x69\x73\x74\145\160\137\141\x73\x73\x65\164\163", [$this, "\x6b\141\x73\x63\x63\155\155\155\171\161\x71\x77\165\141\141\x79"]); } public function kasccmmmyqqwuaay() { $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->oeoquuwkoywiuesy($eygsasmqycagyayw->awgyqswkqywwmkye("\155\165\154\164\x69\x73\164\x65\160", $eygsasmqycagyayw->get("\x6d\x75\154\x74\x69\x73\x74\145\x70\56\x63\x73\163"))); } }
