<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a42a72b7b43             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; class Asset extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\145\x6e\161\165\145\165\x65\137\x6d\x75\154\164\151\163\164\x65\160\x5f\141\163\163\x65\x74\x73", [$this, "\x6b\141\163\x63\143\155\155\155\171\x71\161\x77\165\141\x61\x79"]); } public function kasccmmmyqqwuaay() { $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->oeoquuwkoywiuesy($eygsasmqycagyayw->awgyqswkqywwmkye("\x6d\x75\154\x74\151\x73\164\x65\160", $eygsasmqycagyayw->get("\x6d\165\x6c\164\151\163\164\145\160\56\143\163\163"))); } }
