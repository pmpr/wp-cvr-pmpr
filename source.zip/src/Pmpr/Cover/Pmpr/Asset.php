<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669d717e9761b             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; class Asset extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x65\156\x71\165\145\165\x65\137\x6d\165\154\x74\151\x73\x74\x65\160\x5f\141\163\x73\145\x74\x73", [$this, "\153\141\x73\143\x63\x6d\x6d\x6d\171\x71\161\x77\x75\141\x61\x79"]); } public function kasccmmmyqqwuaay() { $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->oeoquuwkoywiuesy($eygsasmqycagyayw->awgyqswkqywwmkye("\x6d\165\154\164\151\163\x74\x65\160", $eygsasmqycagyayw->get("\x6d\165\x6c\x74\x69\x73\164\145\x70\x2e\x63\x73\x73"))); } }
