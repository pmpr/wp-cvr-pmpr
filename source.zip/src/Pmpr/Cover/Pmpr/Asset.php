<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ced8515d92c             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; class Asset extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\145\156\161\x75\x65\165\x65\x5f\x6d\165\154\x74\x69\x73\x74\x65\x70\137\141\163\163\x65\164\x73", [$this, "\153\x61\x73\143\143\x6d\x6d\x6d\x79\161\x71\x77\x75\x61\x61\171"]); } public function kasccmmmyqqwuaay() { $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->oeoquuwkoywiuesy($eygsasmqycagyayw->awgyqswkqywwmkye("\155\165\x6c\164\151\x73\164\145\x70", $eygsasmqycagyayw->get("\155\x75\x6c\x74\151\x73\164\x65\160\56\x63\163\163"))); } }
