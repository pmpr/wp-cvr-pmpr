<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669d561d8bd6d             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; class Asset extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\145\156\161\x75\x65\165\145\x5f\x6d\x75\x6c\x74\x69\x73\164\145\x70\137\x61\x73\163\x65\x74\163", [$this, "\153\141\x73\143\x63\155\x6d\x6d\171\161\x71\x77\x75\x61\141\171"]); } public function kasccmmmyqqwuaay() { $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->oeoquuwkoywiuesy($eygsasmqycagyayw->awgyqswkqywwmkye("\155\165\x6c\x74\151\x73\164\x65\x70", $eygsasmqycagyayw->get("\155\165\x6c\164\x69\x73\x74\x65\160\56\x63\x73\163"))); } }
