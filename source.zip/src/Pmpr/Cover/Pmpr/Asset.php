<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cf889e20710             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; class Asset extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x65\x6e\x71\165\x65\x75\145\x5f\155\165\x6c\164\x69\x73\x74\145\x70\x5f\x61\163\163\x65\x74\163", [$this, "\153\x61\163\143\x63\155\x6d\x6d\x79\x71\x71\167\165\x61\141\x79"]); } public function kasccmmmyqqwuaay() { $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->oeoquuwkoywiuesy($eygsasmqycagyayw->awgyqswkqywwmkye("\x6d\x75\x6c\164\x69\x73\x74\x65\x70", $eygsasmqycagyayw->get("\155\x75\154\164\x69\x73\164\145\x70\x2e\143\163\163"))); } }
