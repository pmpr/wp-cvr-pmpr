<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66c7b6d27cadb             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; class Asset extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\145\156\161\165\145\165\x65\x5f\x6d\x75\x6c\164\x69\x73\164\x65\160\x5f\x61\163\163\145\x74\x73", [$this, "\x6b\141\x73\143\143\x6d\155\x6d\x79\x71\161\x77\165\x61\x61\x79"]); } public function kasccmmmyqqwuaay() { $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->oeoquuwkoywiuesy($eygsasmqycagyayw->awgyqswkqywwmkye("\155\165\x6c\164\151\163\164\x65\160", $eygsasmqycagyayw->get("\155\x75\154\x74\151\x73\164\x65\x70\56\x63\x73\163"))); } }
