<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             694c4d3b3b826             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Cover\Pmpr\Traits\CommonTrait; abstract class Container extends BaseClass { use CommonTrait; }
