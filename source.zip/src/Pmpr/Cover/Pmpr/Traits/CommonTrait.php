<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ced8515d92c             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Traits; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Cover\Pmpr\Customizer; trait CommonTrait { public function wkiaeewoqmsougim($ymqmyyeuycgmigyo, $ggauoeuaesiymgee = false) { return Customizer::symcgieuakksimmu()->giiuwsmyumqwwiyq($ymqmyyeuycgmigyo, $ggauoeuaesiymgee); } public function mkcqggisuwuuueqm() : array { return [Constants::qisqmmesuewemeqg => ["\143\x72\x6f\x70" => 1, "\x77\x69\x64\x74\x68" => 803, "\150\x65\151\147\150\x74" => 450, "\143\165\163\164\157\155" => 0], Constants::MEDIUM => ["\x63\162\x6f\160" => 1, "\x77\151\x64\x74\150" => 200, "\x68\x65\151\147\150\x74" => 200, "\143\165\163\164\157\x6d" => 0], Constants::egwoacukmsioosum => ["\x63\162\157\x70" => 1, "\x77\151\144\164\x68" => 120, "\x68\x65\x69\147\150\164" => 100, "\x63\x75\x73\164\157\155" => 0], Constants::meugkwqwuyoyeeqs => ["\143\x72\157\160" => 1, "\x77\151\x64\164\150" => 80, "\x68\x65\151\x67\150\x74" => 80, "\143\165\x73\x74\x6f\155" => 1]]; } }
