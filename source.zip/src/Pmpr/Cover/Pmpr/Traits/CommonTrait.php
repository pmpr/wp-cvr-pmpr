<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66b9bf433b189             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Traits; use Pmpr\Cover\Pmpr\Customizer; trait CommonTrait { public function wkiaeewoqmsougim($ymqmyyeuycgmigyo, $ggauoeuaesiymgee = false) { return Customizer::symcgieuakksimmu()->giiuwsmyumqwwiyq($ymqmyyeuycgmigyo, $ggauoeuaesiymgee); } public function mkcqggisuwuuueqm() : array { return [self::qisqmmesuewemeqg => ["\143\x72\x6f\160" => 1, "\167\x69\x64\x74\x68" => 803, "\150\145\151\147\150\x74" => 450, "\143\x75\x73\x74\x6f\155" => 0], self::MEDIUM => ["\x63\x72\157\x70" => 1, "\167\x69\144\164\x68" => 200, "\x68\x65\151\x67\150\x74" => 200, "\143\165\163\x74\157\155" => 0], self::egwoacukmsioosum => ["\x63\x72\157\x70" => 1, "\167\151\144\x74\150" => 120, "\x68\x65\x69\147\150\164" => 100, "\143\165\163\x74\157\x6d" => 0], self::meugkwqwuyoyeeqs => ["\143\x72\x6f\x70" => 1, "\167\151\144\x74\150" => 80, "\x68\145\151\x67\150\x74" => 80, "\143\165\163\x74\x6f\x6d" => 1]]; } }
