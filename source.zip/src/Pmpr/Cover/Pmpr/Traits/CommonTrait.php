<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             675816101f185             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Traits; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Cover\Pmpr\Customizer; trait CommonTrait { public function wkiaeewoqmsougim($ymqmyyeuycgmigyo, $ggauoeuaesiymgee = false) { return Customizer::symcgieuakksimmu()->giiuwsmyumqwwiyq($ymqmyyeuycgmigyo, $ggauoeuaesiymgee); } public function mkcqggisuwuuueqm() : array { return [Constants::qisqmmesuewemeqg => ["\x63\162\x6f\160" => 1, "\167\151\x64\x74\x68" => 803, "\x68\145\151\x67\150\164" => 450, "\x63\x75\x73\x74\157\x6d" => 0], Constants::MEDIUM => ["\143\162\x6f\160" => 1, "\167\151\x64\164\x68" => 200, "\150\x65\x69\x67\x68\164" => 200, "\143\x75\x73\x74\x6f\155" => 0], Constants::egwoacukmsioosum => ["\143\162\x6f\x70" => 1, "\167\x69\144\x74\x68" => 120, "\150\145\151\x67\x68\164" => 100, "\143\x75\x73\164\157\155" => 0], Constants::meugkwqwuyoyeeqs => ["\143\162\x6f\160" => 1, "\167\151\144\x74\150" => 80, "\150\x65\x69\147\x68\x74" => 80, "\143\x75\163\x74\157\155" => 1]]; } }
