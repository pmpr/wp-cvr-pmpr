<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669c358f62566             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Traits; use Pmpr\Cover\Pmpr\Customizer; trait CommonTrait { public function wkiaeewoqmsougim($ymqmyyeuycgmigyo, $ggauoeuaesiymgee = false) { return Customizer::symcgieuakksimmu()->giiuwsmyumqwwiyq($ymqmyyeuycgmigyo, $ggauoeuaesiymgee); } public function mkcqggisuwuuueqm() : array { return [self::qisqmmesuewemeqg => ["\x63\x72\x6f\x70" => 1, "\x77\x69\x64\164\150" => 803, "\x68\x65\151\x67\150\164" => 450, "\x63\165\x73\164\x6f\155" => 0], self::MEDIUM => ["\x63\162\157\x70" => 1, "\x77\x69\x64\164\x68" => 200, "\150\145\x69\x67\150\x74" => 200, "\x63\x75\x73\x74\157\x6d" => 0], self::egwoacukmsioosum => ["\x63\x72\x6f\x70" => 1, "\x77\x69\144\x74\x68" => 120, "\150\x65\x69\x67\x68\x74" => 100, "\143\x75\x73\164\x6f\155" => 0], self::meugkwqwuyoyeeqs => ["\x63\162\x6f\160" => 1, "\167\x69\x64\x74\x68" => 80, "\x68\x65\151\x67\150\164" => 80, "\x63\165\x73\164\157\x6d" => 1]]; } }
