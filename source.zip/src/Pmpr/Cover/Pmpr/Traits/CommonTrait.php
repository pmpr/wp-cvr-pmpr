<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6684009825136             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Traits; use Pmpr\Cover\Pmpr\Customizer; trait CommonTrait { public function wkiaeewoqmsougim($ymqmyyeuycgmigyo, $ggauoeuaesiymgee = false) { return Customizer::symcgieuakksimmu()->giiuwsmyumqwwiyq($ymqmyyeuycgmigyo, $ggauoeuaesiymgee); } public function mkcqggisuwuuueqm() : array { return [self::qisqmmesuewemeqg => ["\143\162\x6f\160" => 1, "\167\151\x64\164\x68" => 803, "\150\145\151\x67\150\164" => 450, "\x63\x75\x73\164\x6f\x6d" => 0], self::MEDIUM => ["\143\162\157\160" => 1, "\167\x69\x64\x74\x68" => 200, "\x68\x65\151\147\150\164" => 200, "\x63\165\163\164\x6f\x6d" => 0], self::egwoacukmsioosum => ["\x63\x72\157\x70" => 1, "\167\x69\144\164\x68" => 120, "\x68\x65\x69\x67\x68\164" => 100, "\143\x75\163\164\157\155" => 0], self::meugkwqwuyoyeeqs => ["\x63\x72\x6f\160" => 1, "\167\x69\x64\164\x68" => 80, "\x68\145\151\147\x68\x74" => 80, "\x63\165\x73\x74\157\155" => 1]]; } }
