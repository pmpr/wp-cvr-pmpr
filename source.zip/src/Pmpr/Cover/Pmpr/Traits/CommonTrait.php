<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669d561d8bd6d             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Traits; use Pmpr\Cover\Pmpr\Customizer; trait CommonTrait { public function wkiaeewoqmsougim($ymqmyyeuycgmigyo, $ggauoeuaesiymgee = false) { return Customizer::symcgieuakksimmu()->giiuwsmyumqwwiyq($ymqmyyeuycgmigyo, $ggauoeuaesiymgee); } public function mkcqggisuwuuueqm() : array { return [self::qisqmmesuewemeqg => ["\143\162\157\160" => 1, "\x77\151\144\164\150" => 803, "\x68\x65\151\147\150\164" => 450, "\143\x75\x73\x74\157\x6d" => 0], self::MEDIUM => ["\x63\162\157\x70" => 1, "\x77\x69\144\x74\150" => 200, "\150\x65\151\x67\x68\x74" => 200, "\143\165\x73\x74\157\x6d" => 0], self::egwoacukmsioosum => ["\x63\162\x6f\160" => 1, "\167\x69\144\164\x68" => 120, "\150\145\x69\x67\150\x74" => 100, "\143\x75\163\164\157\x6d" => 0], self::meugkwqwuyoyeeqs => ["\143\162\157\x70" => 1, "\x77\x69\144\x74\x68" => 80, "\x68\145\x69\x67\150\x74" => 80, "\x63\x75\x73\164\x6f\155" => 1]]; } }
