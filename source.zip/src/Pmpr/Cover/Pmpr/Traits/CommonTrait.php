<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67581a8b7701f             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Traits; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Cover\Pmpr\Customizer; trait CommonTrait { public function wkiaeewoqmsougim($ymqmyyeuycgmigyo, $ggauoeuaesiymgee = false) { return Customizer::symcgieuakksimmu()->giiuwsmyumqwwiyq($ymqmyyeuycgmigyo, $ggauoeuaesiymgee); } public function mkcqggisuwuuueqm() : array { return [Constants::qisqmmesuewemeqg => ["\x63\162\157\x70" => 1, "\x77\x69\x64\x74\x68" => 803, "\150\145\151\x67\150\x74" => 450, "\143\165\x73\x74\x6f\155" => 0], Constants::MEDIUM => ["\x63\x72\x6f\x70" => 1, "\x77\151\x64\x74\x68" => 200, "\x68\x65\x69\x67\150\164" => 200, "\143\x75\163\164\x6f\155" => 0], Constants::egwoacukmsioosum => ["\x63\162\157\x70" => 1, "\x77\x69\x64\164\x68" => 120, "\x68\x65\151\x67\150\164" => 100, "\x63\165\x73\164\157\155" => 0], Constants::meugkwqwuyoyeeqs => ["\143\x72\157\x70" => 1, "\x77\x69\144\x74\150" => 80, "\x68\x65\151\x67\x68\x74" => 80, "\x63\165\x73\164\157\x6d" => 1]]; } }
