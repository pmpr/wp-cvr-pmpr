<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669d5b84b76a1             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Traits; use Pmpr\Cover\Pmpr\Customizer; trait CommonTrait { public function wkiaeewoqmsougim($ymqmyyeuycgmigyo, $ggauoeuaesiymgee = false) { return Customizer::symcgieuakksimmu()->giiuwsmyumqwwiyq($ymqmyyeuycgmigyo, $ggauoeuaesiymgee); } public function mkcqggisuwuuueqm() : array { return [self::qisqmmesuewemeqg => ["\x63\x72\157\160" => 1, "\167\151\144\x74\150" => 803, "\x68\145\151\147\x68\164" => 450, "\143\x75\x73\x74\x6f\x6d" => 0], self::MEDIUM => ["\x63\162\157\160" => 1, "\x77\151\x64\x74\150" => 200, "\150\x65\151\x67\150\x74" => 200, "\x63\165\x73\164\x6f\x6d" => 0], self::egwoacukmsioosum => ["\143\162\x6f\x70" => 1, "\x77\x69\144\x74\150" => 120, "\x68\x65\151\147\x68\164" => 100, "\x63\165\x73\x74\x6f\x6d" => 0], self::meugkwqwuyoyeeqs => ["\143\162\x6f\160" => 1, "\167\151\x64\x74\x68" => 80, "\x68\x65\x69\x67\150\x74" => 80, "\x63\165\x73\x74\x6f\x6d" => 1]]; } }
