<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669c49f78f111             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Traits; use Pmpr\Cover\Pmpr\Customizer; trait CommonTrait { public function wkiaeewoqmsougim($ymqmyyeuycgmigyo, $ggauoeuaesiymgee = false) { return Customizer::symcgieuakksimmu()->giiuwsmyumqwwiyq($ymqmyyeuycgmigyo, $ggauoeuaesiymgee); } public function mkcqggisuwuuueqm() : array { return [self::qisqmmesuewemeqg => ["\x63\162\x6f\x70" => 1, "\x77\x69\144\164\x68" => 803, "\x68\x65\x69\147\150\164" => 450, "\143\x75\x73\164\x6f\155" => 0], self::MEDIUM => ["\143\x72\x6f\x70" => 1, "\x77\151\x64\x74\150" => 200, "\x68\x65\151\x67\150\164" => 200, "\x63\x75\x73\x74\157\155" => 0], self::egwoacukmsioosum => ["\143\x72\157\160" => 1, "\167\x69\x64\164\150" => 120, "\150\x65\x69\x67\x68\x74" => 100, "\143\165\x73\x74\x6f\x6d" => 0], self::meugkwqwuyoyeeqs => ["\x63\x72\157\160" => 1, "\x77\x69\144\164\150" => 80, "\x68\x65\x69\x67\x68\x74" => 80, "\143\x75\163\164\x6f\x6d" => 1]]; } }
