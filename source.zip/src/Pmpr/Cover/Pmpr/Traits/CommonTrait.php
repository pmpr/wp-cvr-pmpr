<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66c508e944d8a             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Traits; use Pmpr\Cover\Pmpr\Customizer; trait CommonTrait { public function wkiaeewoqmsougim($ymqmyyeuycgmigyo, $ggauoeuaesiymgee = false) { return Customizer::symcgieuakksimmu()->giiuwsmyumqwwiyq($ymqmyyeuycgmigyo, $ggauoeuaesiymgee); } public function mkcqggisuwuuueqm() : array { return [self::qisqmmesuewemeqg => ["\143\x72\x6f\x70" => 1, "\x77\x69\144\x74\x68" => 803, "\150\x65\x69\147\x68\x74" => 450, "\143\x75\x73\164\157\155" => 0], self::MEDIUM => ["\143\162\x6f\160" => 1, "\x77\151\x64\x74\150" => 200, "\x68\x65\151\147\x68\x74" => 200, "\143\x75\x73\164\157\155" => 0], self::egwoacukmsioosum => ["\143\x72\157\x70" => 1, "\167\151\144\164\150" => 120, "\150\x65\x69\147\150\x74" => 100, "\x63\165\x73\164\157\155" => 0], self::meugkwqwuyoyeeqs => ["\143\x72\157\x70" => 1, "\167\151\144\164\150" => 80, "\x68\x65\151\147\x68\164" => 80, "\x63\x75\163\164\x6f\x6d" => 1]]; } }
