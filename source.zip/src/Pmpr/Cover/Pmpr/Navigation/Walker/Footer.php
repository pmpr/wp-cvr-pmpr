<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d1dbc97f5c2             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Navigation\Walker; class Footer extends Walker { public function __construct() { $this->eggaocmukisgaqgs("\x64\151\166")->oiikmkeaimmqgaiu("\144\151\x76")->seqmucuwuueuqekq(["\143\x6c\x61\x73\163" => "\x72\x6f\167\40\x6d\164\x2d\64"]); } public function smkqamusaugagkwi($siquossayskcwkea, $igqsaukqcqscimok, $kkisyguyosoyymqs, $gquaqgsmiuqsaoum = 0) { $this->igmaewykumgwoaoy($siquossayskcwkea, "\143\154\x61\x73\x73", "\x62\x74\x6e\40\142\x74\x6e\55\x73\155\x20\142\164\x6e\x2d\x67\x72\x61\171\55\65\x30\60\x20\x62\164\156\x2d\142\154\157\143\x6b"); return parent::smkqamusaugagkwi($siquossayskcwkea, $igqsaukqcqscimok, $kkisyguyosoyymqs, $gquaqgsmiuqsaoum); } public function qcgmmmeokuequagy($siquossayskcwkea, $igqsaukqcqscimok, $kkisyguyosoyymqs) { $this->igmaewykumgwoaoy($siquossayskcwkea, "\x63\x6c\x61\163\163", "\x63\x6f\154\55\66"); return parent::qcgmmmeokuequagy($siquossayskcwkea, $igqsaukqcqscimok, $kkisyguyosoyymqs); } }
