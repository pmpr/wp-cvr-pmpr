<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661d98bae5930             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Navigation\Walker; class Footer extends Walker { public function __construct() { $this->eggaocmukisgaqgs("\x64\151\166")->oiikmkeaimmqgaiu("\x64\151\x76")->seqmucuwuueuqekq(["\143\x6c\141\x73\163" => "\x72\157\167\x20\155\x74\55\64"]); } public function smkqamusaugagkwi($siquossayskcwkea, $igqsaukqcqscimok, $kkisyguyosoyymqs, $gquaqgsmiuqsaoum = 0) { $this->igmaewykumgwoaoy($siquossayskcwkea, "\143\154\x61\x73\163", "\x62\x74\156\40\142\x74\156\x2d\x73\x6d\40\142\x74\x6e\55\147\162\141\x79\55\65\x30\60\x20\142\x74\x6e\x2d\x62\x6c\157\143\x6b"); return parent::smkqamusaugagkwi($siquossayskcwkea, $igqsaukqcqscimok, $kkisyguyosoyymqs, $gquaqgsmiuqsaoum); } public function qcgmmmeokuequagy($siquossayskcwkea, $igqsaukqcqscimok, $kkisyguyosoyymqs) { $this->igmaewykumgwoaoy($siquossayskcwkea, "\x63\154\x61\x73\x73", "\143\157\154\x2d\x36"); return parent::qcgmmmeokuequagy($siquossayskcwkea, $igqsaukqcqscimok, $kkisyguyosoyymqs); } }
