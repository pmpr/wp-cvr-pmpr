<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6621af0415f73             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Navigation\Walker; class Footer extends Walker { public function __construct() { $this->eggaocmukisgaqgs("\144\151\166")->oiikmkeaimmqgaiu("\144\151\x76")->seqmucuwuueuqekq(["\x63\154\141\163\163" => "\x72\x6f\x77\40\x6d\x74\55\x34"]); } public function smkqamusaugagkwi($siquossayskcwkea, $igqsaukqcqscimok, $kkisyguyosoyymqs, $gquaqgsmiuqsaoum = 0) { $this->igmaewykumgwoaoy($siquossayskcwkea, "\143\154\141\x73\163", "\142\164\156\x20\x62\x74\x6e\x2d\x73\x6d\x20\142\x74\156\55\x67\162\141\x79\55\x35\60\60\40\x62\x74\x6e\x2d\x62\154\x6f\x63\153"); return parent::smkqamusaugagkwi($siquossayskcwkea, $igqsaukqcqscimok, $kkisyguyosoyymqs, $gquaqgsmiuqsaoum); } public function qcgmmmeokuequagy($siquossayskcwkea, $igqsaukqcqscimok, $kkisyguyosoyymqs) { $this->igmaewykumgwoaoy($siquossayskcwkea, "\x63\x6c\x61\163\163", "\x63\157\154\x2d\66"); return parent::qcgmmmeokuequagy($siquossayskcwkea, $igqsaukqcqscimok, $kkisyguyosoyymqs); } }
