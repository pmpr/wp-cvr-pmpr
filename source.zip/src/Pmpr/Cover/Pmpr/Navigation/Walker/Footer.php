<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6684009825136             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Navigation\Walker; class Footer extends Walker { public function __construct() { $this->eggaocmukisgaqgs("\x64\x69\166")->oiikmkeaimmqgaiu("\144\x69\x76")->seqmucuwuueuqekq(["\143\x6c\x61\163\163" => "\x72\x6f\167\x20\x6d\164\55\x34"]); } public function smkqamusaugagkwi($siquossayskcwkea, $igqsaukqcqscimok, $kkisyguyosoyymqs, $gquaqgsmiuqsaoum = 0) { $this->igmaewykumgwoaoy($siquossayskcwkea, "\x63\x6c\x61\163\x73", "\142\164\x6e\40\142\164\156\55\163\x6d\40\x62\x74\156\x2d\147\x72\x61\171\55\x35\x30\x30\x20\x62\164\x6e\55\142\x6c\x6f\143\153"); return parent::smkqamusaugagkwi($siquossayskcwkea, $igqsaukqcqscimok, $kkisyguyosoyymqs, $gquaqgsmiuqsaoum); } public function qcgmmmeokuequagy($siquossayskcwkea, $igqsaukqcqscimok, $kkisyguyosoyymqs) { $this->igmaewykumgwoaoy($siquossayskcwkea, "\143\x6c\x61\x73\x73", "\x63\x6f\154\x2d\66"); return parent::qcgmmmeokuequagy($siquossayskcwkea, $igqsaukqcqscimok, $kkisyguyosoyymqs); } }
