<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6714e17f99bf3             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Navigation\Walker; use Pmpr\Common\Cover\Navigation\Walker; class Footer extends Walker { public function __construct() { $this->eggaocmukisgaqgs("\144\151\x76")->oiikmkeaimmqgaiu("\144\x69\166")->seqmucuwuueuqekq(["\143\x6c\x61\x73\163" => "\x72\157\x77\40\x6d\x74\x2d\x34"]); } public function smkqamusaugagkwi($siquossayskcwkea, $igqsaukqcqscimok, $kkisyguyosoyymqs, $gquaqgsmiuqsaoum = 0) { $this->igmaewykumgwoaoy($siquossayskcwkea, "\x63\x6c\x61\x73\x73", "\x62\x74\156\x20\142\x74\156\x2d\x73\155\40\x62\x74\156\x2d\x67\x72\x61\171\x2d\x35\60\x30\40\x62\164\156\x2d\142\x6c\157\x63\x6b"); return parent::smkqamusaugagkwi($siquossayskcwkea, $igqsaukqcqscimok, $kkisyguyosoyymqs, $gquaqgsmiuqsaoum); } public function qcgmmmeokuequagy($siquossayskcwkea, $igqsaukqcqscimok, $kkisyguyosoyymqs) { $this->igmaewykumgwoaoy($siquossayskcwkea, "\143\154\141\x73\x73", "\143\157\154\x2d\66"); return parent::qcgmmmeokuequagy($siquossayskcwkea, $igqsaukqcqscimok, $kkisyguyosoyymqs); } }
