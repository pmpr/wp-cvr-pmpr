<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66c508e944d8a             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Navigation\Walker; class Footer extends Walker { public function __construct() { $this->eggaocmukisgaqgs("\144\151\166")->oiikmkeaimmqgaiu("\x64\151\166")->seqmucuwuueuqekq(["\x63\154\x61\x73\x73" => "\x72\157\167\40\x6d\164\x2d\x34"]); } public function smkqamusaugagkwi($siquossayskcwkea, $igqsaukqcqscimok, $kkisyguyosoyymqs, $gquaqgsmiuqsaoum = 0) { $this->igmaewykumgwoaoy($siquossayskcwkea, "\x63\154\141\x73\163", "\x62\x74\156\x20\142\x74\156\x2d\x73\x6d\x20\x62\x74\156\55\147\x72\141\x79\55\65\60\x30\40\142\164\156\x2d\142\x6c\157\x63\153"); return parent::smkqamusaugagkwi($siquossayskcwkea, $igqsaukqcqscimok, $kkisyguyosoyymqs, $gquaqgsmiuqsaoum); } public function qcgmmmeokuequagy($siquossayskcwkea, $igqsaukqcqscimok, $kkisyguyosoyymqs) { $this->igmaewykumgwoaoy($siquossayskcwkea, "\143\154\141\163\163", "\143\x6f\x6c\x2d\66"); return parent::qcgmmmeokuequagy($siquossayskcwkea, $igqsaukqcqscimok, $kkisyguyosoyymqs); } }
