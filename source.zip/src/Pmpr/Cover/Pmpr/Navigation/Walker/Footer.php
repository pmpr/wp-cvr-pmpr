<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e4de2d54d6             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Navigation\Walker; class Footer extends Walker { public function __construct() { $this->eggaocmukisgaqgs("\x64\x69\166")->oiikmkeaimmqgaiu("\x64\151\166")->seqmucuwuueuqekq(["\143\154\x61\x73\x73" => "\x72\x6f\167\x20\x6d\x74\x2d\x34"]); } public function smkqamusaugagkwi($siquossayskcwkea, $igqsaukqcqscimok, $kkisyguyosoyymqs, $gquaqgsmiuqsaoum = 0) { $this->igmaewykumgwoaoy($siquossayskcwkea, "\143\x6c\x61\x73\163", "\x62\164\x6e\40\x62\164\156\x2d\x73\155\x20\x62\164\156\55\147\162\x61\171\55\65\60\x30\40\x62\164\x6e\55\142\x6c\x6f\x63\153"); return parent::smkqamusaugagkwi($siquossayskcwkea, $igqsaukqcqscimok, $kkisyguyosoyymqs, $gquaqgsmiuqsaoum); } public function qcgmmmeokuequagy($siquossayskcwkea, $igqsaukqcqscimok, $kkisyguyosoyymqs) { $this->igmaewykumgwoaoy($siquossayskcwkea, "\x63\x6c\141\163\x73", "\x63\157\x6c\55\66"); return parent::qcgmmmeokuequagy($siquossayskcwkea, $igqsaukqcqscimok, $kkisyguyosoyymqs); } }
