<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             675816101f185             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Navigation\Walker; use Pmpr\Common\Cover\Navigation\Walker; class Footer extends Walker { public function __construct() { $this->eggaocmukisgaqgs("\144\151\166")->oiikmkeaimmqgaiu("\x64\151\x76")->seqmucuwuueuqekq(["\143\154\x61\163\x73" => "\162\x6f\x77\x20\155\164\55\64"]); } public function smkqamusaugagkwi($siquossayskcwkea, $igqsaukqcqscimok, $kkisyguyosoyymqs, $gquaqgsmiuqsaoum = 0) { $this->igmaewykumgwoaoy($siquossayskcwkea, "\x63\x6c\141\x73\x73", "\x62\164\x6e\40\142\x74\x6e\55\x73\x6d\40\x62\164\156\55\x67\162\x61\x79\55\x35\x30\x30\40\142\x74\x6e\x2d\x62\x6c\x6f\x63\x6b"); return parent::smkqamusaugagkwi($siquossayskcwkea, $igqsaukqcqscimok, $kkisyguyosoyymqs, $gquaqgsmiuqsaoum); } public function qcgmmmeokuequagy($siquossayskcwkea, $igqsaukqcqscimok, $kkisyguyosoyymqs) { $this->igmaewykumgwoaoy($siquossayskcwkea, "\143\154\x61\163\163", "\x63\157\x6c\55\x36"); return parent::qcgmmmeokuequagy($siquossayskcwkea, $igqsaukqcqscimok, $kkisyguyosoyymqs); } }
