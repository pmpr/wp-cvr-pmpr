<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6637344f0b8b9             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Navigation\Walker; class Footer extends Walker { public function __construct() { $this->eggaocmukisgaqgs("\x64\x69\x76")->oiikmkeaimmqgaiu("\144\x69\166")->seqmucuwuueuqekq(["\143\154\x61\x73\163" => "\x72\157\x77\40\155\x74\55\64"]); } public function smkqamusaugagkwi($siquossayskcwkea, $igqsaukqcqscimok, $kkisyguyosoyymqs, $gquaqgsmiuqsaoum = 0) { $this->igmaewykumgwoaoy($siquossayskcwkea, "\x63\154\141\x73\x73", "\142\x74\156\40\x62\x74\156\55\163\155\x20\142\164\x6e\x2d\147\x72\x61\x79\55\x35\60\x30\x20\x62\164\156\x2d\x62\154\157\143\x6b"); return parent::smkqamusaugagkwi($siquossayskcwkea, $igqsaukqcqscimok, $kkisyguyosoyymqs, $gquaqgsmiuqsaoum); } public function qcgmmmeokuequagy($siquossayskcwkea, $igqsaukqcqscimok, $kkisyguyosoyymqs) { $this->igmaewykumgwoaoy($siquossayskcwkea, "\143\154\141\x73\163", "\143\x6f\154\55\66"); return parent::qcgmmmeokuequagy($siquossayskcwkea, $igqsaukqcqscimok, $kkisyguyosoyymqs); } }
