<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66812eb5d80af             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Navigation\Walker; class Footer extends Walker { public function __construct() { $this->eggaocmukisgaqgs("\144\x69\166")->oiikmkeaimmqgaiu("\144\151\166")->seqmucuwuueuqekq(["\143\x6c\141\x73\163" => "\x72\x6f\x77\x20\155\x74\x2d\64"]); } public function smkqamusaugagkwi($siquossayskcwkea, $igqsaukqcqscimok, $kkisyguyosoyymqs, $gquaqgsmiuqsaoum = 0) { $this->igmaewykumgwoaoy($siquossayskcwkea, "\x63\154\x61\x73\163", "\x62\x74\x6e\x20\142\x74\x6e\55\x73\155\x20\142\164\x6e\x2d\147\x72\x61\x79\55\x35\60\x30\40\x62\x74\156\x2d\x62\x6c\x6f\143\153"); return parent::smkqamusaugagkwi($siquossayskcwkea, $igqsaukqcqscimok, $kkisyguyosoyymqs, $gquaqgsmiuqsaoum); } public function qcgmmmeokuequagy($siquossayskcwkea, $igqsaukqcqscimok, $kkisyguyosoyymqs) { $this->igmaewykumgwoaoy($siquossayskcwkea, "\x63\x6c\x61\x73\163", "\143\x6f\x6c\55\x36"); return parent::qcgmmmeokuequagy($siquossayskcwkea, $igqsaukqcqscimok, $kkisyguyosoyymqs); } }
