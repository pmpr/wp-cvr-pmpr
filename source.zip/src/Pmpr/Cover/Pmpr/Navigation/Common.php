<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66812eb5d80af             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Navigation; use Pmpr\Cover\Pmpr\Container; abstract class Common extends Container { }
