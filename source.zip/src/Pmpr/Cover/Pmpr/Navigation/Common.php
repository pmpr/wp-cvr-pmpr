<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66b6183f51930             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Navigation; use Pmpr\Cover\Pmpr\Container; abstract class Common extends Container { }
