<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66bd2143b21cb             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Navigation; use Pmpr\Cover\Pmpr\Container; abstract class Common extends Container { }
