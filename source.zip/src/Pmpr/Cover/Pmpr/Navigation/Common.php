<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669c358f62566             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Navigation; use Pmpr\Cover\Pmpr\Container; abstract class Common extends Container { }
