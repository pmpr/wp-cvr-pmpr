<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669ada6f97df7             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Pmpr\Navigation; use Pmpr\Cover\Pmpr\Container; abstract class Common extends Container { }
